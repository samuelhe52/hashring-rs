<script setup lang="ts">
import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
import { init, use, type EChartsCoreOption, type EChartsType } from 'echarts/core'
import { BarChart, LineChart } from 'echarts/charts'
import { GridComponent, LegendComponent, TooltipComponent, AriaComponent, MarkAreaComponent, MarkLineComponent } from 'echarts/components'
import { SVGRenderer } from 'echarts/renderers'
import { object } from '../data'
import { downloadBlob, svgToPng } from '../download'

use([BarChart, LineChart, GridComponent, LegendComponent, TooltipComponent, AriaComponent, MarkAreaComponent, MarkLineComponent, SVGRenderer])
const props = withDefaults(defineProps<{ option: EChartsCoreOption; label: string; animateUpdates?: boolean; motion?: boolean; exportable?: boolean; source?: string }>(), { motion: true, animateUpdates: false })
const emit = defineEmits<{ layout: [] }>()
const container = ref<HTMLDivElement | null>(null)
const exportError = ref('')
const exporting = ref(false)
let chart: EChartsType | undefined
let resizeObserver: ResizeObserver | undefined
let painted = false
const chartText = { fontFamily: 'system-ui, Microsoft YaHei, sans-serif', color: '#736f65' }

function update() {
  const first = !painted
  const interpolate = !first && props.animateUpdates
  chart?.setOption({
    backgroundColor: 'transparent',
    textStyle: chartText,
    aria: { enabled: true, description: props.label },
    ...props.option,
    animation: props.motion !== false && !matchMedia('(prefers-reduced-motion: reduce)').matches && (first || props.animateUpdates === true),
    animationDuration: 540,
    animationDurationUpdate: interpolate ? 360 : 0,
    animationDelay: (index: number) => first ? Math.min(index * 40, 200) : 0,
    animationEasing: 'cubicOut',
    animationEasingUpdate: 'cubicOut',
    animationDelayUpdate: (index: number) => Math.min(index * 28, 112),
    tooltip: { confine: true, ...object(props.option.tooltip) },
  }, interpolate ? { replaceMerge: ['series'] } : { notMerge: true })
  painted = true
  emit('layout')
}

async function exportChart(format: 'svg' | 'png') {
  exporting.value = true
  exportError.value = ''
  const width = 1100
  const height = 520
  let figure: EChartsType | undefined
  try {
    figure = init(null, undefined, { renderer: 'svg', ssr: true, width, height: height - 104 })
    const series = props.option.series
    const showLegend = !props.option.legend && Array.isArray(series) && series.length > 1
    const grid = object(props.option.grid)
    figure.setOption({
      textStyle: { ...chartText, fontSize: 13 },
      ...props.option,
      ...(showLegend ? { legend: { bottom: 2 }, grid: { ...grid, bottom: (typeof grid.bottom === 'number' ? grid.bottom : 40) + 28 } } : {}),
      backgroundColor: 'transparent',
      animation: false,
    })
    const svg = new DOMParser().parseFromString(figure.renderToSVGString(), 'image/svg+xml').documentElement
    const ns = 'http://www.w3.org/2000/svg'
    const sheet = document.createElementNS(ns, 'svg')
    sheet.setAttribute('width', String(width))
    sheet.setAttribute('height', String(height))
    sheet.setAttribute('viewBox', `0 0 ${width} ${height}`)
    const paper = document.createElementNS(ns, 'rect')
    paper.setAttribute('width', '100%')
    paper.setAttribute('height', '100%')
    paper.setAttribute('fill', '#fbfaf7')
    sheet.append(paper)
    function caption(value: string, y: number, size: number, color: string) {
      const line = document.createElementNS(ns, 'text')
      line.setAttribute('x', '24')
      line.setAttribute('y', String(y))
      line.setAttribute('fill', color)
      line.setAttribute('font-size', String(size))
      line.setAttribute('font-family', chartText.fontFamily)
      line.textContent = value.length > 82 ? value.slice(0, 79) + '…' : value
      sheet.append(line)
    }
    caption(props.label, 35, 22, '#282720')
    svg.setAttribute('y', '54')
    sheet.append(svg)
    caption(props.source ? 'hashring-rs / ' + props.source : 'hashring-rs 实验工作台', height - 18, 13, '#736f65')
    const blob = new Blob([new XMLSerializer().serializeToString(sheet)], { type: 'image/svg+xml;charset=utf-8' })
    const file = props.label.replace(/[\\/:*?"<>|]/g, '-').slice(0, 100) + '.' + format
    downloadBlob(format === 'svg' ? blob : await svgToPng(blob, width, height), file)
  } catch (error) {
    exportError.value = error instanceof Error ? error.message : '图表导出失败'
  } finally {
    figure?.dispose()
    exporting.value = false
  }
}

onMounted(() => {
  if (!container.value) return
  chart = init(container.value, undefined, { renderer: 'svg' })
  update()
  let width = container.value.clientWidth
  let height = container.value.clientHeight
  resizeObserver = new ResizeObserver(() => {
    if (!container.value) return
    const nextWidth = container.value.clientWidth
    const nextHeight = container.value.clientHeight
    if (nextWidth !== width || nextHeight !== height) { width = nextWidth; height = nextHeight; chart?.resize(); emit('layout') }
  })
  resizeObserver.observe(container.value)
})
watch(() => props.option, update, { deep: true })
onBeforeUnmount(() => { resizeObserver?.disconnect(); chart?.dispose() })
defineExpose({ pixelAt(value: number): number | null { const pixel = chart?.convertToPixel({ xAxisIndex: 0 }, value); return typeof pixel === 'number' && Number.isFinite(pixel) ? pixel : null } })
</script>

<template>
  <div v-if="exportable" class="chart-export">
    <span>导出图表</span>
    <button class="button secondary" :disabled="exporting" @click="exportChart('png')">PNG</button>
    <button class="button secondary" :disabled="exporting" @click="exportChart('svg')">SVG</button>
    <p v-if="exportError" class="text-warning" role="alert">{{ exportError }}</p>
  </div>
  <div ref="container" class="data-chart" role="img" :aria-label="label"></div>
</template>
