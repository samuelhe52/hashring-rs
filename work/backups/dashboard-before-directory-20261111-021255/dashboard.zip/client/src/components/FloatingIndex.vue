<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, useId, watch } from 'vue'

const props = defineProps<{ items: { id: string; label: string }[] }>()
const root = ref<HTMLElement | null>(null)
const toggle = ref<HTMLButtonElement | null>(null)
const menu = ref<HTMLDialogElement | null>(null)
const current = ref('')
const progress = ref(0)
const open = ref(false)
const menuId = useId()
const headingId = useId()
let scroller: HTMLElement | null = null
let observer: ResizeObserver | undefined
let frame = 0
let outsidePress = false
let locked: { element: HTMLElement; overflow: string } | null = null
let chosen: { id: string; position: number; arrived: boolean } | null = null

function scrollArea() { return scroller ?? document.scrollingElement }

function update() {
  frame = 0
  const area = scrollArea()
  if (!area) return
  const distance = area.scrollHeight - area.clientHeight
  progress.value = distance > 0 ? Math.max(0, Math.min(1, area.scrollTop / distance)) : 1
  if (chosen) {
    const atTarget = Math.abs(chosen.position - area.scrollTop) < 2
    if (atTarget || !chosen.arrived) {
      chosen.arrived ||= atTarget
      current.value = chosen.id
      return
    }
    chosen = null
  }
  const top = scroller?.getBoundingClientRect().top ?? 0
  const threshold = distance > 0 && distance - area.scrollTop < 2 ? top + area.clientHeight : top + 120
  let active = props.items[0]?.id ?? ''
  let closest = -Infinity
  for (const item of props.items) {
    const sectionTop = document.getElementById(item.id)?.getBoundingClientRect().top
    if (sectionTop === undefined || sectionTop > threshold || sectionTop <= closest + 1) continue
    active = item.id
    closest = sectionTop
  }
  current.value = active
}

function schedule() { if (!frame) frame = requestAnimationFrame(update) }

function readFromScroll() {
  if (!chosen) return
  chosen = null
  schedule()
}

function scrollKey(event: KeyboardEvent) {
  if (event.target instanceof Element && event.target.closest('input, select, textarea, button, a')) return
  if (['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' '].includes(event.key)) readFromScroll()
}

function releaseScroll() {
  if (!locked) return
  locked.element.style.overflow = locked.overflow
  locked = null
}

function closeMenu() {
  menu.value?.close()
  open.value = false
  releaseScroll()
}

function openMenu(event: MouseEvent) {
  if (!menu.value || menu.value.open) return
  const element = scroller ?? document.body
  locked = { element, overflow: element.style.overflow }
  element.style.overflow = 'hidden'
  menu.value.showModal()
  open.value = true
  const list = menu.value.querySelector<HTMLElement>('.index-dialog-nav')
  const active = list?.querySelector<HTMLElement>('[aria-current="location"]') ?? list?.querySelector<HTMLElement>('a')
  const focusTarget = event.detail === 0 ? active : list
  focusTarget?.focus({ preventScroll: true })
  if (active && list) list.scrollTop = active.offsetTop - list.offsetTop - (list.clientHeight - active.offsetHeight) / 2
}

function go(id: string) {
  closeMenu()
  const section = document.getElementById(id)
  const area = scrollArea()
  if (!section || !area) return
  const top = scroller?.getBoundingClientRect().top ?? 0
  const margin = parseFloat(getComputedStyle(section).scrollMarginTop) || 0
  const position = Math.min(area.scrollHeight - area.clientHeight, Math.max(0, area.scrollTop + section.getBoundingClientRect().top - top - margin))
  chosen = { id, position, arrived: false }
  current.value = id
  section.focus({ preventScroll: true })
  area.scrollTo({ top: position, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })
}

function outside(event: MouseEvent) {
  if (!menu.value || event.target !== menu.value) return false
  const box = menu.value.getBoundingClientRect()
  return event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom
}
function rememberPress(event: PointerEvent) { outsidePress = outside(event) }

function resize() {
  if (menu.value?.open && toggle.value && !toggle.value.checkVisibility()) closeMenu()
  chosen = null
  schedule()
}

onMounted(() => {
  scroller = root.value?.closest<HTMLElement>('.window-body') ?? null
  const target = scroller ?? window
  target.addEventListener('scroll', schedule, { passive: true })
  target.addEventListener('wheel', readFromScroll, { passive: true })
  target.addEventListener('touchmove', readFromScroll, { passive: true })
  target.addEventListener('keydown', scrollKey as EventListener)
  window.addEventListener('resize', resize)
  const content = root.value?.closest('.playback-layout, .workbench')
  if (content) {
    observer = new ResizeObserver(schedule)
    observer.observe(content)
  }
  schedule()
})
watch(() => props.items, schedule, { flush: 'post' })
onBeforeUnmount(() => {
  const target = scroller ?? window
  target.removeEventListener('scroll', schedule)
  target.removeEventListener('wheel', readFromScroll)
  target.removeEventListener('touchmove', readFromScroll)
  target.removeEventListener('keydown', scrollKey as EventListener)
  window.removeEventListener('resize', resize)
  observer?.disconnect()
  cancelAnimationFrame(frame)
  closeMenu()
})
</script>

<template>
  <div ref="root" class="floating-index">
    <nav class="index-rail" aria-label="页面目录">
      <span class="index-label">目录</span>
      <ul>
        <li v-for="(item, order) in items" :key="item.id" :style="{ '--index-delay': order * 35 + 'ms' }"><a :href="'#' + item.id" :aria-current="current === item.id ? 'location' : undefined" @click.prevent="go(item.id)">{{ item.label }}</a></li>
      </ul>
    </nav>

    <button ref="toggle" type="button" class="index-toggle" title="打开目录" aria-label="打开目录" aria-haspopup="dialog" :aria-expanded="open" :aria-controls="menuId" @click="openMenu">
      <svg class="index-progress" viewBox="0 0 48 48" aria-hidden="true">
        <circle class="index-progress-track" cx="24" cy="24" r="22" />
        <circle class="index-progress-value" cx="24" cy="24" r="22" pathLength="1" stroke-dasharray="1" :stroke-dashoffset="1 - progress" />
      </svg>
      <svg class="index-icon" viewBox="0 0 20 20" aria-hidden="true"><path d="M7 5h9M7 10h9M7 15h6M3.5 5h.1M3.5 10h.1M3.5 15h.1" /></svg>
    </button>

    <dialog :id="menuId" ref="menu" class="index-dialog" :aria-labelledby="headingId" @cancel.stop.prevent="closeMenu"
      @pointerdown="rememberPress" @click="outsidePress && outside($event) && closeMenu()">
      <div class="index-dialog-heading">
        <h2 :id="headingId">目录</h2>
        <button type="button" class="index-close" aria-label="关闭目录" @click="closeMenu">
          <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10m0-10L5 15" /></svg>
        </button>
      </div>
      <nav class="index-dialog-nav" aria-label="页面目录" tabindex="-1">
        <ul>
          <li v-for="(item, order) in items" :key="item.id" :style="{ '--index-delay': order * 22 + 'ms' }">
            <a :href="'#' + item.id" :aria-current="current === item.id ? 'location' : undefined" @click.prevent="go(item.id)">{{ item.label }}</a>
          </li>
        </ul>
      </nav>
    </dialog>
  </div>
</template>
