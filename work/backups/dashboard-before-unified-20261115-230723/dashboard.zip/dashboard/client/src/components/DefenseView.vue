<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import DefenseReports from './DefenseReports.vue'
import DefenseRing from './DefenseRing.vue'
import DefenseWindowMetrics from './DefenseWindowMetrics.vue'
import DetailWindow from './DetailWindow.vue'
import FloatingIndex from './FloatingIndex.vue'
import ReplayEventList from './ReplayEventList.vue'
import RunCompare from './RunCompare.vue'
import RunConfig from './RunConfig.vue'
import RunFiles from './RunFiles.vue'
import TopologyView from './TopologyView.vue'
import { canonical } from '../compare.ts'
import { formatNumber as fmt, modeLabels, number, object, request, statusLabels, text } from '../data'
import { defaultSceneRun, defenseCase, headline, latestPublishedEpoch, sceneFor, scenes, seconds, stageDetails, type Scene } from '../defense'
import { absoluteEventTime, eventName, eventSummary, relativeEventTime } from '../events'
import { replayBounds, visibleCount } from '../history.ts'
import { defenseDirectory, type DirectoryEntry } from '../navigation'
import { decodeTopology, type RingModel } from '../topology.ts'
import type { EventLog, RunDetail, RunEvent, RunListItem } from '../types'
import { useReplayClock } from '../useReplayClock'
import '../defense.css'

type Panel = 'runs' | 'compare' | 'report' | 'config' | 'event'
type Report = 'load' | 'balance' | 'acceptance'
type ConfigTab = 'parameters' | 'topology' | 'raw' | 'logs'
const query = new URLSearchParams(location.search)
const scene = ref<Scene>(query.get('scene') === 'expansion' ? 'expansion' : 'fault')
const selectedId = ref('')
const runs = ref<RunListItem[]>([])
const run = ref<RunDetail | null>(null)
const log = ref<EventLog>({ events: [], issues: [], missing: false })
const listLoading = ref(true)
const runLoading = ref(false)
const listError = ref('')
const loadError = ref('')
const eventError = ref('')
const missingLinkedRun = ref(false)
const panel = ref<Panel | null>(null)
const returnIndex = ref('defense-overview')
const visual = ref<'ring' | 'metrics' | 'mechanism'>('ring')
const evidence = ref<'stage' | 'feed'>('stage')
const mechanismOverride = ref<'before' | 'after' | null>(null)
const sourceEvent = ref<RunEvent>()
const configTab = ref<ConfigTab>('parameters')
const report = ref<Report>('load')
const pickerSearch = ref('')
const timeline = ref<HTMLElement | null>(null)
let listController: AbortController | undefined
let detailController: AbortController | undefined

const candidateRuns = computed(() => runs.value.filter(item => sceneFor(item.config) === scene.value))
const pickerRuns = computed(() => candidateRuns.value.filter(item => item.name.toLowerCase().includes(pickerSearch.value.trim().toLowerCase())))
const replay = computed(() => defenseCase(scene.value, log.value.events))
const stages = computed(() => replay.value.stages.map(stage => ({ ...stage, ...stageDetails(stage, replay.value, run.value?.summary) })))
const stageEvents = computed(() => stages.value.map(stage => stage.event))
const bounds = computed(() => replayBounds(replay.value.records, run.value?.manifest?.started_unix_ms))
const initialEvent = computed(() => stages.value[0]?.event ?? replay.value.records[0])
const { cursor, boundaryLine, playing, speed, pause, seek, toggle } = useReplayClock(
  () => bounds.value,
  () => ({ time: initialEvent.value?.unix_ms ?? bounds.value.start, line: initialEvent.value?.line ?? Infinity }),
)
const count = computed(() => visibleCount(replay.value.records, cursor.value, boundaryLine.value ?? Infinity))
const seen = computed(() => replay.value.records.slice(0, count.value))
const currentEvent = computed(() => seen.value.at(-1))
const stageIndex = computed(() => visibleCount(stageEvents.value, cursor.value, boundaryLine.value ?? Infinity) - 1)
const activeStage = computed(() => stages.value[stageIndex.value])
const reachedStages = computed(() => stages.value.slice(0, stageIndex.value + 1))
const sourceOrigin = computed(() => replay.value.anchor?.unix_ms ?? bounds.value.origin)
const readings = computed(() => headline(scene.value, replay.value, run.value?.summary))
const duration = computed(() => bounds.value.end - bounds.value.start)
const config = computed(() => object(run.value?.manifest?.config))
const metadata = computed(() => {
  const initial = replay.value.initialSnapshot?.fields.members
  const initialCount = Array.isArray(initial) ? initial.length : null
  const peak = number(config.value.node_count)
  let nodes = peak === null ? '未记录' : fmt(peak)
  if (initialCount !== null && peak !== null && peak > initialCount) {
    nodes = scene.value === 'fault' ? initialCount + ' + ' + (peak - initialCount) + ' 替换' : initialCount + '→' + peak
  }
  return [
    { label: '节点', value: nodes }, { label: '键数', value: number(config.value.key_count) === null ? '未记录' : fmt(config.value.key_count) },
    { label: 'V', value: text(config.value.virtual_nodes), title: '每个物理节点的虚拟节点数' },
    { label: 'RF', value: text(config.value.desired_replication_factor), title: '目标副本数' },
    { label: 'ACK', value: text(config.value.write_ack_policy), title: '写入确认策略' },
  ]
})
const localSample = computed(() => run.value?.source === 'demo' || run.value?.name === scenes[scene.value].sample)
const topologyRecords = computed(() => log.value.events.filter(event => event.event === 'topology_published'))
const snapshots = computed(() => replay.value.records.flatMap(event => {
  if (event.event !== 'topology_published') return []
  const model = decodeTopology(event.fields).model
  return model ? [{ event, model }] : []
}))
const snapshotEvents = computed(() => snapshots.value.map(({ event }) => event))
const snapshotIndex = computed(() => visibleCount(snapshotEvents.value, cursor.value, boundaryLine.value ?? Infinity) - 1)
const snapshot = computed(() => snapshots.value[snapshotIndex.value])
const earlierRing = computed<RingModel | null>(() => {
  const initial = snapshots.value.slice(0, Math.max(0, snapshotIndex.value)).find(({ event }) => event === replay.value.initialSnapshot)
  if (!snapshot.value || !initial || initial.model.epoch === snapshot.value.model.epoch) return null
  return initial.model
})
const publishedEpoch = computed(() => latestPublishedEpoch(seen.value))
const missingTargetRing = computed(() => scene.value === 'expansion' &&
  reachedStages.value.some(stage => stage.kind === 'migrated' || stage.kind === 'verified') &&
  !reachedStages.value.some(stage => stage.kind === 'snapshot'))
const ringStatus = computed(() => {
  const displayed = snapshot.value?.model.epoch
  if (publishedEpoch.value && publishedEpoch.value !== displayed) {
    return '已发布 epoch ' + publishedEpoch.value + (displayed ? ' · 环图为记录中的 epoch ' + displayed : ' · 完整快照未记录')
  }
  if (missingTargetRing.value) return '扩容后的完整快照未记录'
  return snapshot.value ? 'events.jsonl 第 ' + snapshot.value.event.line + ' 行' : '当前游标无完整快照'
})
const victim = computed(() => {
  const anchor = replay.value.anchor
  return scene.value === 'fault' && anchor && seen.value.includes(anchor)
    ? String(anchor.fields.node_id ?? anchor.fields.victim ?? '') : undefined
})
const mechanism = computed(() => mechanismOverride.value ?? (
  reachedStages.value.some(stage => ['publish', 'migrated', 'verified', 'snapshot'].includes(stage.kind)) ? 'after' : 'before'
))
const hasMetrics = computed(() => replay.value.records.some(event => event.event === 'metrics_sampled'))
const marks = computed(() => reachedStages.value.map(stage => stage.event))
const activeIndex = computed(() => {
  switch (panel.value) {
    case 'report': return report.value === 'acceptance' ? 'defense-acceptance' : report.value === 'balance' ? 'defense-balance' : 'defense-load'
    case 'config': return configTab.value === 'parameters' ? 'defense-config' : 'defense-' + configTab.value
    case 'event': return 'defense-feed'
    case 'runs': return 'defense-runs'
    case 'compare': return 'defense-compare'
    default: return returnIndex.value
  }
})
const modalTitle = computed(() => {
  switch (panel.value) {
    case 'runs': return '选择' + scenes[scene.value].title + '记录'
    case 'compare': return '跨运行对比'
    case 'report': return report.value === 'acceptance' ? '课程验收对照' : '负载与均衡'
    case 'config': return '运行配置与证据'
    case 'event': return sourceEvent.value ? eventName(sourceEvent.value.event) : '事件原文'
    default: return ''
  }
})
const modalSubtitle = computed(() => {
  if (panel.value === 'event' && sourceEvent.value) return 'events.jsonl · 第 ' + sourceEvent.value.line + ' 行 · ' + absoluteEventTime(sourceEvent.value.unix_ms) + ' 北京时间'
  return panel.value === 'config' ? run.value?.name : undefined
})
const workbenchLink = computed(() => {
  const previous = sessionStorage.getItem('hashring.workbench.run')
  return previous ? './?run=' + encodeURIComponent(previous) : './'
})
const opener = computed(() => './?run=' + encodeURIComponent(run.value?.id ?? ''))
const runBase = computed(() => '/api/runs/' + encodeURIComponent(run.value?.id ?? ''))
const comparableConfig = (value: RunListItem['config']) =>
  canonical(Object.fromEntries(Object.entries(value).filter(([key]) => key !== 'output_dir' && key !== 'write_ack_policy')))
const compareDefaults = computed(() => {
  const signature = comparableConfig(config.value)
  const sameMode = candidateRuns.value.filter(item => item.id !== selectedId.value && item.status === 'success' &&
    item.name !== run.value?.name && comparableConfig(item.config) === signature)
  if (selectedId.value && sameMode[0]) return [selectedId.value, sameMode[0].id]
  const latency = runs.value.filter(item => !item.source && item.status === 'success' && item.config.mode === 'latency')
  return latency.length >= 2 ? latency.slice(0, 2).map(item => item.id) : selectedId.value ? [selectedId.value] : []
})
const sampleCommand = computed(() => {
  if (run.value?.name !== scenes[scene.value].sample) return ''
  const fault = scene.value === 'fault'
  return [
    'target/release/hashring-rs experiment --mode ' + (fault ? 'availability' : 'correctness'),
    '  --nodes 4 --keys ' + (fault ? '300' : '2000') + ' --virtual-nodes 32 --concurrency 8 --seed 1',
    '  --desired-replication-factor 3 --policy ' + (fault ? 'first-successor' : 'owner-only'),
    '  --worker-threads 2 --coordinator-worker-threads 2 --output results/defense-' + scene.value,
  ].join(' \\\n')
})

const sceneKey = (kind: Scene) => 'hashring.defense.' + kind
function updateUrl() {
  const url = new URL(location.href)
  url.searchParams.set('view', 'defense')
  url.searchParams.set('scene', scene.value)
  if (selectedId.value) url.searchParams.set('run', selectedId.value)
  else url.searchParams.delete('run')
  history.replaceState(history.state, '', url)
}
function jump(event: RunEvent) { seek(event.unix_ms, event.line) }
function step(direction: number) {
  const stage = stages.value[stageIndex.value + direction]
  if (stage) jump(stage.event)
}
function openPanel(next: Panel) {
  pause()
  panel.value = next
}
function openReport(view: Report) {
  report.value = view
  openPanel('report')
}
function openConfig(tab: ConfigTab = 'parameters') {
  configTab.value = tab
  openPanel('config')
}
function inspect(event: RunEvent) {
  sourceEvent.value = event
  openPanel('event')
}
function scrollToSection(id: string, keyboard: boolean) {
  const element = document.getElementById(id)
  if (keyboard) element?.focus({ preventScroll: true })
  element?.scrollIntoView({ block: 'start', behavior: keyboard || matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })
}
async function navigate(entry: DirectoryEntry, keyboard: boolean) {
  switch (entry.id) {
    case 'defense-overview': panel.value = null; returnIndex.value = entry.id; await nextTick(); scrollToSection(entry.id, keyboard); break
    case 'defense-current':
    case 'defense-feed':
      panel.value = null
      evidence.value = entry.id === 'defense-feed' ? 'feed' : 'stage'
      returnIndex.value = entry.id
      await nextTick()
      scrollToSection('defense-evidence', keyboard)
      break
    case 'defense-load': openReport('load'); break
    case 'defense-balance': openReport('balance'); break
    case 'defense-acceptance': openReport('acceptance'); break
    case 'defense-config': openConfig(); break
    case 'defense-topology': openConfig('topology'); break
    case 'defense-raw': openConfig('raw'); break
    case 'defense-logs': openConfig('logs'); break
    case 'defense-compare': openPanel('compare'); break
    case 'defense-runs': openPanel('runs'); break
  }
}

async function selectRun(id: string) {
  detailController?.abort()
  pause()
  selectedId.value = id
  if (id) sessionStorage.setItem(sceneKey(scene.value), id)
  updateUrl()
  run.value = null
  log.value = { events: [], issues: [], missing: false }
  loadError.value = ''
  eventError.value = ''
  visual.value = 'ring'
  evidence.value = 'stage'
  returnIndex.value = 'defense-overview'
  panel.value = null
  runLoading.value = !!id
  if (!id) return

  detailController = new AbortController()
  const signal = detailController.signal
  const base = '/api/runs/' + encodeURIComponent(id)
  const [detail, events] = await Promise.allSettled([request<RunDetail>(base, signal), request<EventLog>(base + '/events', signal)])
  if (signal.aborted) return
  if (detail.status === 'fulfilled') {
    run.value = detail.value
    if (events.status === 'fulfilled') log.value = events.value
    else eventError.value = events.reason instanceof Error ? events.reason.message : String(events.reason)
    if (initialEvent.value) jump(initialEvent.value)
    else seek(bounds.value.start)
  } else loadError.value = detail.reason instanceof Error ? detail.reason.message : String(detail.reason)
  runLoading.value = false
}
function selectScene(kind: Scene) {
  if (scene.value === kind) return
  missingLinkedRun.value = false
  scene.value = kind
  pickerSearch.value = ''
  void selectRun(defaultSceneRun(runs.value, kind, sessionStorage.getItem(sceneKey(kind)))?.id ?? '')
}
async function loadRuns() {
  listController?.abort()
  listController = new AbortController()
  const signal = listController.signal
  listLoading.value = true
  listError.value = ''
  try {
    const result = await request<{ runs: RunListItem[] }>('/api/runs?include=demo', signal)
    if (signal.aborted) return
    runs.value = result.runs
    const wanted = new URLSearchParams(location.search).get('run')
    const linked = runs.value.find(item => item.id === wanted) ?? runs.value.find(item => item.source === 'demo' && item.name === wanted)
    const linkedScene = sceneFor(linked?.config)
    if (linked && linkedScene) {
      missingLinkedRun.value = false
      scene.value = linkedScene
      void selectRun(linked.id)
    } else {
      missingLinkedRun.value = !!wanted
      const next = defaultSceneRun(runs.value, scene.value, sessionStorage.getItem(sceneKey(scene.value)))
      void selectRun(next?.id ?? '')
    }
  } catch (failure) {
    if (!signal.aborted) listError.value = failure instanceof Error ? failure.message : String(failure)
  } finally {
    if (!signal.aborted) listLoading.value = false
  }
}

watch(activeStage, async () => {
  mechanismOverride.value = null
  await nextTick()
  const rail = timeline.value
  const current = rail?.querySelector<HTMLElement>('[aria-current="step"]')
  if (rail && current && rail.scrollWidth > rail.clientWidth) {
    const offset = current.getBoundingClientRect().left - rail.getBoundingClientRect().left
    if (offset < 0 || offset + current.offsetWidth > rail.clientWidth) rail.scrollLeft += offset
  }
})
onMounted(loadRuns)
onBeforeUnmount(() => { listController?.abort(); detailController?.abort() })
</script>

<template>
  <div class="defense-shell">
    <header id="defense-overview" class="defense-header" tabindex="-1">
      <div class="defense-title">
        <svg class="brand-mark" viewBox="0 0 36 36" fill="none" aria-hidden="true"><circle cx="18" cy="18" r="12" stroke="currentColor" stroke-width="1.2"/><circle cx="18" cy="6" r="3" fill="var(--accent)"/><circle cx="28.4" cy="24" r="2.6" fill="var(--teal)"/><circle cx="7.6" cy="24" r="2.6" fill="var(--gold)"/><circle cx="18" cy="18" r="2" fill="currentColor"/></svg>
        <h1>hashring-rs</h1><span>答辩演示</span>
      </div>
      <a class="button secondary defense-back" :href="workbenchLink"><span aria-hidden="true">←</span> 实验工作台</a>
    </header>

    <main class="defense-main">
      <div class="defense-navigation">
        <nav class="defense-scenes" aria-label="答辩案例">
          <button :aria-pressed="scene === 'expansion'" @click="selectScene('expansion')">
            <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 3.5a6.5 6.5 0 1 0 6.5 6.5M12 5h6m-3-3v6" /></svg>在线扩容
          </button>
          <button :aria-pressed="scene === 'fault'" @click="selectScene('fault')">
            <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2.5 10h3.3l1.8-4.8 3.1 9.4 2.5-6.1h4.3" /></svg>主节点故障
          </button>
        </nav>
        <div class="defense-run-control">
          <span v-if="run" class="defense-run-state" :title="run.name"><i aria-hidden="true" :class="run.status"></i>历史回放<span> · {{ localSample ? '本机小样' : run.name.split('/').at(-1) }}</span></span>
          <button class="button secondary defense-picker" aria-haspopup="dialog" :disabled="listLoading" @click="openPanel('runs')">切换运行 <span aria-hidden="true">⌄</span></button>
          <div class="defense-index"><FloatingIndex :groups="defenseDirectory" :active="returnIndex" :has-run="!!run" @navigate="navigate" /></div>
        </div>
      </div>

      <p v-if="missingLinkedRun && run" class="notice warning">指定运行不可回放，已打开当前场景的可用记录。</p>
      <div v-if="listLoading || runLoading" class="defense-empty" role="status"><span class="loading-dot"></span><h2>正在读取{{ scenes[scene].title }}记录</h2></div>
      <div v-else-if="listError || loadError" class="defense-empty" role="alert">
        <h2>运行记录读取失败</h2><p>{{ listError || loadError }}</p>
        <button class="button secondary" @click="listError ? loadRuns() : selectRun(selectedId)">重新读取</button>
      </div>
      <div v-else-if="!run" class="defense-empty"><h2>未加载可用运行</h2><p>将已有的实验结果放入 results 后刷新列表。</p><button class="button secondary" @click="loadRuns">刷新结果</button></div>
      <div v-else :key="run.id" class="defense-scene-body">
        <div class="defense-description">
          <p class="defense-result-label">本场结果 <span v-if="run.status !== 'success'" class="status-badge" :class="run.status">{{ statusLabels[run.status] }}</span></p>
          <dl class="defense-facts" aria-label="运行参数">
            <div v-for="item in metadata" :key="item.label" :title="item.title"><dt>{{ item.label }}</dt><dd>{{ item.value }}</dd></div>
          </dl>
        </div>
        <div v-if="run.summary?.error" class="notice error" role="alert">{{ run.summary.error }}</div>
        <dl class="defense-readings" aria-label="本场最终读数">
          <div v-for="reading in readings" :key="reading.label" :data-tone="reading.tone">
            <dt>{{ reading.label }}</dt>
            <dd><strong :class="{ 'missing-reading': reading.value === '未记录', 'long-reading': reading.value.length > 9 }">{{ reading.value }}</strong><span v-if="reading.value !== '未记录' && reading.unit">{{ reading.unit }}</span></dd>
            <p>{{ reading.note }}</p>
          </div>
        </dl>

        <div v-if="eventError" class="notice error" role="alert"><p>事件读取失败。{{ eventError }}</p><button class="table-link" @click="selectRun(selectedId)">重新读取</button></div>
        <div v-else-if="log.issues.length" class="notice warning">{{ log.issues.length }} 行事件无法解析，可在原文中核对。</div>
        <div class="defense-layout">
          <section class="defense-card defense-figure" aria-label="随游标变化的实验图">
            <header class="defense-card-heading">
              <h2>{{ visual === 'metrics' ? '变更窗口' : '一致性哈希环' }}</h2>
              <nav v-if="scene === 'expansion' || hasMetrics" class="defense-card-tabs" aria-label="图表视图">
                <button :aria-pressed="visual === 'ring'" @click="visual = 'ring'">记录的环</button>
                <button v-if="scene === 'expansion'" :aria-pressed="visual === 'mechanism'" @click="visual = 'mechanism'">机制示意</button>
                <button v-if="hasMetrics" :aria-pressed="visual === 'metrics'" @click="visual = 'metrics'">指标</button>
              </nav>
              <span v-else-if="snapshot" class="defense-snapshot-tag">实测快照</span>
            </header>
            <div class="defense-figure-body">
              <DefenseWindowMetrics v-if="visual === 'metrics'" :seen="seen" :records="replay.records" :marks="marks"
                :start="bounds.start" :end="bounds.end" :origin="sourceOrigin" :cursor="cursor"
                :axis-label="scene === 'fault' ? '自故障起算（s）' : '自扩容开始（s）'" />
              <DefenseRing v-else :model="snapshot?.model ?? null" :previous="earlierRing" :victim="victim" :mechanism="visual === 'mechanism' ? mechanism : undefined" />
            </div>
            <footer class="defense-card-footer">
              <template v-if="visual === 'mechanism'">
                <span>K 的哈希位置固定</span>
                <div class="defense-card-tabs" aria-label="机制示意阶段">
                  <button :aria-pressed="mechanism === 'before'" @click="mechanismOverride = 'before'">加入前</button>
                  <button :aria-pressed="mechanism === 'after'" @click="mechanismOverride = 'after'">加入后</button>
                </div>
              </template>
              <span v-else-if="visual === 'metrics'">{{ config.mode === 'scaling' ? '窗口 p99 取采样时所在阶段，缺失处断开。' : '竖线标注变更事件，缺失窗口断开。' }}</span>
              <template v-else>
                <span :class="{ 'snapshot-stale': missingTargetRing || (publishedEpoch && publishedEpoch !== snapshot?.model.epoch) }">{{ ringStatus }}</span>
                <button v-if="topologyRecords.length" class="table-link" aria-haspopup="dialog" @click="openConfig('topology')">快照详情 ↗</button>
              </template>
            </footer>
          </section>

          <section id="defense-evidence" class="defense-card defense-evidence" aria-label="阶段证据" tabindex="-1">
            <header class="defense-card-heading">
              <div class="defense-card-tabs evidence-tabs" aria-label="回放证据">
                <button :aria-pressed="evidence === 'stage'" @click="evidence = 'stage'; returnIndex = 'defense-current'">本阶段</button>
                <button :aria-pressed="evidence === 'feed'" @click="evidence = 'feed'; returnIndex = 'defense-feed'">事件进程</button>
              </div>
              <span v-if="activeStage" class="defense-stage-counter">{{ stageIndex + 1 }} / {{ stages.length }} 阶段</span>
            </header>
            <div v-if="evidence === 'stage'" class="defense-evidence-body">
              <article v-if="activeStage" :key="activeStage.event.line" class="defense-stage-reading" :data-tone="activeStage.tone">
                <div class="defense-stage-time"><i aria-hidden="true"></i><time>{{ activeStage.elapsed < 0 ? '−' : '+' }}{{ seconds(Math.abs(activeStage.elapsed)) }} s</time><span>{{ scene === 'fault' ? '自故障起算' : '相对扩容开始' }}</span></div>
                <h2>{{ activeStage.title }}</h2>
                <p>{{ activeStage.note }}</p>
                <dl v-if="activeStage.facts.length" class="defense-stage-facts">
                  <div v-for="fact in activeStage.facts" :key="fact.label">
                    <dt>{{ fact.label }}</dt><dd><button v-if="fact.source" class="table-link" :aria-label="fact.label + ' · 查看事件第 ' + fact.source.line + ' 行'" @click="inspect(fact.source)">{{ fact.value }} ↗</button><template v-else>{{ fact.value }}</template></dd>
                  </div>
                </dl>
              </article>
              <article v-else-if="currentEvent" class="defense-stage-reading">
                <div class="defense-stage-time"><time>{{ relativeEventTime(currentEvent.unix_ms, sourceOrigin) }}</time></div>
                <h2>{{ eventName(currentEvent.event) }}</h2><p>{{ eventSummary(currentEvent) || '此时间点尚未进入案例阶段。' }}</p>
              </article>
              <p v-else class="empty-inline">{{ log.missing ? '本场未找到 events.jsonl。' : log.events.length ? '游标尚未到达首条事件。' : '本场未记录可回放事件。' }}</p>
            </div>
            <div v-else class="defense-feed-body">
              <ReplayEventList :events="seen" :total="replay.records.length" :origin="sourceOrigin" :selected="currentEvent?.line" animate compact
                empty="当前游标没有可用事件。" @jump="jump" />
            </div>
            <footer class="defense-card-footer">
              <template v-if="evidence === 'stage' && activeStage">
                <span>{{ activeStage.eventName }} · #{{ activeStage.event.line }}</span>
                <button class="table-link" aria-haspopup="dialog" @click="inspect(activeStage.event)">事件原文 ↗</button>
              </template>
              <template v-else-if="currentEvent">
                <span>{{ eventName(currentEvent.event) }} · #{{ currentEvent.line }}</span>
                <button class="table-link" aria-haspopup="dialog" @click="inspect(currentEvent)">事件原文 ↗</button>
              </template>
            </footer>
          </section>

          <section class="defense-transport" aria-label="阶段与回放控制">
            <div v-if="stages.length" ref="timeline" class="defense-stage-line" role="group" aria-label="阶段时间线">
              <button v-for="(stage, index) in stages" :key="stage.event.line" :aria-current="index === stageIndex ? 'step' : undefined" :data-reached="index <= stageIndex"
                @click="jump(stage.event)">
                <i aria-hidden="true"></i><span><strong>{{ stage.label }}</strong><time>{{ seconds(stage.elapsed) }} s</time></span>
              </button>
            </div>
            <p v-else class="defense-no-stages">该次运行未记录{{ scenes[scene].title }}的阶段事件。</p>
            <div v-if="replay.records.length" class="defense-transport-controls">
              <div class="defense-play-controls">
                <button class="button secondary defense-play" :disabled="!duration" @click="toggle">
                  <svg viewBox="0 0 16 16" aria-hidden="true"><path v-if="playing" d="M4 3h3v10H4zm5 0h3v10H9z" /><path v-else d="M5 2.5v11L13 8z" /></svg>
                  {{ playing ? '暂停' : cursor >= bounds.end && duration ? '重播' : '播放' }}
                </button>
                <select v-model="speed" aria-label="回放速度"><option v-for="value in [1, 2, 5, 10]" :key="value" :value="value">{{ value }}×</option></select>
              </div>
              <div class="defense-scrubber">
                <input class="replay-seek" type="range" aria-label="回放进度" :aria-valuetext="relativeEventTime(cursor, sourceOrigin)" :min="bounds.start" :max="bounds.end"
                  :value="cursor" :disabled="!duration" :style="{ '--playback-progress': (duration ? (cursor - bounds.start) / duration * 100 : 0) + '%' }"
                  step="1" @input="seek(Number(($event.target as HTMLInputElement).value))" />
                <output title="游标对应的事件时间">{{ relativeEventTime(cursor, sourceOrigin) }}</output>
              </div>
              <div class="defense-step-controls">
                <button class="button secondary" :disabled="stageIndex <= 0" @click="step(-1)"><span aria-hidden="true">←</span> 上一阶段</button>
                <button class="button primary" :disabled="stageIndex >= stages.length - 1" @click="step(1)">下一阶段 <span aria-hidden="true">→</span></button>
              </div>
            </div>
          </section>
        </div>
      </div>

      <nav class="defense-resources" aria-label="实验资料">
        <button aria-haspopup="dialog" @click="openReport('load')"><span>正式负载曲线</span><span aria-hidden="true">↗</span></button>
        <button aria-haspopup="dialog" @click="openReport('acceptance')"><span>验收对照</span><span aria-hidden="true">↗</span></button>
        <button aria-haspopup="dialog" :disabled="!run" @click="openConfig()"><span>运行配置与证据</span><span aria-hidden="true">↗</span></button>
        <button aria-haspopup="dialog" :disabled="!runs.length" @click="openPanel('compare')"><span>跨运行对比</span><span aria-hidden="true">↗</span></button>
      </nav>
    </main>

    <DetailWindow v-if="panel" :page-key="panel" :title="modalTitle" :subtitle="modalSubtitle" :wide="panel === 'compare'" :compact="panel === 'event' || panel === 'runs'" @close="panel = null">
      <template #navigation><FloatingIndex :groups="defenseDirectory" :active="activeIndex" :has-run="!!run" @navigate="navigate" /></template>
      <div v-if="panel === 'runs'" class="run-picker">
        <label class="search-field"><input v-model="pickerSearch" type="search" placeholder="搜索运行名称" aria-label="搜索答辩运行" /></label>
        <ul v-if="pickerRuns.length" class="run-list defense-picker-list">
          <li v-for="item in pickerRuns" :key="item.id">
            <button class="run-card" :class="{ active: item.id === selectedId }" :aria-pressed="item.id === selectedId" @click="missingLinkedRun = false; selectRun(item.id)">
              <span class="run-card-top"><span class="mode-label">{{ modeLabels[text(item.config.mode)] || text(item.config.mode) }}</span><span class="status-badge" :class="item.status"><i></i>{{ statusLabels[item.status] }}</span></span>
              <strong class="run-name">{{ item.name }}</strong>
              <span class="run-card-meta"><span>{{ item.source === 'demo' ? '内置实录' : '本地结果' }}</span><span>{{ fmt(item.config.key_count) }} 键</span><span>RF {{ text(item.config.desired_replication_factor) }}</span><span>{{ text(item.config.write_ack_policy) }}</span></span>
            </button>
          </li>
        </ul>
        <p v-else class="empty-inline">{{ candidateRuns.length ? '没有匹配的运行。' : '没有可用的该场景记录。' }}</p>
      </div>
      <DefenseReports v-else-if="panel === 'report'" :view="report" @view="report = $event" />
      <RunCompare v-else-if="panel === 'compare'" :runs="runs" :initial-id="selectedId" :initial-selection="compareDefaults" />
      <section v-else-if="panel === 'event' && sourceEvent" class="defense-event-source">
        <nav class="defense-evidence-links"><a :href="runBase + '/raw?file=events.jsonl'" class="button secondary" target="_blank" rel="noopener">打开完整 events.jsonl ↗</a></nav>
        <h3>事件字段</h3><pre class="source-view event-fields" tabindex="0" aria-label="事件字段">{{ JSON.stringify(sourceEvent.fields, null, 2) }}</pre>
        <details class="data-disclosure"><summary>JSONL 本行原文</summary><pre class="source-view" tabindex="0">{{ sourceEvent.raw }}</pre></details>
      </section>
      <section v-else-if="panel === 'config' && run" class="defense-run-evidence">
        <nav class="view-switch" aria-label="本场实验资料">
          <button :aria-pressed="configTab === 'parameters'" @click="configTab = 'parameters'">实验配置</button>
          <button :aria-pressed="configTab === 'topology'" @click="configTab = 'topology'">拓扑快照</button>
          <button :aria-pressed="configTab === 'raw'" @click="configTab = 'raw'">结果原文</button>
          <button :aria-pressed="configTab === 'logs'" @click="configTab = 'logs'">进程日志</button>
        </nav>
        <template v-if="configTab === 'parameters'">
          <div class="defense-evidence-links">
            <span>模式 {{ text(config.mode) }} · {{ number(run.manifest?.started_unix_ms) !== null ? absoluteEventTime(run.manifest!.started_unix_ms!) + ' 北京时间' : '未记录开始时间' }}</span>
            <a :href="opener" class="table-link">在工作台打开本场 →</a>
          </div>
          <details v-if="sampleCommand" class="data-disclosure"><summary>样例复跑命令</summary><pre class="source-view" tabindex="0">{{ sampleCommand }}</pre></details>
          <RunConfig :run="run" />
        </template>
        <template v-else-if="configTab === 'topology'">
          <p class="defense-evidence-links">{{ scene === 'expansion' && config.mode === 'correctness' ? '完整运行含扩容与缩容，快照按各自的记录时刻展示。' : '这里列出本场记录的全部完整拓扑。' }}</p>
          <TopologyView :run="run" :events="topologyRecords" :initial-line="snapshot?.event.line" />
        </template>
        <RunFiles v-else :key="configTab" :run-id="run.id" :kind="configTab" :demo="run.source === 'demo'" />
      </section>
    </DetailWindow>
  </div>
</template>
