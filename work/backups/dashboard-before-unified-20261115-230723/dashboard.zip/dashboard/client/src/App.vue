<script setup lang="ts">
import { computed, defineAsyncComponent, nextTick, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import DetailWindow from './components/DetailWindow.vue'
import RunOverview from './components/RunOverview.vue'
import RunFiles from './components/RunFiles.vue'
import RunTimeline from './components/RunTimeline.vue'
import RunConfig from './components/RunConfig.vue'
import RunCompare from './components/RunCompare.vue'
import RunReplay from './components/RunReplay.vue'
import RunTopology from './components/RunTopology.vue'
import FloatingIndex from './components/FloatingIndex.vue'
import RunExperiment from './components/RunExperiment.vue'
import type { Latency, RunDetail, RunListItem } from './types'
import { formatNumber as fmt, formatTime, modeLabels, number, object, request, shortName, stages, statusLabels, text } from './data'
import { directory, type DirectoryEntry, type Panel } from './navigation'
import { sceneFor } from './defense'

const DefenseView = defineAsyncComponent(() => import('./components/DefenseView.vue'))
const defense = new URLSearchParams(location.search).get('view') === 'defense'

const runs = ref<RunListItem[]>([])
const run = ref<RunDetail | null>(null)
const selectedId = ref('')
const selectedStage = ref('')
const search = ref('')
const mode = ref('all')
const status = ref('all')
const sort = ref('newest')
const listLoading = ref(true)
const detailLoading = ref(false)
const listError = ref('')
const detailError = ref('')
const panel = ref<Panel | null>(null)
const fileKind = ref<'raw' | 'logs'>('raw')
const views = reactive({ latency: 'curve', nodes: 'owned_keys', observations: 'throughput', config: 'parameters', compare: 'latency', topology: 'range', case: 'stages', replay: 'metrics' })
const comparePlot = ref('bar')
const compareRepeats = ref(false)
const directoryAnchor = ref('')
let anchorObserver: MutationObserver | undefined
let listController: AbortController | undefined
let detailController: AbortController | undefined

const panelTitles: Record<Panel, string> = { topology: '哈希环与拓扑', replay: '历史回放', compare: '跨运行对比', case: '案例分析', experiment: '运行实验', runs: '选择一次运行', latency: '延迟与速率', nodes: '节点负载', events: '事件时间线', config: '实验配置', observations: '其他观测', files: '文件与日志' }
const analysisModules = [
  { id: 'case', title: '案例分析', description: '阶段变化与导出图', path: 'M5 6h24v22H5zM10 22v-6m7 6V11m7 11v-8' },
  { id: 'compare', title: '运行对比', description: '同一指标并排看', path: 'M6 8h22M6 14h15M6 20h18M6 26h11' },
  { id: 'replay', title: '历史回放', description: '按时间重看实验', path: 'M5 14a12 12 0 1 1 0 7M5 7v7h7m3-3 9 6-9 6z' },
  { id: 'topology', title: '哈希环', description: '节点归属与迁移区间', path: 'M17 5a12 12 0 1 1-12 12A12 12 0 0 1 17 5Zm0 0v5m12 7h-5m-7 12v-5M5 17h5' },
] as const
const modules = [
  { id: 'latency', title: '延迟与速率', description: '阶段曲线、分位数与错误', path: 'M3 24h28M5 21l7-7 7 3 10-12M5 5v19' },
  { id: 'nodes', title: '节点负载', description: '键数、操作数与 CPU', path: 'M5 8h24M5 16h17M5 24h21M5 5v22' },
  { id: 'events', title: '事件时间线', description: '运行事件与原始字段', path: 'M8 5v22M15 7h14M15 16h10M15 25h14M5 7h6M5 16h6M5 25h6' },
  { id: 'config', title: '实验配置', description: '参数、源码与构建', path: 'M4 8h26M4 24h26M10 5v6M24 21v6M4 16h26M19 13v6' },
  { id: 'observations', title: '其他观测', description: '吞吐、空闲基线与压力', path: 'M5 24V13h5v11M15 24V6h5v18M25 24V17h5v7' },
  { id: 'files', title: '文件与日志', description: '原始结果与进程日志', path: 'M8 3h12l7 7v19H8zM20 3v8h7M12 17h10M12 22h8' },
] as const
const pageIndex = computed(() => directory.map(group => ({ ...group, items: group.items.map(item => ({ ...item,
  children: item.children?.filter(child => child.id !== 'case-stages' || rateStages.value.length > 0),
})) })))
const directoryActive = computed(() => {
  if (directoryAnchor.value) return directoryAnchor.value
  const parent = directory.flatMap(group => group.items).find(item => item.panel === panel.value)
  if (!parent) return 'overview'
  const view = panel.value === 'files' ? fileKind.value : views[panel.value as keyof typeof views]
  return parent.children?.find(item => !item.anchor && item.view === view && (!item.plot || item.plot === comparePlot.value))?.id ?? parent.id
})
const modes = computed(() => [...new Set(runs.value.map(item => text(item.config?.mode)).filter(value => value !== '未提供'))].sort())
const filteredRuns = computed(() => runs.value.filter(item => item.name.toLowerCase().includes(search.value.toLowerCase()) &&
  (mode.value === 'all' || item.config?.mode === mode.value) && (status.value === 'all' || item.status === status.value))
  .sort((a, b) => sort.value === 'name' ? a.name.localeCompare(b.name, 'zh-CN')
    : ((a.started_unix_ms ?? 0) - (b.started_unix_ms ?? 0)) * (sort.value === 'oldest' ? 1 : -1)))
const config = computed(() => object(run.value?.manifest?.config))
const defenseLink = computed(() => './?view=defense' +
  (run.value && sceneFor(config.value) ? '&run=' + encodeURIComponent(run.value.id) : ''))
const rateStages = computed(() => stages(run.value?.summary ?? null))
const currentEntry = computed(() => rateStages.value.find(([name]) => name === selectedStage.value) ?? rateStages.value[0])
const current = computed(() => currentEntry.value?.[1])
const rateScale = computed(() => Math.max(1, ...rateStages.value.map(([, value]) => Math.max(number(value.achieved_rate) ?? 0, number(value.target_rate) ?? 0))))
const latencyScale = computed(() => Math.max(1, ...rateStages.value.map(([, value]) => number(value.latency_us?.get?.p99) ?? 0)))
const hasRecordedErrors = computed(() => rateStages.value.some(([, value]) => Object.values(object(value.errors)).some(count => number(count) !== null && Number(count) > 0)))
const subtitle = computed(() => {
  if (panel.value === 'runs') return `${runs.value.length} 次本地运行`
  if (panel.value === 'experiment' || panel.value === 'compare') return undefined
  return run.value?.id
})
function latency(op: string): Latency { return object(object(current.value?.latency_us)[op]) as Latency }

async function navigate(entry: DirectoryEntry, keyboard: boolean) {
  anchorObserver?.disconnect()
  directoryAnchor.value = ''
  const previousPanel = panel.value
  panel.value = entry.panel
  if (entry.view && entry.panel === 'files') fileKind.value = entry.view as 'raw' | 'logs'
  else if (entry.view && entry.panel && entry.panel in views) views[entry.panel as keyof typeof views] = entry.view
  if (entry.plot) comparePlot.value = entry.plot
  if (entry.id === 'compare-repeat') compareRepeats.value = true
  await nextTick()
  directoryAnchor.value = entry.anchor ? entry.id : ''
  const body = document.querySelector<HTMLElement>('.window-body')
  if (!entry.panel) {
    document.getElementById('overview')?.focus({ preventScroll: true })
    window.scrollTo({ top: 0, behavior: keyboard || matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })
    return
  }
  if (!body) return
  if (!entry.anchor) {
    if (previousPanel === entry.panel) body.scrollTo({ top: 0, behavior: 'instant' })
    if (keyboard) document.getElementById('window-title')?.focus({ preventScroll: true })
    return
  }
  const go = () => {
    const section = body.querySelector<HTMLElement>('#' + entry.anchor)
    if (!section) return
    anchorObserver?.disconnect()
    if (entry.anchor === 'playback-source') section.querySelector('details')?.setAttribute('open', '')
    body.scrollTo({ top: body.scrollTop + section.getBoundingClientRect().top - body.getBoundingClientRect().top - 12,
      behavior: keyboard || matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })
    section.focus({ preventScroll: true })
  }
  anchorObserver = new MutationObserver(go)
  anchorObserver.observe(body, { childList: true, subtree: true })
  go()
}

watch(panel, () => { anchorObserver?.disconnect(); directoryAnchor.value = '' })
watch(() => Object.values(views), () => { directoryAnchor.value = '' })

async function selectRun(id: string) {
  panel.value = null
  detailController?.abort()
  detailController = new AbortController()
  const signal = detailController.signal
  selectedId.value = id
  sessionStorage.setItem('hashring.workbench.run', id)
  selectedStage.value = ''
  run.value = null
  detailError.value = ''
  detailLoading.value = true
  const url = new URL(location.href)
  url.searchParams.set('run', id)
  history.replaceState(null, '', url)
  try {
    run.value = await request<RunDetail>(`/api/runs/${encodeURIComponent(id)}`, signal)
    views.case = stages(run.value.summary).length ? 'stages' : 'metrics'
    views.observations = ['scaling', 'fault', 'availability', 'correctness'].includes(text(run.value.manifest?.config?.mode)) ? 'structured' : 'throughput'
  }
  catch (failure) { if (!signal.aborted) detailError.value = failure instanceof Error ? failure.message : String(failure) }
  finally { if (!signal.aborted) detailLoading.value = false }
}
async function loadRuns() {
  listController?.abort()
  listController = new AbortController()
  const signal = listController.signal
  listLoading.value = true
  listError.value = ''
  try {
    const wanted = selectedId.value || new URLSearchParams(location.search).get('run')
    const response = await request<{ runs: RunListItem[] }>('/api/runs' + (wanted?.startsWith('@demo/') ? '?include=demo' : ''), signal)
    runs.value = response.runs
    const next = runs.value.find(item => item.id === wanted)?.id ?? runs.value[0]?.id
    if (next) await selectRun(next)
    else { detailController?.abort(); selectedId.value = ''; run.value = null; detailLoading.value = false; detailError.value = '' }
  } catch (failure) { if (!signal.aborted) listError.value = failure instanceof Error ? failure.message : String(failure) }
  finally { if (!signal.aborted) listLoading.value = false }
}
async function openExperimentResult(id: string) {
  selectedId.value = id
  panel.value = null
  await loadRuns()
}
onMounted(() => {
  if (defense) document.title = 'hashring-rs · 答辩演示'
  else void loadRuns()
})
onBeforeUnmount(() => { listController?.abort(); detailController?.abort(); anchorObserver?.disconnect() })
</script>

<template>
  <DefenseView v-if="defense" />
  <div v-else class="app-shell">
    <header class="topbar">
      <h1 class="brand"><svg class="brand-mark" viewBox="0 0 36 36" fill="none" aria-hidden="true"><circle cx="18" cy="18" r="12" stroke="currentColor" stroke-width="1.2"/><circle cx="18" cy="6" r="3" fill="var(--accent)"/><circle cx="28.4" cy="24" r="2.6" fill="var(--teal)"/><circle cx="7.6" cy="24" r="2.6" fill="var(--gold)"/><circle cx="18" cy="18" r="2" fill="currentColor"/></svg><span>hashring-rs <small>实验工作台</small></span></h1>
      <div class="heading-actions">
        <span class="local-indicator"><i></i>本地结果</span>
        <a class="button secondary defense-entry" :href="defenseLink">答辩演示 <span aria-hidden="true">↗</span></a>
        <button class="button secondary" aria-haspopup="dialog" @click="panel = 'runs'">切换运行 <span class="count">{{ runs.length }}</span></button>
        <button class="button icon-button" :disabled="listLoading" aria-label="刷新结果" @click="loadRuns"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M16 7a6.5 6.5 0 1 0 .4 5M16 3v4h-4" /></svg></button>
        <button class="button primary" aria-haspopup="dialog" @click="panel = 'experiment'">运行实验</button>
      </div>
    </header>
    <main class="workbench">
      <div v-if="listError && run" class="notice error" role="alert"><p>{{ listError }}</p><button class="table-link" @click="loadRuns">重试读取</button></div>
      <section id="overview" class="main-result" aria-label="运行概览" tabindex="-1" :aria-busy="detailLoading">
        <div v-if="detailLoading || (listLoading && !run)" class="empty-block" role="status"><span class="loading-dot"></span><h2>正在读取运行结果</h2></div>
        <div v-else-if="listError && !run" class="empty-block" role="alert"><h2>结果列表读取失败</h2><p>{{ listError }}</p><button class="button primary" @click="loadRuns">重试读取</button></div>
        <div v-else-if="detailError" class="empty-block" role="alert"><h2>运行结果读取失败</h2><p>{{ detailError }}</p><button class="button primary" @click="selectRun(selectedId)">重新读取</button></div>
        <template v-else-if="run">
          <div v-if="run.status === 'failed' || run.summary?.error" class="notice error" role="alert"><p><strong>实验失败</strong><span>{{ run.summary?.error || '结果标记为失败，未提供原因。' }}</span></p></div>
          <div v-if="run.status === 'incomplete'" class="notice neutral"><p>结果尚不完整，无法判断最终成功与否。已记录的信息仍可展开查看。</p></div>
          <div class="result-hero">
            <div class="result-story">
              <div class="detail-kicker"><span class="mode-label">{{ text(config.mode) }}</span><span class="status-badge" :class="run.status"><i></i>{{ statusLabels[run.status] }}</span></div>
              <h2>{{ modeLabels[text(config.mode)] || '运行结果' }}</h2>
              <p class="hero-date"><span>{{ formatTime(run.manifest?.started_unix_ms) }} 北京时间</span><span>耗时 {{ fmt(run.summary?.elapsed_seconds, 2) }} s</span></p>
              <div v-if="rateStages.length" class="hero-readings" :key="run.id + currentEntry?.[0]">
                <div><span>实际成功速率</span><strong>{{ fmt(current?.achieved_rate, 2) }}<small>ops/s</small></strong><p>目标 {{ fmt(current?.target_rate) }} · 正式 {{ fmt(current?.seconds, 2) }} s</p></div>
                <div><span>GET p99</span><strong>{{ fmt(latency('get').p99) }}<small>µs</small></strong><p>{{ fmt(latency('get').samples) }} 个样本 · 不含预热</p></div>
              </div>
            </div>
            <section v-if="rateStages.length" class="stage-preview" aria-label="选择阶段">
              <div class="preview-heading">
                <h3>负载阶梯</h3>
                <button class="preview-link" aria-haspopup="dialog" @click="panel = 'latency'">查看完整曲线 <span aria-hidden="true">›</span></button>
              </div>
                <div class="stage-columns" aria-hidden="true"><span>目标档位</span><span><i class="rate-key"></i>实际速率 <small>ops/s</small></span><span><i class="latency-key"></i>GET p99 <small>µs</small></span></div>
                <button v-for="([name, value], index) in rateStages.slice(0, 4)" :key="run.id + name" class="stage-preview-row" :aria-pressed="currentEntry?.[0] === name" @click="selectedStage = name">
                  <span class="stage-target"><span class="stage-selection" aria-hidden="true"></span><strong>{{ fmt(value.target_rate) }}</strong><small>ops/s</small></span>
                  <span class="stage-measure rate-measure"><strong>{{ fmt(value.achieved_rate, 2) }}</strong><span class="sr-only">ops/s 实际成功速率</span><span class="stage-track" aria-hidden="true"><i :style="{ width: ((number(value.achieved_rate) ?? 0) / rateScale * 100) + '%', animationDelay: (index * 55) + 'ms' }"></i></span></span>
                  <span class="stage-measure latency-measure"><strong>{{ fmt(value.latency_us?.get?.p99, 2) }}</strong><span class="sr-only">µs GET p99</span><span class="stage-track" aria-hidden="true"><i :style="{ width: ((number(value.latency_us?.get?.p99) ?? 0) / latencyScale * 100) + '%', animationDelay: (index * 55) + 'ms' }"></i></span></span>
                </button>
                <p v-if="rateStages.length > 4" class="stage-note">其余 {{ rateStages.length - 4 }} 档见完整曲线。</p>
            </section>
            <section v-else class="stage-preview" aria-label="运行详情">
              <div class="preview-heading">
                <h3>运行详情</h3>
                <button class="preview-link" aria-haspopup="dialog" @click="panel = 'case'">查看案例 <span aria-hidden="true">›</span></button>
              </div>
              <div class="run-detail-links">
                <button class="button secondary" aria-haspopup="dialog" @click="panel = 'replay'">历史回放</button>
                <button class="button secondary" aria-haspopup="dialog" @click="panel = 'observations'">运行观测</button>
              </div>
            </section>
          </div>
          <dl class="hero-facts">
            <div><dt>节点</dt><dd>{{ fmt(config.node_count) }}</dd></div>
            <div><dt>副本数 RF</dt><dd>{{ fmt(config.desired_replication_factor) }}</dd></div>
            <div><dt>写入确认 ACK</dt><dd>{{ text(config.write_ack_policy) }}</dd></div>
            <div><dt>键数</dt><dd>{{ fmt(config.key_count) }}</dd></div>
            <div><dt>值大小</dt><dd>{{ fmt(config.value_bytes) }} <small>B</small></dd></div>
            <div v-if="config.virtual_nodes !== undefined"><dt>虚拟位置 / 节点</dt><dd>{{ fmt(config.virtual_nodes) }}</dd></div>
          </dl>
          <div class="result-context"><p>{{ run.id }}</p><div><button v-if="run.manifest?.source_reproducible === false" class="context-warning" aria-haspopup="dialog" @click="panel = 'config'">源码可复现性待核对</button><button v-if="run.warnings.length" class="context-warning" aria-haspopup="dialog" @click="panel = 'config'">{{ run.warnings.length }} 项文件提示</button><button v-if="hasRecordedErrors" class="context-warning" aria-haspopup="dialog" @click="panel = 'latency'">部分阶段有错误记录</button></div></div>
          <div v-if="current?.sender_saturated === true" class="notice warning" role="status">发送端未跟上计划。本阶段不能按目标负载解释为集群表现。</div>
        </template>
        <div v-else class="empty-block"><div class="empty-ring" aria-hidden="true"></div><h2>从一次运行开始</h2><p>当前没有可读取的实验结果。将已有结果目录放入 results 后刷新。</p><button class="button secondary" @click="loadRuns">刷新结果</button></div>
      </section>
      <template v-if="run && !detailLoading">
        <div class="workbench-links">
          <section id="analysis" class="workbench-section" tabindex="-1" aria-labelledby="analysis-title">
            <h2 id="analysis-title">分析与演示</h2>
            <div class="module-grid analysis-grid"><button v-for="item in analysisModules" :key="item.id" class="module-card" aria-haspopup="dialog" @click="panel = item.id"><svg viewBox="0 0 34 34" aria-hidden="true"><path :d="item.path" /></svg><span><strong>{{ item.title }}</strong><span class="module-description">{{ item.description }}</span></span><span class="module-arrow" aria-hidden="true">›</span></button></div>
          </section>
          <section id="records" class="workbench-section" tabindex="-1" aria-labelledby="records-title">
            <h2 id="records-title">运行记录</h2>
            <div class="module-grid record-grid"><button v-for="item in modules" :key="item.id" class="module-card" aria-haspopup="dialog" @click="panel = item.id; fileKind = 'raw'"><svg viewBox="0 0 34 34" aria-hidden="true"><path :d="item.path" /></svg><span><strong>{{ item.title }}</strong><span class="module-description">{{ item.description }}</span></span><span class="module-arrow" aria-hidden="true">›</span></button></div>
          </section>
        </div>
      </template>
      <footer class="page-footer">数据来自本地实验记录。缺失项以 — 表示。</footer>
    </main>
    <FloatingIndex v-if="!panel" :groups="pageIndex" :active="directoryActive" :has-run="!!run && !detailLoading" @navigate="navigate" />
    <DetailWindow v-if="panel" :page-key="panel" :title="panelTitles[panel]" :subtitle="subtitle" :compact="panel === 'runs'" :wide="['replay', 'case', 'experiment'].includes(panel)" @close="panel = null">
      <template #navigation><FloatingIndex :groups="pageIndex" :active="directoryActive" :has-run="!!run && !detailLoading" @navigate="navigate" /></template>
      <template #default>
      <div v-if="panel === 'runs'" class="run-picker">
        <label class="search-field"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5.5"/><path d="m13 13 4 4"/></svg><input v-model="search" type="search" placeholder="搜索运行名称" aria-label="搜索运行名称" /></label>
        <div class="filter-row"><select v-model="mode" aria-label="筛选实验模式"><option value="all">全部模式</option><option v-for="item in modes" :key="item" :value="item">{{ item }}</option></select><select v-model="status" aria-label="筛选运行状态"><option value="all">全部状态</option><option value="success">成功</option><option value="failed">失败</option><option value="incomplete">未完成</option></select></div>
        <div class="list-sort"><span>{{ filteredRuns.length }} 次运行</span><select v-model="sort" aria-label="运行排序"><option value="newest">最新优先</option><option value="oldest">最早优先</option><option value="name">名称排序</option></select></div>
        <div v-if="listError" class="notice error" role="alert"><p>{{ listError }}</p><button class="table-link" @click="loadRuns">重试读取</button></div>
        <div v-else-if="!filteredRuns.length" class="sidebar-empty"><strong>{{ runs.length ? '没有匹配的运行' : '还没有实验结果' }}</strong><p>试试其他名称或筛选条件，或者刷新结果。</p><button v-if="runs.length" class="table-link" @click="search = ''; mode = 'all'; status = 'all'">清除筛选</button></div>
        <ul v-else class="run-list">
          <li v-for="item in filteredRuns" :key="item.id">
            <button class="run-card" :class="{ active: item.id === selectedId }" :aria-pressed="item.id === selectedId" @click="selectRun(item.id)">
              <span class="run-card-top"><span class="mode-label">{{ text(item.config?.mode) }}</span><span class="status-badge" :class="item.status"><i></i>{{ statusLabels[item.status] }}</span></span>
              <strong class="run-name">{{ shortName(item.name) }}</strong>
              <span class="run-date">{{ formatTime(item.started_unix_ms) }}</span>
              <span class="run-card-meta">
                <span v-if="item.source === 'demo'">内置实录</span>
                <span>{{ fmt(item.config?.key_count) }} 键</span>
                <span>{{ fmt(item.config?.node_count) }} 节点</span>
                <span>RF {{ fmt(item.config?.desired_replication_factor) }}</span>
                <span>ACK {{ text(item.config?.write_ack_policy) }}</span>
                <span>{{ fmt(item.elapsed_seconds, 2) }} s</span>
              </span>
              <span v-if="item.warnings.length" class="text-warning">部分文件读取异常</span>
            </button>
          </li>
        </ul>
        <p class="sidebar-footnote">开始时间均为北京时间。</p>
      </div>
      <RunExperiment v-else-if="panel === 'experiment'" @result="openExperimentResult" />
      <template v-else-if="run">
        <RunCompare v-if="panel === 'compare'" v-model:view="views.compare" v-model:plot="comparePlot" v-model:group-repeats="compareRepeats" :runs="runs" :initial-id="selectedId" />
        <RunReplay v-else-if="panel === 'replay' || panel === 'case'" v-model:view="views[panel]" :run="run" :case-study="panel === 'case'" />
        <RunTopology v-else-if="panel === 'topology'" v-model:view="views.topology" :run="run" />
        <RunOverview v-else-if="panel === 'latency' || panel === 'nodes' || panel === 'observations'" v-model:view="views.latency" v-model:observation-view="views.observations" v-model:load-metric="views.nodes" :run="run" :section="panel" :stage="currentEntry?.[0] ?? ''" @select-stage="selectedStage = $event" />
        <RunTimeline v-else-if="panel === 'events'" :run="run" />
        <RunConfig v-else-if="panel === 'config'" v-model:view="views.config" :run="run" />
        <template v-else-if="panel === 'files'"><nav class="view-switch" aria-label="文件内容"><button :aria-pressed="fileKind === 'raw'" @click="fileKind = 'raw'">原始结果</button><button :aria-pressed="fileKind === 'logs'" @click="fileKind = 'logs'">进程日志</button></nav><RunFiles :key="fileKind" :run-id="run.id" :kind="fileKind" :demo="run.source === 'demo'" /></template>
      </template>
      </template>
    </DetailWindow>
  </div>
</template>

