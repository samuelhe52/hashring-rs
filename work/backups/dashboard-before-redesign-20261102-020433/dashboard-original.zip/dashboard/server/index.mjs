import http from 'node:http'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createStore } from './store.mjs'

const dashboard = fileURLToPath(new URL('..', import.meta.url))

function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff' })
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body)
}

export async function createDashboardServer({ resultsRoot = process.env.RESULTS_DIR || path.join(dashboard, '../results'), dev = false } = {}) {
  const store = createStore(resultsRoot)
  const vite = dev ? await (await import('vite')).createServer({
    configFile: path.join(dashboard, 'vite.config.ts'),
    server: { middlewareMode: true }, appType: 'spa',
  }) : null
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost')
      if (url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET') return send(res, 405, { error: '当前版本仅支持读取结果' })
        if (url.pathname === '/api/runs') return send(res, 200, { runs: await store.listRuns() })
        if (url.pathname === '/api/guide') return send(res, 200, await readFile(path.join(dashboard, 'LEARNING.md'), 'utf8'), 'text/plain; charset=utf-8')
        const route = /^\/api\/runs\/([^/]+)(?:\/(raw|logs|events))?$/.exec(url.pathname)
        if (!route) return send(res, 404, { error: '接口不存在' })
        let id
        try { id = decodeURIComponent(route[1]) }
        catch { return send(res, 400, { error: '运行名称编码无效' }) }
        if (route[2] === 'events') return send(res, 200, await store.events(id))
        if (route[2] === 'raw') {
          const filename = url.searchParams.get('file')
          const content = await store.rawFile(id, filename)
          if (url.searchParams.get('download') === '1') res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`)
          return send(res, 200, content, 'text/plain; charset=utf-8')
        }
        if (route[2] === 'logs') {
          const process = url.searchParams.get('process')
          const content = await store.logs(id, process)
          if (process && url.searchParams.get('download') === '1') res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(process)}`)
          return send(res, 200, content, process ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8')
        }
        return send(res, 200, await store.readRun(id))
      }
      if (vite) return vite.middlewares(req, res)
      const file = url.pathname.startsWith('/assets/')
        ? path.join(dashboard, 'dist', 'assets', path.basename(url.pathname))
        : path.join(dashboard, 'dist/index.html')
      const content = await readFile(file)
      const mime = { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }
      res.writeHead(200, { 'Content-Type': `${mime[path.extname(file)] || 'application/octet-stream'}; charset=utf-8` })
      res.end(content)
    } catch (error) {
      send(res, error.status ?? (error.code === 'ENOENT' ? 404 : 500), { error: error.message })
    }
  })

  return {
    server,
    async close() {
      await vite?.close()
      await new Promise(resolve => server.close(resolve))
    },
  }
}

// 被测试文件 import 时不启动端口；直接执行此文件时才启动本地服务。
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const app = await createDashboardServer({ dev: process.argv.includes('--dev') })
  app.server.listen(Number(process.env.PORT || 4173), '127.0.0.1', () => {
    console.log('Hashring Dashboard: http://localhost:' + app.server.address().port)
    console.log('读取实验目录: ' + path.resolve(process.env.RESULTS_DIR || path.join(dashboard, '../results')))
  })
  app.server.on('error', async error => { console.error(error.message); process.exitCode = 1; await app.close() })
  process.once('SIGINT', () => app.close())
  process.once('SIGTERM', () => app.close())
}
