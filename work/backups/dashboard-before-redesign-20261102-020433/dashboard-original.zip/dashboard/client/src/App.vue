<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import RunOverview from './components/RunOverview.vue'
import RunFiles from './components/RunFiles.vue'
import RunTimeline from './components/RunTimeline.vue'
import type { RunDetail, RunListItem } from './types'
import { fieldNames, formatNumber as fmt, formatTime, object, request, shortName, statusLabels, text } from './data'

const runs = ref<RunListItem[]>([])
const run = ref<RunDetail | null>(null)
const selectedId = ref('')
const search = ref('')
const mode = ref('all')
const status = ref('all')
const sort = ref('newest')
const listLoading = ref(true)
const detailLoading = ref(false)
const listError = ref('')
const detailError = ref('')
const activeTab = ref('overview')
const configSearch = ref('')
let listController: AbortController | undefined
let detailController: AbortController | undefined

const modes = computed(() => [...new Set(runs.value.map(item => text(item.config?.mode)).filter(value => value !== '未提供'))].sort())
const filteredRuns = computed(() => runs.value.filter(item =>
  item.name.toLowerCase().includes(search.value.toLowerCase()) &&
  (mode.value === 'all' || item.config?.mode === mode.value) &&
  (status.value === 'all' || item.status === status.value))
  .sort((a, b) => sort.value === 'name' ? a.name.localeCompare(b.name, 'zh-CN')
    : ((a.started_unix_ms ?? 0) - (b.started_unix_ms ?? 0)) * (sort.value === 'oldest' ? 1 : -1)))
const config = computed(() => object(run.value?.manifest?.config))
const build = computed(() => object(run.value?.manifest?.build))
const configEntries = computed(() => Object.entries(config.value).filter(([key, value]) =>
  `${key} ${fieldNames[key] || ''} ${text(value)}`.toLowerCase().includes(configSearch.value.toLowerCase())))
const tabs = [{ id: 'overview', name: '结果概览' }, { id: 'events', name: '事件时间线' }, { id: 'config', name: '实验配置' }, { id: 'raw', name: '原始文件' }, { id: 'logs', name: '进程日志' }]

async function selectRun(id: string) {
  detailController?.abort()
  detailController = new AbortController()
  const signal = detailController.signal
  selectedId.value = id
  run.value = null
  detailError.value = ''
  detailLoading.value = true
  activeTab.value = 'overview'
  configSearch.value = ''
  const url = new URL(location.href)
  url.searchParams.set('run', id)
  history.replaceState(null, '', url)
  try { run.value = await request<RunDetail>(`/api/runs/${encodeURIComponent(id)}`, signal) }
  catch (failure) { if (!signal.aborted) detailError.value = failure instanceof Error ? failure.message : String(failure) }
  finally { if (!signal.aborted) detailLoading.value = false }
}

async function loadRuns() {
  listController?.abort()
  listController = new AbortController()
  const signal = listController.signal
  listLoading.value = true
  listError.value = ''
  try {
    const response = await request<{ runs: RunListItem[] }>('/api/runs', signal)
    runs.value = response.runs
    const wanted = selectedId.value || new URLSearchParams(location.search).get('run')
    const next = runs.value.find(item => item.id === wanted)?.id ?? runs.value[0]?.id
    if (next) await selectRun(next)
    else { detailController?.abort(); selectedId.value = ''; run.value = null; detailLoading.value = false; detailError.value = '' }
  } catch (failure) { if (!signal.aborted) listError.value = failure instanceof Error ? failure.message : String(failure) }
  finally { if (!signal.aborted) listLoading.value = false }
}

onMounted(loadRuns)
onBeforeUnmount(() => { listController?.abort(); detailController?.abort() })
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <a class="brand" href="/" aria-label="Hashring 实验结果首页">
        <svg class="brand-mark" viewBox="0 0 36 36" fill="none" aria-hidden="true"><circle cx="18" cy="18" r="12" stroke="currentColor" stroke-width="1.2"/><circle cx="18" cy="6" r="3" fill="var(--accent)"/><circle cx="28.4" cy="24" r="2.6" fill="var(--teal)"/><circle cx="7.6" cy="24" r="2.6" fill="var(--gold)"/><circle cx="18" cy="18" r="2" fill="currentColor"/></svg>
        <span>hashring<span class="brand-suffix">-rs</span></span>
      </a>
      <span class="topbar-section">实验工作台</span>
      <div class="topbar-right"><span class="local-indicator"><i></i>本地结果</span><a href="/api/guide" target="_blank" rel="noopener">学习文档 <span aria-hidden="true">↗</span></a></div>
    </header>

    <main>
      <div class="page-heading"><div><h1>实验结果</h1><p>查看配置，读懂每一次运行。</p></div><button class="button secondary refresh-button" :disabled="listLoading" @click="loadRuns"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M16 7a6.5 6.5 0 1 0 .4 5M16 3v4h-4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ listLoading ? '正在读取' : '刷新结果' }}</button></div>

      <div class="workspace">
        <aside class="runs-sidebar" aria-label="实验运行列表">
          <div class="sidebar-heading"><h2>全部运行</h2><span class="count">{{ runs.length }}</span></div>
          <label class="search-field"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5.5"/><path d="m13 13 4 4"/></svg><input v-model="search" type="search" placeholder="搜索运行名称" aria-label="搜索运行名称" /></label>
          <div class="filter-row"><select v-model="mode" aria-label="筛选实验模式"><option value="all">全部模式</option><option v-for="item in modes" :key="item" :value="item">{{ item }}</option></select><select v-model="status" aria-label="筛选运行状态"><option value="all">全部状态</option><option value="success">成功</option><option value="failed">失败</option><option value="incomplete">未完成</option></select></div>
          <div class="list-sort"><span>{{ filteredRuns.length }} 次运行</span><select v-model="sort" aria-label="运行排序"><option value="newest">最新优先</option><option value="oldest">最早优先</option><option value="name">名称排序</option></select></div>
          <div v-if="listError" class="notice error" role="alert"><p>{{ listError }}</p><button class="table-link" @click="loadRuns">重试读取</button></div>
          <div v-else-if="listLoading && !runs.length" class="empty-inline" role="status">正在查找运行结果……</div>
          <div v-else-if="!filteredRuns.length" class="sidebar-empty"><strong>{{ runs.length ? '没有匹配的运行' : '还没有实验结果' }}</strong><p>{{ runs.length ? '试试其他名称或筛选条件。' : '将已有实验的完整结果目录放入 results，再刷新列表。' }}</p><button v-if="runs.length" class="table-link" @click="search = ''; mode = 'all'; status = 'all'">清除筛选</button></div>
          <ul v-else class="run-list"><li v-for="item in filteredRuns" :key="item.id"><button class="run-card" :class="{ active: item.id === selectedId }" :aria-pressed="item.id === selectedId" @click="selectRun(item.id)">
            <span class="run-card-top"><span class="mode-label">{{ text(item.config?.mode) }}</span><span class="status-badge" :class="item.status"><i></i>{{ statusLabels[item.status] }}</span></span>
            <strong class="run-name">{{ shortName(item.name) }}</strong><span class="run-date">{{ formatTime(item.started_unix_ms) }}</span>
            <span class="run-card-meta"><span>{{ fmt(item.config?.node_count) }} 节点</span><span>RF {{ fmt(item.config?.desired_replication_factor) }}</span><span>{{ fmt(item.elapsed_seconds, 2) }} s</span></span>
            <span class="run-card-policy">{{ text(item.config?.write_ack_policy) }}<span>{{ fmt(item.config?.key_count) }} 键</span></span>
            <span v-if="item.warnings.length" class="text-warning">部分文件读取异常</span>
          </button></li></ul>
          <p class="sidebar-footnote">开始时间均为北京时间。</p>
        </aside>

        <section class="detail-area" aria-label="运行详情" :aria-busy="detailLoading">
          <div v-if="detailLoading" class="empty-block loading-block" role="status"><span class="loading-dot"></span><h2>正在读取运行结果</h2><p>稍后即可查看配置与指标。</p></div>
          <div v-else-if="detailError" class="empty-block" role="alert"><h2>运行结果读取失败</h2><p>{{ detailError }}</p><button class="button primary" @click="selectRun(selectedId)">重新读取</button></div>
          <template v-else-if="run">
            <header class="run-detail-heading"><div><div class="detail-kicker"><span>{{ text(config.mode) }}</span><span class="status-badge" :class="run.status"><i></i>{{ statusLabels[run.status] }}</span></div><h2>{{ shortName(run.name) }}</h2><p class="run-full-id">{{ run.id }}</p></div><div class="run-timing"><span>{{ formatTime(run.manifest?.started_unix_ms) }}</span><span>总耗时 <b>{{ fmt(run.summary?.elapsed_seconds, 2) }}</b> s</span></div></header>
            <dl class="run-facts"><div><dt>节点</dt><dd>{{ fmt(config.node_count) }}</dd></div><div><dt>期望 RF</dt><dd>{{ fmt(config.desired_replication_factor) }}</dd></div><div><dt>ACK 策略</dt><dd>{{ text(config.write_ack_policy) }}</dd></div><div><dt>键数</dt><dd>{{ fmt(config.key_count) }}</dd></div><div><dt>值大小</dt><dd>{{ fmt(config.value_bytes) }} B</dd></div></dl>
            <div v-if="run.manifest?.source_reproducible === false" class="notice warning provenance-notice"><span aria-hidden="true">!</span><p><strong>源码可复现性未满足</strong><span>保留本次结果；正式引用前请核对构建与运行源码。</span></p></div>
            <div v-if="run.status === 'failed' || run.summary?.error" class="notice error" role="alert"><p><strong>实验失败</strong><span>{{ run.summary?.error || '结果标记为失败，未提供原因。' }}</span></p></div>
            <div v-if="run.status === 'incomplete'" class="notice neutral"><p>结果尚不完整，无法判断最终成功与否。下方保留已记录的内容。</p></div>
            <div v-for="warning in run.warnings" :key="warning" class="notice warning" role="status">{{ warning }}</div>
            <nav class="detail-tabs" aria-label="详情视图"><button v-for="tab in tabs" :key="tab.id" :class="{ active: activeTab === tab.id }" :aria-pressed="activeTab === tab.id" @click="activeTab = tab.id">{{ tab.name }}</button></nav>
            <RunOverview v-if="activeTab === 'overview'" :key="run.id" :run="run" />
            <RunTimeline v-else-if="activeTab === 'events'" :key="run.id" :run="run" />
            <div v-else-if="activeTab === 'config'" class="config-view">
              <section class="panel"><div class="section-heading"><div><h3>实际运行配置</h3><p>保留 manifest 中全部配置；适用参数取决于实验模式。</p></div></div><input v-model="configSearch" type="search" class="config-search" aria-label="搜索配置字段" placeholder="搜索参数名、含义或值" />
                <div class="table-scroll"><table class="config-table"><caption class="sr-only">运行配置字段</caption><thead><tr><th>参数</th><th>说明</th><th>值</th></tr></thead><tbody><tr v-for="[key, value] in configEntries" :key="key"><th scope="row"><code>{{ key }}</code></th><td>{{ fieldNames[key] || '—' }}</td><td>{{ text(value) }}</td></tr><tr v-if="!configEntries.length"><td colspan="3">{{ configSearch ? '没有匹配的配置字段。' : '未提供配置。' }}</td></tr></tbody></table></div>
              </section>
              <section class="panel"><div class="section-heading"><div><h3>构建与运行环境</h3><p>区分实验通过状态与源码可复现性。</p></div></div><dl class="config-grid"><div><dt>源码提交</dt><dd class="break-all">{{ text(build.git_commit) }}</dd></div><div><dt>构建配置</dt><dd>{{ text(build.profile) }}</dd></div><div><dt>目标平台</dt><dd>{{ text(build.target) }}</dd></div><div><dt>Rust 编译器</dt><dd>{{ text(build.rustc_version) }}</dd></div><div><dt>构建源码有改动</dt><dd>{{ text(build.git_dirty) }}</dd></div><div><dt>源码可复现</dt><dd>{{ text(run.manifest?.source_reproducible) }}</dd></div><div><dt>结束 epoch</dt><dd>{{ fmt(run.summary?.final_epoch) }}</dd></div><div><dt>数据格式版本</dt><dd>{{ fmt(run.manifest?.schema_version) }}</dd></div><div class="full-width"><dt>运行系统</dt><dd>{{ text(run.manifest?.system) }}</dd></div></dl></section>
            </div>
            <RunFiles v-else :key="run.id + activeTab" :run-id="run.id" :kind="activeTab === 'logs' ? 'logs' : 'raw'" />
          </template>
          <div v-else class="empty-block"><div class="empty-ring" aria-hidden="true"></div><h2>从一次运行开始</h2><p>选择左侧实验，查看它的配置与结果。</p></div>
        </section>
      </div>
      <footer class="page-footer"><span>hashring-rs · 一致性哈希实验</span><span>让每个读数，都有出处。</span></footer>
    </main>
  </div>
</template>
