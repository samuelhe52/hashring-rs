<script setup lang="ts">
import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
import { init, use, type EChartsCoreOption, type EChartsType } from 'echarts/core'
import { BarChart, LineChart } from 'echarts/charts'
import { GridComponent, LegendComponent, TooltipComponent, AriaComponent } from 'echarts/components'
import { SVGRenderer } from 'echarts/renderers'
import { object } from '../data'

use([BarChart, LineChart, GridComponent, LegendComponent, TooltipComponent, AriaComponent, SVGRenderer])
const props = defineProps<{ option: EChartsCoreOption; label: string }>()
const container = ref<HTMLDivElement | null>(null)
let chart: EChartsType | undefined
let resizeObserver: ResizeObserver | undefined

function update() {
  chart?.setOption({
    animation: false,
    backgroundColor: 'transparent',
    textStyle: { fontFamily: 'system-ui, Microsoft YaHei, sans-serif', color: '#736f65' },
    aria: { enabled: true },
    ...props.option,
    tooltip: { confine: true, ...object(props.option.tooltip) },
  }, { notMerge: true })
}

onMounted(() => {
  if (!container.value) return
  chart = init(container.value, undefined, { renderer: 'svg' })
  update()
  resizeObserver = new ResizeObserver(() => chart?.resize())
  resizeObserver.observe(container.value)
})
watch(() => props.option, update, { deep: true })
onBeforeUnmount(() => { resizeObserver?.disconnect(); chart?.dispose() })
</script>

<template>
  <div ref="container" class="data-chart" role="img" :aria-label="label"></div>
</template>
