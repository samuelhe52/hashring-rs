<script setup lang="ts">
import { nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue'

const props = defineProps<{ items: { id: string; label: string }[] }>()
const root = ref<HTMLElement | null>(null)
const current = ref('')
const open = ref(false)
const listId = useId()
const toggle = ref<HTMLButtonElement | null>(null)
let scroller: HTMLElement | null = null

function update() {
  const top = (scroller?.getBoundingClientRect().top ?? 0) + 100
  current.value = props.items[0]?.id ?? ''
  for (const item of props.items) {
    const section = document.getElementById(item.id)
    if (section && section.getBoundingClientRect().top <= top) current.value = item.id
  }
}

function go(id: string) {
  const section = document.getElementById(id)
  if (!section) return
  open.value = false
  section.focus({ preventScroll: true })
  section.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' })
  current.value = id
}

function closeOutside(event: PointerEvent) {
  if (event.target instanceof Node && !root.value?.contains(event.target)) open.value = false
}

function escape(event: KeyboardEvent) {
  if (!open.value) return
  event.preventDefault()
  event.stopPropagation()
  open.value = false
  toggle.value?.focus()
}

onMounted(() => {
  scroller = root.value?.closest('.window-body') as HTMLElement | null
  const target = scroller ?? window
  target.addEventListener('scroll', update, { passive: true })
  window.addEventListener('resize', update)
  document.addEventListener('pointerdown', closeOutside)
  update()
})
watch(() => props.items, async () => { await nextTick(); update() })
onBeforeUnmount(() => {
  const target = scroller ?? window
  target.removeEventListener('scroll', update)
  window.removeEventListener('resize', update)
  document.removeEventListener('pointerdown', closeOutside)
})
</script>

<template>
  <nav ref="root" class="floating-index" :class="{ 'is-open': open }" aria-label="页面目录" @keydown.esc="escape">
    <button ref="toggle" class="index-toggle" :aria-expanded="open" :aria-controls="listId" @click="open = !open">
      <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 5h10M6 10h10M6 15h7M3 5h.1M3 10h.1M3 15h.1" /></svg>目录
    </button>
    <div :id="listId" class="index-list">
      <span class="index-label">目录</span>
      <a v-for="item in items" :key="item.id" :href="'#' + item.id" :aria-current="current === item.id ? 'location' : undefined" @click.prevent="go(item.id)">{{ item.label }}</a>
    </div>
  </nav>
</template>
