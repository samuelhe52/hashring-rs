# Hashring 实验工作台

本地运行的 Vue 3 + TypeScript 网页与 Node.js 后端。浏览和对比真实实验记录，也可以启动本机 Rust 实验，查看实时事件、指标和拓扑。

## 当前界面：概览与浮窗

主页面左侧显示当前运行，右侧“负载阶梯”逐档比较实际速率和 GET p99。点击阶段切换读数，配置在下方独立排列。完整目录包含 13 个主入口，子目录可直接进入图表、配置差异、重复组统计、各类观测和日志。首页与详情共用同一份目录，详情内可以直接切换模块。目录采用半透明滚轮，滚动后条目自然居中，居中项放大 14%，上下边缘渐隐。滚轮浏览、点击打开，当前内容用陶橙圆点标记。鼠标在目录范围内时单独滚动目录，移到正文后照常滚动页面；触屏可上下滑动。宽屏目录悬在右侧，中等宽度用右侧浮层，手机用底部浮层，圆形按钮外圈显示当前页面的滚动进度。桌面回放和案例将图固定在左边，右侧可滚动查看读数、事件和字段。

详情使用原生 dialog：短暂淡入与抬升、点击外部／Esc／关闭按钮返回，键盘焦点限制在窗口内并在关闭后回到入口。图表在窗口显示后才初始化，首次约 560 ms 绘出真实数据，条目短暂错峰；节点条形切换约 280 ms，连续回放关闭数据动画。原生比例条从左侧展开。系统设置“减少动态效果”时关闭这些过渡。

11 月 9 日试改前的源码、构建产物和桌面截图在 `work/backups/dashboard-before-design-trial-20261109-004345/`。当前的验收截图、导出样图与换账号交接在 `work/dashboard-20261109/`。

## 结果浏览、对比与回放

- 运行列表：搜索名称，按模式、成功 / 失败 / 未完成筛选，按时间或名称排序。
- 结果详情：运行身份、实际配置、成功 / 失败及原因、总耗时、源码可复现性。
- latency 阶段：目标 / 实际成功速率、issued、late、重试、错误类别、发送端是否饱和。
- 图表：GET / PUT / DELETE 的阶段 p50 / p99 与实际速率曲线、当前阶段的延迟柱状图、每节点键数 / 操作数 / CPU 分布。
- 核对表格：分位数、样本数、成功操作数、节点负载、Rust 已计算的均衡统计量。
- 批量吞吐、空闲基线、初始节点压力、其他标量观测；未提供的项保留“—”。
- 配置全文、构建身份、原始 manifest / summary / events、日志浏览、按行搜索和原文下载。
- 事件时间线：按时间排列、类别 / 阶段 / 关键词筛选、隐藏预热、只看关键事件、关键事件跳转，查看 fields 与本行原文；每页 50 条。

分析区提供案例分析、运行对比、历史回放和哈希环。阶段记录见 [PROGRESS.md](PROGRESS.md)。

### 跨运行对比

默认选当前运行与另一份结果；展开“选择运行”可选择 2 到 N 次，点击“应用选择”。单个运行读取失败会单独提示，其他可读结果仍保留。配置支持深比较和仅看差异，缺字段与 null 分开。

阶段指标按目标速率匹配，重复目标可逐列选择阶段。条形图和表格以第一条运行为对照，显示带符号的差值。可切换分组分位数和实际速率曲线。图表支持带标题和来源的 PNG、SVG。其他指标按完整字段路径查看。

将同配置的成功运行标为重复组，可查看有效读数的均值、最小值、最大值与记录数。阶段须同名并且没有记录发送端饱和。p99 均值只描述各次实验的 p99，原始阶段成绩保留。正式报告按组长要求使用至少三次重复。

### 案例与图表

“案例分析”取当前运行的实测数据。延迟实验可对照阶段实际速率、尾延迟与样本数，下载图表，或跳到首次正式采样与初始环。迁移、故障结果会显示已记录的 epoch、阶段耗时和对应事件，可在同一窗内查看环与游标。

### 历史回放

支持播放、暂停、1×／2×／5×／10×、进度拖动、逐事件步进和跳转；切换到后台或关闭窗口时停止计时。起点优先实验启动事件，其次 manifest，再次首条记录；事件早于起点时也保留。时间戳相同的事件按原文件行号推进。

指标只展示游标到达的采样，包含窗口延迟、发送、重试、错误、目标速率与有据可算的窗口实际读数。latency 窗口成功速率按已完成成功操作数与窗口时长计算，和 summary 的整个正式阶段成绩分开。预热和事件标记可切换。缺采样或切换阶段时断线。没有采样的运行仍可看事件和哈希环。

“拓扑回放”跟随同一游标，只使用该时刻已经发布的快照。记录时长来自事件时间轴，与 summary.elapsed_seconds 的计时口径不同。

### 哈希环与拓扑

读取 topology_published，支持选快照与对照快照、悬停／选择区间、虚拟位置、owner／followers、节点空间比例及阶段负载。区间是 (start, end]，副本从第一个 >= token 的位置顺时针收集不同物理节点，RF 包含 owner，与 crates/hashring-core/src/topology.rs 一致。

u64 用精确十进制文本进入 API，客户端以 BigInt 计算归属、跨零区间和前后拓扑的联合边界，仅绘图时转换角度。空间比例和归属变化是 token 几何关系，不代表实际迁移键数／字节数；副本放置不表示实时健康或同步进度。阶段键数／操作数／CPU 来自 summary，明确标为阶段成绩，与快照时刻不同步。

无效快照明确报错并保留原文。同 epoch 的重复快照不会显示为迁移。默认 results 的两次延迟运行均为 epoch 1。另用隔离目录中的真实小规模运行核对了迁移与故障转移事件。

### 事件时间线

点击主页面的“事件时间线”。`my-latency-20261028-013354` 应有 35 条事件、24 个指标窗口、2 份拓扑快照；默认只显示 8 条关键事件。取消“只看关键事件”可看全部 35 条，再展开“搜索、筛选与跳转”隐藏预热后剩 31 条。两份拓扑快照都是 epoch 1，不代表两次拓扑变化。

相对时间优先以 `experiment_started.unix_ms` 为零点；没有启动事件时使用 manifest 开始时间，再缺少时使用首条有效事件，界面会标明基准。它与 summary.elapsed_seconds 的计时口径不同，不会用时间戳差替换最终成绩。北京时间显示到毫秒。

选择事件后可查看字段和本行原文。未知事件仍保留原名；缺少事件文件、空文件、坏行分别提示。坏行会显示原始行号和内容，其他可读事件继续展示；没有末尾换行的完整 JSON 行可以正常读取，未写完的 JSON 尾行会报告问题，之后可手动刷新。

后端利用 Node 的 [JSON.parse reviver context.source](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse) 读取原始数字文本，把 fields 中超出 Number 安全范围的大整数转换为字符串，避免 u64 被舍入；没有增加解析依赖。字段视图中的引号表示接口使用了精确文本，原始 JSON 类型和写法看“本行原文”。所有原始文件保持不变。

latency 使用结构化的 `measurements.rate_*`。其他模式可浏览已输出的吞吐、空闲基线、标量观测、模式专有嵌套记录与全部原始文件。

## 启动实验与实时视图

1. 点击“运行实验”。用表单设定参数，也可上传或粘贴实验 YAML。页面指定的结果目录名优先。
2. 点“预览命令”核对参数。需要终端复跑时可下载 Bash 脚本。在同一环境运行 `bash 下载的脚本.sh /新的/结果目录`，新目录可以覆盖脚本的默认输出路径。
3. 点“启动实验”。实时页与回放共用曲线、事件和哈希环。事件与 stderr 通过 SSE 增量接收。成功时可自动打开新结果，也能继续停留在实时页。
4. “停止实验”终止本次实验的进程组，已写入的文件仍在结果目录。关闭浮窗后可重新打开查看或停止。

一个 Dashboard 服务同时管理一次实验。后端直接调用 `target/release/hashring-rs`，可用 `HASHRING_BIN` 指定其他本机可执行文件。实验运行和停止已在 WSL Debian 验证。运行中可按需每 4 秒查询协调器的 topology 与 replica-status，正式测量时可关闭这项查询。回放读取已落盘的拓扑快照。

## 启动：使用原仓库，推荐 WSL Debian

Windows PowerShell 中进入已经配置的 Debian：

```powershell
wsl -d Debian
```

以下命令在 **WSL Debian** 内执行：

```bash
cd '/mnt/d/数据结构课程/实验7/项目/hashring-rs/dashboard'
npm run dev
```

Windows 浏览器打开 **http://localhost:4173**。一个命令同时启动本地后端和 Vite 开发页面。保持终端开启，在该终端按 `Ctrl+C` 停止。

WSL 中启用了 Vite 轮询监听，Windows 编辑器或 PowerShell 修改前端文件后也能更新页面。修改 server/ 的后端代码后，需停止并重新启动 npm run dev。

需要 Node.js 22.12+；当前已有 WSL Node 24 与依赖。第一次在另一台机器使用，或依赖锁文件变化后，在 `dashboard/` 先执行：

```bash
npm ci
```

已有构建时可直接运行 `npm start`。浏览历史结果只需要 Node。启动新实验需要同一环境内可用的 release 二进制。

### 构建后运行

```bash
npm run build
npm start
```

`build` 先检查 TypeScript / Vue 类型，再打包到 `dashboard/dist/`。`start` 提供构建后的页面与本地 API。

### 自定义结果目录和端口

在 WSL 中，例如：

```bash
RESULTS_DIR='/path/to/results' PORT=4174 npm run dev
```

默认读取仓库根目录 `results/`。`RESULTS_DIR` 指向包含各次运行目录的文件夹；支持 `results/campaign/某次/run/` 这样的嵌套结构。服务仅监听 `127.0.0.1`。

## 用现有结果验收

用已有的 `my-latency-20261028-013354` 可以核对以下读数。

| 项目 | 应显示 |
| --- | --- |
| 配置 | latency、3 节点、RF=3、OwnerOnly、2000 键 |
| 状态 | 成功；同时提示源码可复现性未满足 |
| 总耗时 | 约 27.56 秒 |
| rate_0 目标 / 实际速率 | 500 / 500 ops/s |
| rate_0 GET p99 / 样本数 | 732 µs / 4527 |
| rate_1 目标 / 实际速率 | 1000 / 1000 ops/s |
| rate_1 GET p99 / 样本数 | 660 µs / 9019 |
| 各节点 owner 键数 | 635、534、831 |
| 错误、late、重试 | 已记录的项均为 0 |

切换阶段后，指标、延迟表格、节点分布同步变化。曲线仍显示本次运行的所有阶段；GET / PUT / DELETE 按钮切换曲线操作类型。

运行列表显示键数和 ACK 策略。“其他观测”中的空闲基线同时展示分位数柱状图和样本数，节点压力可按已记录的字段切换柱状图。

“成功”不等于达到系统容量上限；`source_reproducible=false` 不自动表示实验失败。窗口分位数不用于重新计算阶段分位数。CPU 是进程占单核的比例；缺失 CPU 不当成零。原始文件保留 Rust 输出原文。

## 检查

在 `dashboard/` 执行：

```bash
npm test
npm run build
```

测试使用 Node 内置测试工具，在系统临时目录构造结果，不修改真实 `results/`。覆盖嵌套目录、失败运行的部分成绩、缺失 / 损坏文件、真实零值、未采集 CPU、原文 u64 保留、文件访问边界、HTTP 错误及拒绝写入。

当前 22 项测试通过，包含事件解析、结果边界、模式记录大整数、目标速率匹配、配置深比较、回放时间与缺采样、跨零区间、去重副本和联合边界；Vue / TypeScript 检查与生产构建通过。纯数据逻辑用 Node 的 TypeScript stripping 直接测试，不增加测试依赖；建议沿用当前已验证的 Node 24 环境。

第一版已核对两次真实 latency 运行、指标与图表切换、配置、原文和日志。事件时间线另核对了 35 / 24 / 2 的真实数量、筛选、毫秒时间、原文与 token、运行切换，以及 1440px 桌面与 390px 窄屏、键盘操作。缺失 / 空 / 损坏事件、未知事件、121 条事件的分页与跨页跳转、读取失败重试使用临时接口响应验证，没有生成或改动真实实验结果。

本次浮窗版另核对了阶段同步、外部／Esc 关闭、Tab 焦点循环与恢复、320px 窄屏、手机事件详情定位、减少动态效果、异常数据与真实零值。正式 npm start 与攻略接口已验证；截图和检查记录在 `work/dashboard-refined/`。

已用 Chrome 检查桌面与手机布局、目录、固定动画区、动效与减少动态效果、键盘焦点、回放和 PNG/SVG 保存。真实小规模验收覆盖两阶段 latency、实时拓扑与副本、停止保留结果、correctness 迁移和 availability 故障转移。记录在 `work/dashboard-20261109/`。包含图表库的主包会触发 Vite 的 500 kB 体积提示。

## 文件阅读顺序

| 文件 | 学习重点 |
| --- | --- |
| `client/src/main.ts` | Vue 挂载入口 |
| `client/src/App.vue` | 运行列表、筛选、详情请求与视图切换 |
| `client/src/types.ts` | 接口和结果数据的形状 |
| `client/src/data.ts` | 格式化、读取接口、把已有字段整理成展示结构 |
| `client/src/components/RunOverview.vue` | 选择阶段、指标表格与图表配置 |
| `client/src/components/DetailWindow.vue` | 原生浮窗、动画、焦点与关闭行为 |
| `client/src/components/RunConfig.vue` | 参数搜索、构建环境与可复现性 |
| `client/src/components/DataChart.vue` | ECharts 初始化、更新、响应尺寸变化和释放 |
| `client/src/components/RunFiles.vue` | 原始文件 / 日志的请求、搜索和下载 |
| `client/src/components/RunTimeline.vue` | 事件加载、筛选、选择、分页与原文详情 |
| `client/src/components/ModeResults.vue`、`RecordedFields.vue` | 模式专有记录的按需分层阅读 |
| `client/src/components/RunCompare.vue`、`compare.ts` | 运行选择、速率匹配、配置差异与原始指标 |
| `client/src/components/RunReplay.vue`、`history.ts` | 回放时钟、可见记录、预热、断线与事件游标 |
| `client/src/components/RunExperiment.vue` | 表单、YAML、命令预览、脚本和实时连接 |
| `client/src/components/RunTopology.vue`、`TopologyView.vue`、`topology.ts` | 快照、精确环与副本、空间比例、前后变化 |
| `client/src/events.ts` | 事件名称、类别、摘要和时间显示 |
| `client/src/style.css` | 配色、字体、布局和窄屏样式 |
| `server/index.mjs` | HTTP 路由、开发 / 构建页面服务 |
| `server/experiments.mjs` | 启停 Rust 进程组、SSE 增量日志、实时拓扑查询 |
| `server/store.mjs` | 扫描结果、读 JSON、限制文件读取范围 |
| `server/events.mjs` | 逐行解析、无损大整数、异常行报告和稳定排序 |

练习：在 `RunOverview.vue` 搜索 `latency(current, op).p99`，沿 `current → rateStages → run.summary` 追踪到自己的 summary。再找同一位置的 `.samples`，核对 4527 / 9019。

## 当前接口

结果接口使用 GET。运行 id 中的斜杠等字符通过 `encodeURIComponent(id)` 编码。启停与预览操作使用同源 JSON POST。

| 请求 | 返回 |
| --- | --- |
| `/api/runs` | `{ runs: [...] }`，概要按开始时间倒序 |
| `/api/runs/:id` | `{ id, name, status, warnings, manifest, summary }` |
| `/api/runs/:id/events` | `{ events, issues, missing }`；事件含 line、event、unix_ms、fields、raw |
| `/api/runs/:id/raw?file=summary.json` | 原始文本；file 仅允许 manifest.json、summary.json、events.jsonl |
| `/api/runs/:id/logs` | 日志文件名数组 |
| `/api/runs/:id/logs?process=node-1.stderr.log` | 指定进程日志原文 |
| `POST /api/experiments/preview` | 生成完整命令和可下载脚本 |
| `POST /api/experiments` | 启动一次实验 |
| `POST /api/experiments/current/stop` | 按当前运行 id 停止进程组 |
| `GET /api/experiments/current` | 当前实验状态 |
| `GET /api/experiments/current/stream` | SSE 快照和增量事件、stderr |
| `GET /api/experiments/current/topology?id=…` | 查询运行中的拓扑与副本状态 |

概要接口排除 manifest 中较大的运行源码快照；原始文件入口可以查看完整 manifest。程序不读取 coordinator.redb，也不写回实验结果。

事件的 `line` 是原始文件行号；API 按 unix_ms 排序，同毫秒保留原文顺序。`issues` 含损坏行的 line、message、raw。只有运行存在但事件文件不存在时 missing=true；运行不存在仍返回 404。fields 内超出安全范围的大整数为字符串，raw 保留原始单行文本。

原文和指定日志接口可附加 `&download=1`，以附件方式返回同一份文本。

## 视觉来源

浅色纸面、墨色正文与赭橙强调色参考陈阳提供的 `4-陈阳-17.html`；另一张截图用于参考温暖色调、细线分隔和留白。外部项目仅参考 [Consistent Hashing Visualizer](https://github.com/NeelVinay/consistent-hashing-visualizer) 的图、数据与说明的组织方式，不复用其模拟数据或算法实现。

界面主色为 `#faf8f3`、`#282720`、`#736f65`、`#e1dacd` 和 `#b4532a`。负载阶梯和案例中，青色代表速率，陶橙代表延迟。标题和读数使用系统衬线字体，正文使用系统中文无衬线字体。

悬浮目录参考 [konakona 文章页](https://blog.konakona.dev/zh/posts/notes-insights-with-claude/)。试改在项目外临时下载并使用了 [Oil UI](https://github.com/oil-oil/oil-ui)、[emil-design-eng](https://github.com/emilkowalski/skills/tree/main/skills/emil-design-eng)、[frontend-design-direction](https://github.com/affaan-m/ECC/tree/main/skills/frontend-design-direction) 和 [frontend-design](https://github.com/anthropics/skills/tree/main/skills/frontend-design)。条形从左向右展开，回放动效跟随事件与数据，减少动态效果时直接显示状态。

文件仍在原仓库；Git 提交和推送必须另获 cyable 明确授权。
