<script setup lang="ts">
import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
import { init, use, type EChartsCoreOption, type EChartsType } from 'echarts/core'
import { BarChart, LineChart } from 'echarts/charts'
import { GridComponent, LegendComponent, TooltipComponent, AriaComponent, MarkAreaComponent, MarkLineComponent } from 'echarts/components'
import { SVGRenderer } from 'echarts/renderers'
import { object } from '../data'

use([BarChart, LineChart, GridComponent, LegendComponent, TooltipComponent, AriaComponent, MarkAreaComponent, MarkLineComponent, SVGRenderer])
const props = withDefaults(defineProps<{ option: EChartsCoreOption; label: string; animateUpdates?: boolean; motion?: boolean }>(), { motion: true, animateUpdates: false })
const emit = defineEmits<{ layout: [] }>()
const container = ref<HTMLDivElement | null>(null)
let chart: EChartsType | undefined
let resizeObserver: ResizeObserver | undefined
let painted = false

function update() {
  const first = !painted
  chart?.setOption({
    backgroundColor: 'transparent',
    textStyle: { fontFamily: 'system-ui, Microsoft YaHei, sans-serif', color: '#736f65' },
    aria: { enabled: true, description: props.label },
    ...props.option,
    animation: props.motion !== false && !matchMedia('(prefers-reduced-motion: reduce)').matches && (first || props.animateUpdates === true),
    animationDuration: first ? 560 : 280,
    animationDurationUpdate: 0,
    animationDelay: (index: number) => first ? Math.min(index * 40, 200) : 0,
    animationEasing: 'cubicOut',
    tooltip: { confine: true, ...object(props.option.tooltip) },
  }, { notMerge: true })
  painted = true
  emit('layout')
}

onMounted(() => {
  if (!container.value) return
  chart = init(container.value, undefined, { renderer: 'svg' })
  update()
  let width = container.value.clientWidth
  let height = container.value.clientHeight
  resizeObserver = new ResizeObserver(() => {
    if (!container.value) return
    const nextWidth = container.value.clientWidth
    const nextHeight = container.value.clientHeight
    if (nextWidth !== width || nextHeight !== height) { width = nextWidth; height = nextHeight; chart?.resize(); emit('layout') }
  })
  resizeObserver.observe(container.value)
})
watch(() => props.option, update, { deep: true })
onBeforeUnmount(() => { resizeObserver?.disconnect(); chart?.dispose() })
defineExpose({ pixelAt(value: number): number | null { const pixel = chart?.convertToPixel({ xAxisIndex: 0 }, value); return typeof pixel === 'number' && Number.isFinite(pixel) ? pixel : null } })
</script>

<template>
  <div ref="container" class="data-chart" role="img" :aria-label="label"></div>
</template>
