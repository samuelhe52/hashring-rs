<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import DataChart from './DataChart.vue'
import type { Measurement, RunDetail, RunListItem } from '../types'
import { colors, errorsText, fieldNames, formatNumber as fmt, number, object, operations, request, shortName, stages, statusLabels, text } from '../data'
import { canonical, comparisonRates, configRows, numericFields, recordedMetrics, stagesAtRate } from '../compare.ts'

const props = defineProps<{ runs: RunListItem[]; initialId: string }>()
const selected = ref<string[]>([props.initialId, ...props.runs.map(run => run.id).filter(id => id !== props.initialId)].filter(Boolean).slice(0, 2))
const applied = ref<string[]>([])
const loaded = ref<RunDetail[]>([])
const failures = ref<{ id: string; message: string }[]>([])
const loading = ref(false)
const view = ref('latency')
const onlyDifferent = ref(true)
const operation = ref('get')
const percentile = ref<'p50' | 'p95' | 'p99' | 'max'>('p99')
const plot = ref('curve')
const rate = ref<number | null>(null)
const stageOverrides = ref<Record<string, string>>({})
const metric = ref('')
let controller: AbortController | undefined
const rates = computed(() => comparisonRates(loaded.value))
const currentRate = computed(() => rate.value !== null && rates.value.includes(rate.value) ? rate.value : rates.value[0] ?? null)
const current = computed(() => loaded.value.map(run => { const candidates = stagesAtRate(run, currentRate.value); return candidates.find(([key]) => key === stageOverrides.value[run.id]) ?? candidates[0] }))
const configs = computed(() => configRows(loaded.value))
const visibleConfigs = computed(() => configs.value.filter(row => !onlyDifferent.value || row.different))
const fields = computed(() => loaded.value.map(run => numericFields(recordedMetrics(run))))
const metricPaths = computed(() => [...new Set(fields.value.flatMap(fields => [...fields.keys()]))].sort((a, b) => a.localeCompare(b, 'en', { numeric: true })))
const currentMetric = computed(() => metricPaths.value.includes(metric.value) ? metric.value : metricPaths.value[0] ?? '')
const label = (run: RunDetail, index: number) => `${index + 1}. ${shortName(run.name)}`
const latency = (stage: Measurement | undefined, key: string) => number(object(object(stage?.latency_us)[operation.value])[key])
const pending = computed(() => canonical(selected.value) !== canonical(applied.value))
watch(rate, () => { stageOverrides.value = {} })

const metricRows = computed(() => [
  { name: '实际成功速率 · ops/s', values: current.value.map(entry => fmt(entry?.[1].achieved_rate, 2)) },
  ...(['p50', 'p95', 'p99', 'max'] as const).map(key => ({ name: `${operation.value.toUpperCase()} ${key} · µs`, values: current.value.map(entry => fmt(latency(entry?.[1], key), 2)) })),
  { name: `${operation.value.toUpperCase()} 样本数`, values: current.value.map(entry => fmt(latency(entry?.[1], 'samples'))) },
  ...(['issued', 'late', 'retries'] as const).map(key => ({ name: key, values: current.value.map(entry => fmt(entry?.[1][key])) })),
  { name: '错误类别', values: current.value.map(entry => entry ? errorsText(entry[1].errors) : '未提供') },
  { name: '发送端', values: current.value.map(entry => entry?.[1].sender_saturated === true ? '饱和' : entry?.[1].sender_saturated === false ? '正常' : '未提供') },
])
const curveOption = computed(() => ({
  color: colors, grid: { top: 20, left: 46, right: 20, bottom: 48, outerBoundsMode: 'same' },
  tooltip: { trigger: 'axis', valueFormatter: (value: unknown) => `${fmt(value, 2)} µs` },
  xAxis: { type: 'value', name: '实际成功速率（ops/s）', nameLocation: 'middle', nameGap: 30 },
  yAxis: { type: 'value', name: 'µs', splitLine: { lineStyle: { color: '#e5e0d7', type: 'dashed' } } },
  series: loaded.value.map((run, index) => ({ name: label(run, index), type: 'line', symbol: 'circle', symbolSize: 7, smooth: false, connectNulls: false,
    lineStyle: { width: 2, type: index >= colors.length ? 'dashed' : 'solid' },
    data: stages(run.summary).filter(([, stage]) => number(stage.achieved_rate) !== null).map(([, stage]) => [stage.achieved_rate, latency(stage, percentile.value)]).sort((a, b) => (a[0] ?? 0) - (b[0] ?? 0)),
  })),
}))
function bars(values: (number | null)[], unit: string) {
  return { grid: { top: 12, left: 3, right: 65, bottom: 30, outerBoundsMode: 'same' }, tooltip: { trigger: 'axis' },
    xAxis: { type: 'value', name: unit, min: 0 }, yAxis: { type: 'category', inverse: true, data: loaded.value.map(label), axisTick: { show: false }, axisLine: { show: false } },
    series: [{ type: 'bar', barMaxWidth: 28, showBackground: true, backgroundStyle: { color: '#f3f1ec' }, label: { show: true, position: 'right', formatter: (item: { value: unknown }) => fmt(item.value, 2) },
      data: values.map((value, index) => ({ value, itemStyle: { color: colors[index % colors.length], borderRadius: [0, 4, 4, 0] } })),
    }],
  }
}
const barOption = computed(() => bars(current.value.map(entry => latency(entry?.[1], percentile.value)), 'µs'))
const otherOption = computed(() => bars(fields.value.map(fields => fields.get(currentMetric.value) ?? null), '原字段单位'))

async function load() {
  if (selected.value.length < 2) return
  controller?.abort()
  controller = new AbortController()
  const signal = controller.signal
  const ids = [...selected.value]
  loading.value = true
  failures.value = []
  const results = await Promise.allSettled(ids.map(id => request<RunDetail>(`/api/runs/${encodeURIComponent(id)}`, signal)))
  if (signal.aborted) return
  loaded.value = results.flatMap(result => result.status === 'fulfilled' ? [result.value] : [])
  failures.value = results.flatMap((result, index) => result.status === 'rejected' ? [{ id: ids[index]!, message: result.reason instanceof Error ? result.reason.message : String(result.reason) }] : [])
  applied.value = ids
  stageOverrides.value = {}
  loading.value = false
}
onMounted(load)
onBeforeUnmount(() => controller?.abort())
</script>

<template>
  <section class="compare-view">
    <details class="data-disclosure compare-picker" :open="runs.length < 2"><summary>选择运行 · 已选 {{ selected.length }} 次</summary><div class="comparison-choices"><label v-for="run in runs" :key="run.id" class="comparison-choice"><input v-model="selected" type="checkbox" :value="run.id" /><span><strong>{{ shortName(run.name) }}</strong><code>{{ run.id }}</code><small>{{ text(run.config.mode) }} · {{ statusLabels[run.status] }}</small></span></label></div><button class="button primary" :disabled="selected.length < 2 || loading" @click="load">{{ loading ? '正在读取' : '应用选择' }}</button><p v-if="selected.length < 2" class="footnote">至少选择两次运行。</p></details>
    <div v-if="pending && !loading" class="notice neutral"><p>选择已改变，点击“应用选择”更新对比。</p><button class="table-link" :disabled="selected.length < 2" @click="load">应用选择</button></div>
    <p v-if="loading" class="empty-inline" role="status">正在读取所选运行……</p>
    <div v-for="failure in failures" :key="failure.id" class="notice error" role="alert"><p><strong>{{ failure.id }}</strong><span>{{ failure.message }}；其他可读运行已保留。</span></p><button class="table-link" @click="load">重试</button></div>
    <template v-if="loaded.length && !loading">
      <div class="comparison-legend"><div v-for="(run, index) in loaded" :key="run.id" :title="run.id"><i :style="{ background: colors[index % colors.length] }"></i><span>{{ label(run, index) }}</span><span class="status-badge" :class="run.status">{{ statusLabels[run.status] }}</span><small v-if="run.manifest?.source_reproducible === false" class="text-warning">源码待核对</small><small v-if="run.warnings.length" class="text-warning">{{ run.warnings.length }} 项文件提示</small></div></div>
      <p v-if="loaded.length < 2" class="notice warning">只有一次运行可读取，请调整选择或重试后进行对比。</p>
      <nav class="view-switch" aria-label="对比内容"><button :aria-pressed="view === 'latency'" @click="view = 'latency'">阶段指标</button><button :aria-pressed="view === 'other'" @click="view = 'other'">其他指标</button><button :aria-pressed="view === 'config'" @click="view = 'config'">配置差异</button></nav>
      <template v-if="view === 'config'"><label class="checkbox-label compare-diff"><input v-model="onlyDifferent" type="checkbox" />只看不同参数</label><div class="table-scroll"><table><caption class="sr-only">所选运行配置差异</caption><thead><tr><th>参数</th><th v-for="(run, index) in loaded" :key="run.id" :title="run.id">{{ label(run, index) }}</th></tr></thead><tbody><tr v-for="row in visibleConfigs" :key="row.key" :class="{ 'different-row': row.different }"><th scope="row">{{ fieldNames[row.key] || row.key }}<code class="field-code">{{ row.key }}</code></th><td v-for="(value, index) in row.values" :key="index" class="wrap-cell">{{ text(value) }}</td></tr><tr v-if="!visibleConfigs.length"><td :colspan="loaded.length + 1">{{ onlyDifferent ? '没有配置差异，可取消勾选查看全部参数。' : '没有记录配置。' }}</td></tr></tbody></table></div></template>
      <template v-else-if="view === 'latency'">
        <template v-if="rates.length"><div class="comparison-controls"><label>目标速率<select :value="currentRate" aria-label="对比目标速率" @change="rate = Number(($event.target as HTMLSelectElement).value)"><option v-for="value in rates" :key="value" :value="value" :selected="currentRate === value">{{ fmt(value) }} ops/s</option></select></label><div class="segmented" aria-label="对比操作"><button v-for="op in operations" :key="op" :aria-pressed="operation === op" @click="operation = op">{{ op.toUpperCase() }}</button></div><label>分位值<select v-model="percentile" aria-label="对比分位值"><option v-for="value in ['p50', 'p95', 'p99', 'max']" :key="value">{{ value }}</option></select></label><select v-model="plot" aria-label="对比图类型"><option value="curve">全部阶段曲线</option><option value="bar">所选速率条形图</option></select></div>
          <DataChart :option="plot === 'curve' ? curveOption : barOption" :animate-updates="plot === 'bar'" :label="operation.toUpperCase() + ' ' + percentile + ' 多运行延迟对比'" />
          <p class="footnote">{{ plot === 'curve' ? '曲线展示全部阶段，横轴为实际成功速率。下表按所选目标速率匹配。' : '条形与下表按所选目标速率匹配；缺阶段显示 —。' }}</p>
          <div class="table-scroll"><table><caption class="sr-only">所选速率各运行指标</caption><thead><tr><th>指标</th><th v-for="(run, index) in loaded" :key="run.id" :title="run.id">{{ label(run, index) }}<span class="field-code">{{ current[index]?.[0] || '没有匹配阶段' }}</span><select v-if="stagesAtRate(run, currentRate).length > 1" :value="current[index]?.[0]" aria-label="选择重复目标阶段" @change="stageOverrides[run.id] = ($event.target as HTMLSelectElement).value"><option v-for="[name] in stagesAtRate(run, currentRate)" :key="name" :value="name">{{ name }}</option></select></th></tr></thead><tbody><tr v-for="row in metricRows" :key="row.name"><th scope="row">{{ row.name }}</th><td v-for="(value, index) in row.values" :key="index" class="wrap-cell">{{ value }}</td></tr></tbody></table></div>
        </template><p v-else class="empty-inline">所选运行未提供固定速率阶段，可切换“其他指标”或“配置差异”。</p>
      </template>
      <template v-else><template v-if="currentMetric"><label class="record-selector">原始字段<select :value="currentMetric" aria-label="选择对比指标" @change="metric = ($event.target as HTMLSelectElement).value"><option v-for="path in metricPaths" :key="path" :value="path" :selected="path === currentMetric">{{ path }}</option></select></label><DataChart :option="otherOption" :animate-updates="true" :label="currentMetric + ' 多运行原始指标对比'" /><div class="table-scroll"><table><caption class="sr-only">原始指标值</caption><thead><tr><th>运行</th><th>{{ currentMetric }}</th></tr></thead><tbody><tr v-for="(run, index) in loaded" :key="run.id"><th scope="row">{{ label(run, index) }}</th><td>{{ fmt(fields[index]?.get(currentMetric), 6) }}</td></tr></tbody></table></div><p class="footnote">按完整字段路径匹配，单位沿用原字段（_ms 毫秒、_seconds 秒、_us 微秒）；数组序号只是记录位置，比较故障轮次前需核对场景一致。</p></template><p v-else class="empty-inline">没有可比较的数值记录。</p></template>
      <details class="data-disclosure"><summary>运行身份与结果提示</summary><div v-for="run in loaded" :key="run.id" class="comparison-source"><code>{{ run.id }}</code><p>模式 {{ text(run.manifest?.config?.mode) }} · {{ statusLabels[run.status] }} · 总耗时 {{ fmt(run.summary?.elapsed_seconds, 3) }} s</p><p v-if="run.summary?.error" class="text-warning">{{ run.summary.error }}</p><p v-for="warning in run.warnings" :key="warning" class="text-warning">{{ warning }}</p></div></details>
      <p class="footnote">每个值来自各自的 summary。不同配置会影响可比性，请核对配置差异；重复运行仍逐次展示，不把 p99 平均成合并 p99。</p>
    </template>
  </section>
</template>
