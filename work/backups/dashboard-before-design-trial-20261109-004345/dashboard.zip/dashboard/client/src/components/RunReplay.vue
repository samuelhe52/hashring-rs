<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import DataChart from './DataChart.vue'
import TopologyView from './TopologyView.vue'
import type { EventLog, RunDetail, RunEvent } from '../types'
import { colors, formatNumber as fmt, number, object, operations, request, text } from '../data'
import { absoluteEventTime, eventCategory, eventName, eventSummary, isKeyEvent, relativeEventTime } from '../events'
import { replayBounds, sampledSeries, visibleCount, warmupIntervals, windowLatency } from '../history.ts'

const props = defineProps<{ run: RunDetail }>()
const log = ref<EventLog>({ events: [], issues: [], missing: false })
const loading = ref(true)
const error = ref('')
const playing = ref(false)
const speed = ref(1)
const cursor = ref(0)
const boundaryLine = ref<number | null>(null)
const hideWarmup = ref(false)
const markers = ref(true)
const plot = ref('latency')
const view = ref('metrics')
const operation = ref('get')
const percentile = ref('p99')
const chart = ref<InstanceType<typeof DataChart> | null>(null)
const layoutVersion = ref(0)
let controller: AbortController | undefined
let frame = 0
let lastFrame = 0
const bounds = computed(() => replayBounds(log.value.events, props.run.manifest?.started_unix_ms))
const count = computed(() => visibleCount(log.value.events, cursor.value, boundaryLine.value ?? Infinity))
const seen = computed(() => log.value.events.slice(0, count.value))
const currentEvent = computed(() => seen.value.at(-1))
const samples = computed(() => seen.value.filter(event => event.event === 'metrics_sampled' && (!hideWarmup.value || event.fields.warmup !== true)))
const latestSample = computed(() => samples.value.at(-1))
const latestTopology = computed(() => [...seen.value].reverse().find(event => event.event === 'topology_published'))
const topologyRecords = computed(() => log.value.events.filter(event => event.event === 'topology_published'))
const topologyCount = computed(() => visibleCount(topologyRecords.value, cursor.value, boundaryLine.value ?? Infinity))
const seenTopology = computed(() => topologyRecords.value.slice(0, topologyCount.value))
const keyEvents = computed(() => log.value.events.filter(isKeyEvent))
const sourceIssues = computed(() => log.value.issues.length)
const duration = computed(() => bounds.value.end - bounds.value.start)
const unit = computed(() => plot.value === 'latency' ? 'µs' : plot.value === 'target' ? 'ops/s' : '次／窗口')
const seconds = computed(() => (cursor.value - bounds.value.start) / 1000)
const playhead = computed(() => { void layoutVersion.value; return chart.value?.pixelAt(seconds.value) ?? null })
const seriesDefs = computed<{ name: string; value: (event: RunEvent) => number | null }[]>(() => {
  if (plot.value === 'latency') return [{ name: `${operation.value.toUpperCase()} ${percentile.value}`, value: event => windowLatency(event, operation.value, percentile.value) }]
  if (plot.value === 'target') return [{ name: '目标速率', value: event => number(event.fields.target_rate) }]
  if (plot.value === 'counts') return ['issued', 'late', 'retries'].map(key => ({ name: key, value: event => number(event.fields[key]) }))
  const names = [...new Set(log.value.events.filter(event => event.event === 'metrics_sampled').flatMap(event => Object.keys(object(event.fields.errors))))]
  return names.map(key => ({ name: key, value: event => number(object(event.fields.errors)[key]) }))
})
const chartOption = computed(() => ({
  color: colors, grid: { top: 28, left: 50, right: 22, bottom: 45, outerBoundsMode: 'same' },
  tooltip: { trigger: 'axis', valueFormatter: (value: unknown) => `${fmt(value, 2)} ${unit.value}` },
  xAxis: { type: 'value', min: 0, max: Math.max(1, duration.value / 1000), name: '记录时间（s）', nameLocation: 'middle', nameGap: 30 },
  yAxis: { type: 'value', min: 0, name: unit.value, splitLine: { lineStyle: { color: '#e5e0d7', type: 'dashed' } } },
  series: seriesDefs.value.map((series, index) => ({ name: series.name, type: 'line', symbol: 'circle', symbolSize: 5, smooth: false, connectNulls: false,
    data: sampledSeries(seen.value, bounds.value.start, series.value, hideWarmup.value),
    ...(index === 0 ? {
      markArea: { silent: true, itemStyle: { color: '#ccc6bb40' }, data: warmupIntervals(seen.value, bounds.value.start).map(([from, to]) => [{ xAxis: from }, { xAxis: to }]) },
      markLine: { silent: true, symbol: ['none', 'none'], label: { show: false }, lineStyle: { color: '#736f65', opacity: .35, type: 'dashed' }, data: markers.value ? seen.value.filter(event => ['topology', 'migration', 'fault'].includes(eventCategory(event.event))).map(event => ({ name: eventName(event.event), xAxis: (event.unix_ms - bounds.value.start) / 1000 })) : [] },
    } : {}),
  })),
}))
const hasPlottedValue = computed(() => seriesDefs.value.some(series => samples.value.some(event => series.value(event) !== null)))

function pause() { playing.value = false; cancelAnimationFrame(frame) }
function tick(time: number) {
  if (!playing.value) return
  if (time - lastFrame >= 33) {
    cursor.value = Math.min(bounds.value.end, cursor.value + (time - lastFrame) * speed.value)
    lastFrame = time
    if (cursor.value >= bounds.value.end) { pause(); return }
  }
  frame = requestAnimationFrame(tick)
}
function toggle() {
  if (playing.value) return pause()
  if (cursor.value >= bounds.value.end) cursor.value = bounds.value.start
  boundaryLine.value = null
  playing.value = true
  lastFrame = performance.now()
  frame = requestAnimationFrame(tick)
}
function seek(time: number, line: number | null = null) { pause(); cursor.value = Math.max(bounds.value.start, Math.min(time, bounds.value.end)); boundaryLine.value = line }
function jump(line: number) { const event = log.value.events.find(event => event.line === line); if (event) seek(event.unix_ms, line) }
function step(direction: number) {
  if (direction < 0) { const event = log.value.events[Math.max(0, count.value - 2)]; if (event) jump(event.line) }
  else { const event = log.value.events[count.value]; if (event) jump(event.line) }
}
function onVisibility() { if (document.hidden) pause() }
async function load() {
  pause()
  controller?.abort()
  controller = new AbortController()
  const signal = controller.signal
  loading.value = true
  error.value = ''
  try { log.value = await request<EventLog>(`/api/runs/${encodeURIComponent(props.run.id)}/events`, signal); if (!signal.aborted) seek(bounds.value.start) }
  catch (failure) { if (!signal.aborted) error.value = failure instanceof Error ? failure.message : String(failure) }
  finally { if (!signal.aborted) loading.value = false }
}
onMounted(() => { void load(); document.addEventListener('visibilitychange', onVisibility) })
onBeforeUnmount(() => { pause(); controller?.abort(); document.removeEventListener('visibilitychange', onVisibility) })
</script>

<template>
  <section class="replay-view">
    <div class="section-heading"><div><h3>历史记录回放</h3><p>依据事件时间重放，不会启动实验。</p></div><button class="button secondary" :disabled="loading" @click="load">重新读取</button></div>
    <p v-if="loading" class="empty-inline" role="status">正在读取回放记录……</p>
    <div v-else-if="error" class="notice error" role="alert"><p>{{ error }}</p><button class="table-link" @click="load">重试</button></div>
    <template v-else-if="log.events.length">
      <div v-if="sourceIssues" class="notice warning">{{ sourceIssues }} 行无法解析，回放仅使用有效记录。完整问题可在事件时间线核对。</div>
      <div class="replay-controls"><button class="button primary" :disabled="!duration" @click="toggle">{{ playing ? '暂停' : cursor >= bounds.end ? '从头播放' : '播放' }}</button><button class="button secondary" aria-label="上一个事件" @click="step(-1)">←</button><button class="button secondary" aria-label="下一个事件" @click="step(1)">→</button><label>速度<select v-model="speed" aria-label="回放速度"><option v-for="value in [1, 2, 5, 10]" :key="value" :value="value">{{ value }}×</option></select></label><button class="table-link" @click="seek(bounds.start)">回到起点</button><button class="table-link" @click="seek(bounds.end)">查看结束</button></div>
      <div class="replay-position"><span>{{ fmt(seconds, 3) }} / {{ fmt(duration / 1000, 3) }} s</span><span>{{ count }} / {{ log.events.length }} 条记录</span></div>
      <input class="replay-seek" type="range" aria-label="回放进度" :aria-valuetext="relativeEventTime(cursor, bounds.start)" :min="bounds.start" :max="bounds.end" :value="cursor" :disabled="!duration" step="1" @input="seek(Number(($event.target as HTMLInputElement).value))" />
      <div class="replay-readings"><div><span>窗口发出数</span><strong>{{ fmt(latestSample?.fields.issued) }}<small>次</small></strong></div><div><span>{{ operation.toUpperCase() }} 窗口 {{ percentile }}</span><strong>{{ latestSample ? fmt(windowLatency(latestSample, operation, percentile)) : '—' }}<small>µs</small></strong></div><div><span>已发布拓扑</span><strong>{{ latestTopology ? text(latestTopology.fields.epoch) : '—' }}<small>epoch</small></strong></div></div>
      <nav class="view-switch" aria-label="回放视图"><button :aria-pressed="view === 'metrics'" @click="view = 'metrics'">指标回放</button><button :aria-pressed="view === 'topology'" @click="view = 'topology'">拓扑回放</button></nav>
      <TopologyView v-if="view === 'topology'" :run="run" :events="seenTopology" :follow="true" />
      <template v-else>
      <template v-if="log.events.some(event => event.event === 'metrics_sampled')">
        <div class="comparison-controls"><select v-model="plot" aria-label="回放图表"><option value="latency">窗口延迟</option><option value="counts">发出／未按时发出／重试计数</option><option value="errors">各类别错误数</option><option value="target">目标速率</option></select><template v-if="plot === 'latency'"><select v-model="operation" aria-label="回放操作"><option v-for="op in operations" :key="op" :value="op">{{ op.toUpperCase() }}</option></select><select v-model="percentile" aria-label="回放分位值"><option v-for="key in ['p50', 'p95', 'p99', 'max']" :key="key">{{ key }}</option></select></template><label class="checkbox-label"><input v-model="hideWarmup" type="checkbox" />隐藏预热</label><label class="checkbox-label"><input v-model="markers" type="checkbox" />事件标记</label></div>
        <div class="replay-legend"><span v-for="(series, index) in seriesDefs" :key="series.name"><i :style="{ background: colors[index % colors.length] }"></i>{{ series.name }}</span></div>
        <div class="replay-chart"><DataChart ref="chart" :option="chartOption" :motion="false" :label="'截至回放时刻的' + plot + '记录曲线'" @layout="layoutVersion++" /><div v-if="playhead !== null" class="chart-playhead" :style="{ left: playhead + 'px' }" aria-hidden="true"></div><p v-if="!hasPlottedValue" class="chart-empty-label">{{ samples.length ? '当前窗口未记录此类指标' : '当前时刻尚无可显示的采样' }}</p></div>
        <p class="footnote">灰底为已记录的预热窗口，虚线为拓扑／迁移／故障事件。窗口分位数不是最终阶段分位数；缺采样或切换阶段时断线，不插值。{{ latestSample ? '当前窗口：' + text(latestSample.fields.stage) + ' · ' + fmt(latestSample.fields.window_ms) + ' ms' : '' }}</p>
      </template>
      <p v-else class="notice neutral">此运行没有 metrics_sampled，仍可按事件回放，不补画指标曲线。</p>
      </template>
      <label class="record-selector">跳转事件<select :value="currentEvent?.line" aria-label="回放跳转事件" @change="jump(Number(($event.target as HTMLSelectElement).value))"><option v-for="event in log.events" :key="event.line" :value="event.line">{{ relativeEventTime(event.unix_ms, bounds.start) }} · {{ eventName(event.event) }} · #{{ event.line }}</option></select></label>
      <div v-if="currentEvent" class="replay-current"><span class="unit-tag">#{{ currentEvent.line }}</span><strong>{{ eventName(currentEvent.event) }}</strong><span>{{ eventSummary(currentEvent) }}</span><time>{{ absoluteEventTime(currentEvent.unix_ms) }}</time></div>
      <details v-if="currentEvent" class="data-disclosure"><summary>当前事件字段与关键事件</summary><pre class="source-view event-fields" tabindex="0" aria-label="回放当前事件字段">{{ JSON.stringify(currentEvent.fields, null, 2) }}</pre><div class="key-event-links"><button v-for="event in keyEvents" :key="event.line" :aria-pressed="currentEvent.line === event.line" @click="jump(event.line)">{{ eventName(event.event) }} #{{ event.line }}</button></div></details>
    </template>
    <p v-else class="empty-inline">{{ log.missing ? '没有事件文件，无法回放。' : '没有有效事件记录，无法回放。' }}</p>
  </section>
</template>
