<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, useId, watch } from 'vue'
import type { DirectoryEntry, DirectoryGroup } from '../navigation'

const props = defineProps<{ groups: DirectoryGroup[]; active: string; expanded: string; hasRun: boolean }>()
const emit = defineEmits<{ choose: [entry: DirectoryEntry, keyboard: boolean]; expand: [id: string] }>()
const root = ref<HTMLElement | null>(null)
const id = useId()
const marker = ref({ top: 0, height: 0 })
let observer: ResizeObserver | undefined

function disabled(entry: DirectoryEntry) {
  return !props.hasRun && entry.panel !== null && entry.panel !== 'runs' && entry.panel !== 'experiment'
}

function updateMarker() {
  const tree = root.value
  const current = tree?.querySelector<HTMLElement>('[aria-current="page"]')
  if (!tree || !current || current.closest('[inert]')) { marker.value.height = 0; return }
  marker.value = { top: current.getBoundingClientRect().top - tree.getBoundingClientRect().top + 6, height: current.offsetHeight - 12 }
}

watch(() => [props.active, props.expanded], updateMarker, { flush: 'post' })
onMounted(() => {
  observer = new ResizeObserver(updateMarker)
  if (root.value) observer.observe(root.value)
  updateMarker()
})
onBeforeUnmount(() => observer?.disconnect())
</script>

<template>
  <div ref="root" class="index-tree">
    <i class="index-cursor" aria-hidden="true" :style="{ transform: `translateY(${marker.top}px)`, height: marker.height + 'px', opacity: marker.height ? 1 : 0 }"></i>
    <section v-for="(group, groupIndex) in groups" :key="group.label" class="index-group" :aria-label="group.label" :style="{ '--group-delay': groupIndex * 35 + 'ms' }">
      <h3>{{ group.label }}</h3>
      <ul>
        <li v-for="item in group.items" :key="item.id">
          <div class="index-entry" :class="{ 'is-parent-active': item.children?.some(child => child.id === active) }">
            <button class="index-link" :data-entry-id="item.id" :aria-current="active === item.id || (expanded !== item.id && item.children?.some(child => child.id === active)) ? 'page' : undefined" :disabled="disabled(item)" @click="emit('choose', item, $event.detail === 0)">{{ item.label }}</button>
            <button v-if="item.children" class="index-expand" :aria-label="(expanded === item.id ? '收起' : '展开') + item.label + '子目录'" :aria-expanded="expanded === item.id" :aria-controls="id + '-' + item.id" @click="emit('expand', expanded === item.id ? '' : item.id)"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="m6 4 4 4-4 4" /></svg></button>
          </div>
          <div v-if="item.children" :id="id + '-' + item.id" class="index-children" :class="{ expanded: expanded === item.id }" :inert="expanded !== item.id" :aria-hidden="expanded !== item.id">
            <ul><li v-for="child in item.children" :key="child.id"><button class="index-link" :data-entry-id="child.id" :aria-current="active === child.id ? 'page' : undefined" :disabled="disabled(child)" @click="emit('choose', child, $event.detail === 0)">{{ child.label }}</button></li></ul>
          </div>
        </li>
      </ul>
    </section>
  </div>
</template>
