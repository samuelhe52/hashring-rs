# 从零理解 Hashring Dashboard：学习、读代码与后续开发

写给：cyable（GitHub：cyablex）  
编写日期：2026-11-01  
真实工作区：`D:/数据结构课程/实验7/项目/hashring-rs`

## 怎么使用这份文档

这份文档服务于你接下来的顺序：**先学习 → 你明确说开始 → AI 协助完成并验收第一版 → 你能理解代码、检查数据，并继续推进后续功能。**

学完的目标是：你能说清一个功能要展示什么、从哪里取数据、代码大概改在哪里、怎样判断做对了。后续仍可以让 AI 写代码；你逐步负责方向、理解和验收，不要求先成为独立开发整个系统的工程师。

建议分四次读，每次结束做对应练习，不必一次记住所有术语：

| 阅读顺序 | 章节 | 读完要能做什么 |
| --- | --- | --- |
| 第一次：认识项目 | 1—3 | 解释系统和你的职责，找到三类结果文件 |
| 第二次：读懂结果 | 4—5 | 讲清自己那次实验的配置、成绩和过程 |
| 第三次：认识网页代码 | 6—9 | 顺着一条数据追到页面，读懂常见 Vue 和后端代码 |
| 第四次：准备继续工作 | 10—12 | 验收第一版，拆解后续功能，完成综合练习 |

本文里的真实数据来自你亲手运行的 `my-latency-20261028-013354`，没有混用 AI 那次实验或组长验收报告的成绩。标注“教学示例”的代码用来阅读理解，不等同于成品代码。第一版的实际文件划分和接口见第 9 节与 README。

**更新（2026-11-02）：第一版曾由你验收通过，随后加入事件时间线；本次将界面整理为简洁概览 + 六类浮窗，新布局仍待你验收。现场汇报先看 REPORTING.md，本文用于深入学习。配色保留并可后续调整。回放、拓扑、实时、跨运行对比与实验启动尚未实现；验收不等于授权 Git 提交或推送。**

## 1. 先知道整个项目在做什么

### 1.1 用一个例子认识键值存储

假设我们保存这样的信息：

```text
键 key：student:20250001
值 value：陈阳的某条资料
```

“键”用于找到数据，“值”是保存的内容。实际实验里的键和值由程序生成，并不是学生信息。

| 操作 | 意思 | 类比 |
| --- | --- | --- |
| PUT | 写入或更新一个键的值 | 把资料放进指定编号的格子 |
| GET | 根据键读取值 | 按编号取资料 |
| DELETE | 删除这个键 | 清空对应格子 |

项目让多个数据节点一起保存这些键值。数据节点主要把数据放在内存里，访问快；进程退出可能丢失其内存数据，因此需要副本和恢复机制。

这里的“3 个节点”可以是同一台电脑上的 3 个进程，不一定是 3 台电脑。

### 1.2 有三个不同的程序职责

| 角色 | 做什么 | 你先理解到什么程度 |
| --- | --- | --- |
| 协调器 coordinator | 记录哪些节点在集群里、数据怎样分配、拓扑版本和变更状态 | 把它理解为集群分工的管理者 |
| 数据节点 node | 实际保存数据、处理请求、复制和迁移数据 | 把它理解为工作的存储进程 |
| 实验驱动 experiment | 启动这些进程，发送请求，核验结果，写结果文件 | 把它理解为自动测试和记录工具 |

协调器使用 `coordinator.redb` 持久保存自己的管理状态，**这不表示所有数据节点里的键值都落盘了**。

项目主要用 Rust 编写。同一个 `hashring-rs` 可执行程序通过不同子命令扮演不同角色。你负责的 Dashboard 则使用网页技术读取它的输出，之后才接入实验控制。

### 1.3 Dashboard 到底负责什么

第一版的数据流是：

```text
Rust 实验已经运行结束
        ↓ 写文件
results/某次实验/
        ↓ 本地 Node 后端读取
HTTP 接口返回数据
        ↓ 浏览器请求
Vue 页面显示表格和图表
```

Rust 负责实验、指标计算和核验；Dashboard 负责读取、组织、交互和展示。比如 p99 已经写在结果里，网页取出来画图，不重新测量或计算 p99。

你做的是帮助别人看懂实验的工具。别人应该能够回答：“这是哪次实验？什么配置？成功了吗？负载变大后发生了什么？哪里能看到证据？”

**停下来想：** 实验已经跑完，协调器也关闭了，Dashboard 还能显示结果吗？

能。结果文件还在，就可以浏览；历史拓扑要读事件里保存的快照，不需要重新启动旧集群。

## 2. 一致性哈希、副本和故障：够你做 Dashboard 的理解

### 2.1 为什么把数据放在一个“环”上

普通的 `hash(key) % 节点数` 在节点数改变时，可能让大量键重新分配。一致性哈希把节点的位置和键的位置放到同一个环上，让成员变化主要影响附近的部分区间。

本项目里的环位置叫 **token**。键经过哈希得到 token，再在排好序的节点位置中找归属。

下面只用 0—99 的小环教学，实际系统使用 `u64` 范围：

```text
顺时针方向，数值递增：
0 → A(20) → B(50) → C(80) → 99 → 回到 0
```

项目按“第一个大于或等于键 token 的位置”找 owner；超过最大位置就绕回第一个。

| 键的 token | 找到的位置 | owner |
| --- | --- | --- |
| 12 | 20 | A |
| 35 | 50 | B |
| 50 | 50 | B |
| 91 | 绕回 20 | A |

若新增 D(40)，原来归 B 的 `(20,40]` 部分改归 D。已有数据也要转移，这叫**迁移**；画环只是表现这个过程。

### 2.2 虚拟节点不是额外启动的程序

一个物理节点可以在环上有很多位置，这些位置称为虚拟节点。同一个颜色的多个点，可能都属于同一个数据节点。

你那次实验是 3 个物理节点，每个 128 个虚拟节点，共 384 个分配位置。它不是启动了 384 个存储进程。

虚拟节点通常能减小随机分布的偏差，但某次实验不会因此保证每个节点恰好拥有一样多的键。后面会用 635、534、831 这三个真实数值观察这一点。

### 2.3 owner、followers、RF 分别是什么

- **owner**：某个键的主要负责节点。
- **followers**：保存这个键副本的其他节点。
- **RF（Replication Factor）**：期望总副本数，**包括 owner**。

例如 RF=3，正常完整分配时是 1 个 owner + 2 个 followers，放在不同物理节点上。沿环选副本时遇到同一物理节点的其他虚拟位置，会跳过重复节点。

一个节点可以是键 X 的 owner，同时是键 Y 的 follower。“owner”是针对某个键或区间的职责，不是一个节点永远固定的头衔。

配置里的 `desired_replication_factor` 是目标。故障或修复过程中，实际健康副本可能达不到目标；页面不能仅凭 RF=3 就宣称当前已有 3 份健康数据。

### 2.4 RF 与 ACK 策略不是同一个问题

RF 问“希望保存几份”，ACK 策略问“客户端等到什么条件，才收到写成功的回答”。

| 策略 | 何时返回写成功 | 你展示时要知道的代价 |
| --- | --- | --- |
| `OwnerOnly` | owner 已应用这次写入 | 其他副本可能尚未跟上，owner 故障时可能丢失已确认的新写入 |
| `FirstSuccessor` | owner 和顺时针第一个 follower 都已应用 | 比只等 owner 要多等副本；项目针对单次 owner 故障提供更强的数据保留保证 |
| `AllReplicas` | owner 和所有期望 followers 都已应用 | 对完整副本放置的健康状态要求更高，等待可能更长 |

复制通过后台机制进行；ACK 策略决定客户端等待到哪一步。`OwnerOnly` **仍然会复制**，不等于 RF=1。所有策略下数据节点都以内存存储，不能把“确认过副本”说成“永久保存到磁盘”。

### 2.5 epoch、迁移和故障恢复

**epoch 是拓扑版本号。** 例如节点分工变化后，从 epoch 1 发布为 epoch 2。它不是秒数、节点数量或实验阶段编号。

| 名词 | 发生了什么 | 页面可能展示什么 |
| --- | --- | --- |
| 扩容 / 缩容 | 加入 / 移除节点 | 成员数量、分工变化 |
| 迁移 migration | 数据区间转移到新负责节点 | 开始、完成、耗时、owner 变化 |
| 故障转移 failover | 原 owner 故障，其他节点接任 | 故障事件、新 owner、读写恢复时间 |
| 恢复到完整 RF | 修复缺失副本，重新达到副本目标 | 恢复完整副本的时间 |

“能读了”和“所有副本修好了”是两个时间点，不应混成一个“恢复时间”。

### 2.6 这阶段不需要先学完什么

可以先跳过 Rust 语法、gRPC 的二进制协议、迁移算法内部、并发控制实现。需要增加 Rust 输出字段时，先整理需求，交给 @Solaris 或组长协商；Dashboard 不自行修改 `crates/`。

## 3. 认识你手上的环境和文件

### 3.1 同一份仓库，两种路径写法

| 位置 | 路径 / 用途 |
| --- | --- |
| Windows 仓库 | `D:/数据结构课程/实验7/项目/hashring-rs` |
| WSL Debian 看到的同一目录 | `/mnt/d/数据结构课程/实验7/项目/hashring-rs` |
| Dashboard 代码 | 仓库根目录下的 `dashboard/` |
| 实验结果 | 仓库根目录下的 `results/` |
| Rust 编译产物 | `target/release/hashring-rs`，是 Linux 可执行程序 |

Windows 和 WSL 可以看到同一份文件，但它们的 Node、npm 等安装环境是两套。命令前要先看自己在哪个终端、哪个目录。

后续推荐 Rust 与 Dashboard 本地后端都在 WSL 运行，Windows 浏览器访问网页。交接里的环境已经配过；这份文档不要求你重新安装。

### 3.2 先认识命令的含义，不要现在逐条运行

| 以后会遇到的命令 | 意思 | 作用位置 |
| --- | --- | --- |
| `wsl -d Debian` | 从 Windows 进入 Debian | PowerShell |
| `pwd` / `cd` | 看当前位置 / 切换目录 | WSL 终端 |
| `cargo build --release --locked` | 按锁文件编译 Rust 发布程序 | WSL，仓库根目录 |
| `hashring-rs experiment ...` | 运行一次实验；实际路径和参数由运行说明给出 | WSL |
| `npm run dev` | 执行 `package.json` 里定义的 dev 脚本 | 将来按 README，在 `dashboard/` |
| `npm run build` | 执行该项目定义的构建检查和打包 | 将来按 README，在 `dashboard/` |

终端是输入命令的界面；**进程**是正在运行的程序；关闭网页标签不等于停止后端进程。`Ctrl+C` 通常用于向当前前台进程请求停止。具体怎样启动和停止，等第一版完成后按实际 README 操作。

交接时只有 `package.json` 和部分草稿，缺少页面、样式和测试。第一版现已补齐这些文件，启动与检查步骤以 `dashboard/README.md` 为准。

### 3.3 一次实验的目录

你的这次结果目录是：

```text
results/my-latency-20261028-013354/
├── manifest.json
├── summary.json
├── events.jsonl
├── coordinator.redb
└── process-logs/
    ├── coordinator.stdout.log
    ├── coordinator.stderr.log
    ├── node-1.stdout.log
    ├── node-1.stderr.log
    └── ……其他节点日志
```

| 文件 | 最好先记住的说法 | Dashboard 用途 |
| --- | --- | --- |
| `manifest.json` | 实验的设置与身份 | 配置、开始时间、源码版本、可复现性 |
| `summary.json` | 最终成绩单 | 成功 / 失败、阶段速率、延迟、负载等 |
| `events.jsonl` | 按时间记录的过程 | 时间线、后续的曲线和回放 |
| `process-logs/` | 各进程输出的文字 | 查日志、定位错误 |
| `coordinator.redb` | 协调器的管理数据库 | Dashboard 不读取 |

`stdout` 是常规输出，`stderr` 常用于诊断信息和日志。**stderr 文件里有文字，不自动表示实验失败**，要看实际内容和 summary。

`results/` 被 Git 忽略，完整结果留在本地。仓库 `docs/data/` 里的 TSV 汇总表，不一定包含 Dashboard 所需的完整 manifest、事件和日志。

### 3.4 先会读 JSON

JSON 是保存结构化数据的文本格式。下面节选自你的 `manifest.json`，只保留了部分字段：

```json
{
  "source_reproducible": false,
  "config": {
    "mode": "latency",
    "node_count": 3,
    "key_count": 2000,
    "target_rates": [500, 1000],
    "write_ack_policy": "OwnerOnly"
  }
}
```

| 写法 | 类型 | 怎么理解 |
| --- | --- | --- |
| `{ ... }` | 对象 object | 一组“字段名 → 值” |
| `[500, 1000]` | 数组 array | 有顺序的一组值，从索引 0 开始 |
| `"latency"` | 字符串 string | 文字，带双引号 |
| `2000` | 数字 number | 可参与数值运算 |
| `false` / `true` | 布尔 boolean | 否 / 是，没有引号 |
| `null` | 空值 | 这个字段没有可用值，具体含义看契约 |

例如 `manifest.config.node_count` 意思是：先取 manifest 的 config，再取里面的 node_count。`target_rates[0]` 是 500，`target_rates[1]` 是 1000。

JSON 文件不能随意加注释、单引号或末尾多余逗号。文档中标作 `jsonc` 的示例可能带注释，不能当普通 JSON 直接解析。

尤其分清三种情况：

| 情况 | 含义 | 合理显示 |
| --- | --- | --- |
| `"retries": 0` | 已记录，次数确实为零 | `0` |
| `"cpu_percent": null` | 有字段，但没有可用 CPU 采样 | `未采集` 或 `—` |
| 整个字段不存在 | 此结果没有提供这项信息 | `未提供` 或隐藏该项 |

`"false"` 是文字，`false` 才是布尔。你这份 manifest 的 `build.git_dirty` 实际是字符串 `"true"`；`source_reproducible` 则是布尔 `false`。读代码时要看真实类型。

## 4. 读懂你亲手跑的实验

### 4.1 先从 manifest 看“测的条件”

下面都是这次实验的实际配置：

| 字段 | 值 | 含义 |
| --- | --- | --- |
| `mode` | `latency` | 按固定目标速率测负载下的延迟 |
| `node_count` | 3 | 3 个数据节点 |
| `desired_replication_factor` | 3 | 期望每个键共 3 份副本 |
| `write_ack_policy` | `OwnerOnly` | 写成功只等待 owner 应用 |
| `key_count` / `preload_keys` | 2000 / 2000 | 先写入 2000 个键，作为负载键空间 |
| `value_bytes` | 128 | 每个值 128 字节 |
| `virtual_nodes` | 128 | 每个物理节点 128 个虚拟位置 |
| `target_rates` | `[500, 1000]` | 依次进行两个速率阶段 |
| `warmup_seconds` | 2 | 每个阶段先预热 2 秒 |
| `duration_seconds` | 10 | 每个阶段正式计时 10 秒 |
| `mix` | `90:9:1` | GET、PUT、DELETE 的操作配比 |
| `key_distribution` | `uniform` | 键访问分布为均匀分布 |
| `max_in_flight` | 4096 | 尚未完成的负载请求数量上限 |
| `concurrency` | 16 | 本次预加载、核验等批量步骤的并发配置；不是每秒请求数，也不是 `max_in_flight` 的别名 |

“并发”表示同时有多个任务或请求在进行。latency 正式负载按目标时间表投放，并由 max_in_flight 限制尚未完成的请求；不能把 concurrency=16 解释成该阶段最多只能有 16 个在途请求。

配置中还会记录 fault、scaling 等其他模式的默认参数。**字段存在不等于这次执行了那个模式**，本次实际模式看 `config.mode`。

正式实验的参数解析规则是：命令行覆盖 YAML，YAML 覆盖默认值。相对输出路径写在 YAML 里时，按配置文件目录解析；结果 manifest 记录解析后的实际配置。

### 4.2 再从 summary 看“最终怎么样”

你这份 summary 的概要节选：

```json
{
  "success": true,
  "error": null,
  "elapsed_seconds": 27.555309429,
  "final_epoch": 1
}
```

这表示实验驱动判断本次成功，未记录最终错误，总耗时约 27.56 秒，结束时拓扑版本为 1。

两个阶段各包含 `2 秒预热 + 10 秒计时`，合计 24 秒。总耗时还包含启动、预加载、核验、收尾等，所以不是恰好 20 秒或 24 秒。

“success=true”表示本次实验按其核验规则通过，**不意味着已测出系统最大容量，也不意味着所有故障组合都已验证**。

### 4.3 两个速率阶段在哪里

`summary.measurements` 中有 `rate_0`、`rate_1`。编号从 0 开始，它们分别对应 500 和 1000 ops/s。

| 指标 | `rate_0` | `rate_1` |
| --- | --- | --- |
| `target_rate` 目标速率 | 500 ops/s | 1000 ops/s |
| `achieved_rate` 实际成功速率 | 500 ops/s | 1000 ops/s |
| `seconds` 正式计时长度 | 10 s | 10 s |
| `issued` 实际发出的请求 | 5000 | 10000 |
| 成功 GET | 4527 | 9019 |
| 成功 PUT | 424 | 874 |
| 成功 DELETE | 49 | 107 |
| `late` | 0 | 0 |
| `retries` | 0 | 0 |
| 六类 `errors` | 全部 0 | 全部 0 |
| `sender_saturated` | false | false |

第一阶段的 `4527 + 424 + 49 = 5000`。错误为零时，它们恰好等于 issued。正式配比是 90:9:1，但有限次请求的实际数量不要求恰好成为 4500、450、50。

这一算式是帮助你核对和理解已有数据，不是让 Dashboard 另做一套指标计算。

### 4.4 measurements 和 observations 不要读反

在这份 latency 结果中：

- `measurements.rate_0` / `rate_1`：正式速率阶段的结果。
- `observations.initial_put`：预加载 2000 个键的耗时与吞吐。
- `observations.initial_get_verify`：初始读校验。
- `observations.latency_verified_keys`：负载后核验了 2000 个键。
- `observations.idle_client_put_latency_us`：空闲集群的 PUT 基线延迟。

不同模式的结构不完全相同。不要假定所有吞吐都在 `measurements.initial_put`，也不要把空闲基线放进“负载下延迟”的同一列冒充可比数据。

这次还有 `observations.latency_delete_pool_keys=180`，表示专供 DELETE 使用的键池大小。读写不访问这个删除池，写操作对同一键写入固定的预期值，使程序能核对最终状态。“核验了 2000 个键”包含检查该存在的值是否正确、该删除的键是否不存在，并不表示最后仍有 2000 个键全部存在。

### 4.5 源码身份和实验成功分开看

你这份 manifest 记录：

- `build.git_commit`：`b60bf2a390ec1fa7085ac91fb1fd41bfdb047a21`。
- `build.profile`：`release`。
- `build.target`：`x86_64-unknown-linux-gnu`。
- `build.git_dirty`：`"true"`。
- `source_reproducible`：`false`。

这表示运行记录的源码可复现性标记没有满足干净、匹配源码的要求。要解释具体原因，需要继续检查该次 manifest 的运行源码信息；不能直接套用组长报告里那次运行的原因。

页面应同时表达“实验成功”和“源码可复现性未满足”。学习用的小实验可以保留这些信息；正式测量怎样准备干净源码，之后按组内要求处理，不要为了消除提示擅自删文件或提交。

**小检查：** `source_reproducible=false` 能不能把成功状态自动改成失败？不能，它们回答的是两个不同问题。

## 5. 指标、事件和图表：怎样避免看错数字

### 5.1 吞吐与延迟

**吞吐**说“单位时间做成多少操作”，单位常见为 `ops/s`。**延迟**说“一个操作花了多久”，本项目延迟通常用 `µs`（微秒）。

```text
1 秒 = 1000 毫秒 ms
1 毫秒 = 1000 微秒 µs
```

1000 ops/s 不是“每个请求一定耗时 1 毫秒”，因为多个请求可以同时在途。

`target_rate` 是想投放的速率，`achieved_rate` 是正式阶段成功操作数除以阶段时长。**它不是 issued 的同义词**：发出去的请求可能失败。

`performance` 通常让并发任务尽可能快地发请求，看吞吐能力；`latency` 按固定时间表发请求，观察指定负载下的延迟。后者的计时从“应该发出”的时刻开始，把客户端落后于计划的等待也算进去。

### 5.2 p50、p95、p99 不是平均值

把请求延迟从小到大排好：p50 约对应中间的位置；p99 约对应 99% 的请求不超过的位置。它们描述不同部分的体验。

你的 GET 延迟实际是：

| 阶段 | 样本数 | p50 | p95 | p99 | max |
| --- | --- | --- | --- | --- | --- |
| 500 ops/s | 4527 | 401 µs | 599 µs | 732 µs | 1368 µs |
| 1000 ops/s | 9019 | 321 µs | 555 µs | 660 µs | 1336 µs |

例如 `summary.measurements.rate_0.latency_us.get.p99` 的值是 732 µs，也就是 0.732 ms。

这一次 1000 档的 p99 比 500 档低，不能据此断言“提高负载一定降低延迟”。这是一次短时、低负载的本地实验，机器状态和测量波动也会影响结果。

本模式的分位数来自覆盖返回请求的直方图，失败请求的返回延迟也可能在内；不要把所有模式的延迟都叫“成功请求延迟”。`samples` 是对应分布的样本数。

| 其他字段 | 含义 |
| --- | --- |
| `p999` | 99.9 百分位，关注更靠后的尾部 |
| `max` | 最大直方图桶的上界，可能稍高于最慢请求本身 |
| `max_observed` | 实际观察到的最慢请求延迟 |
| `over_range` | 超出直方图测量范围的请求数 |

**禁止把每秒 p99 的平均值当作整个阶段的 p99。** 阶段卡片读 summary，过程曲线读 events。跨重复实验的聚合也需要先确认口径和由谁输出，不能在前端自行制造“合并 p99”。

### 5.3 late、errors、retries、sender_saturated

| 字段 | 这个请求发生了什么 | 能否当作同一种失败相加 |
| --- | --- | --- |
| `late` | 在途请求已满，这次计划请求没发出去 | 它不在 issued 内 |
| `errors` | 请求发出后，以某种未成功结果结束 | 与成功 ops 一起对应 issued |
| `retries` | 客户端多试了几次，包括可重试的拓扑刷新 | 一个请求可能重试后成功，不能当作失败请求数 |
| `sender_saturated` | 发送端自身没有跟上计划 | 表示这阶段不能按原目标负载解释为集群表现 |

六种 errors 原因是 `deadline`、`not_found`、`operation`、`protocol`、`rpc`、`topology`。先知道它们区分超时、未找到、操作拒绝、协议、传输、路由问题即可。`not_found` 是负载中的读取结果，不自动等同于集群损坏。

正式阶段应满足：**成功 ops 总数 + errors 总数 = issued**。late 单独报告。网页直接展示 Rust 已记录的数据，若发现对不上，把证据交给实验程序负责人。

发送端饱和与集群跟不上不是一件事：集群接不住时，可能 late 很多，但发送线程仍按计划处理了每个发送时刻，所以 `sender_saturated` 仍为 false。

### 5.4 负载均衡要分开看“键”和“请求”

你这次 `rate_0.load_balance.per_node` 的真实数据：

| 节点 | `owned_keys` owner 键数 | `ops_handled` 阶段处理操作数 | `cpu_percent` |
| --- | --- | --- | --- |
| node-1 | 635 | 1573 | 4.2% |
| node-2 | 534 | 1321 | 约 3.7% |
| node-3 | 831 | 2106 | 约 5.1% |

owner 键数加起来是 2000，不是 6000。**owned_keys 只统计谁是 owner，不把 follower 副本重复算进去**。3 个节点、RF=3 时，每个节点还会保存其他键的副本。

CPU 是该节点整个进程相对一个核心的用量，不是“全机所有核心的百分比”，也不是缓存逻辑单独的 CPU。原始小数可能是 `5.099999999999999`，页面保留一位小数显示 5.1% 即可；保留原文用于核对。

| 已由 Rust 输出的统计量 | 读法 |
| --- | --- |
| `owned_keys_max_over_mean` | 最大 owner 键数 ÷ 各节点平均 owner 键数；越接近 1 越均匀 |
| `owned_keys_cv` | owner 键数的标准差 ÷ 平均值；越接近 0 越均匀 |
| `ops_handled_max_over_mean` / `ops_handled_cv` | 对操作数做相同统计，表示请求分布 |

本次 owner 键数的 max/mean 约为 1.2465，CV 约为 0.18495。它们是无量纲比值，不带 µs 或 ops/s。

均匀访问 `uniform` 是各键被选中的机会相近；Zipf、hotspot 则让部分键更热门。**键分得较匀，不保证请求也匀**：一个热键通常仍集中到其 owner。

### 5.5 JSONL 是“每行一个 JSON 对象”

普通 `summary.json` 是一个整体对象。`events.jsonl` 则是一行一条事件，不是外面套了 `[]` 的数组，不能把整个文件直接交给一次普通 `JSON.parse`。

下面节选自你这次实验的第一条 `metrics_sampled`，为了阅读展开了缩进，省略了其他字段；实际 JSONL 中整条事件占一行：

```json
{
  "event": "metrics_sampled",
  "unix_ms": 1793122446749,
  "fields": {
    "stage": "rate_0",
    "warmup": true,
    "window_ms": 1000,
    "target_rate": 500,
    "issued": 501,
    "late": 0,
    "epoch": 1
  }
}
```

逐项读：这是一条指标采样事件；属于 rate_0；它仍在预热；采样窗口长 1000 ms；这一窗口发出了 501 个请求；没有因在途上限丢弃；拓扑版本为 1。

每秒目标 500，但某个窗口计数可能是 501，不能要求所有窗口与整数目标完全一致。阶段结果读正式阶段 summary，不把这个预热窗口代入正式成绩。

`unix_ms` 是从 Unix 起点计算的毫秒时间戳。页面可以转为本地时区时间；做时间轴时，也可以表示成距离运行开始的秒数。两种方式都应标清时间含义。

### 5.6 把这次事件数量对应到实验过程

你这次共有 **24 条 metrics_sampled**，因为两个阶段各有 2 秒预热和 10 秒计时。另有 **2 条 topology_published**，分别记录历史拓扑快照，两条的 epoch 都是 1。

两次快照不等于两次拓扑变化；开始和结束都可以记录同一个 epoch。

常见事件可以这样读：

| 事件 | 大意 |
| --- | --- |
| `experiment_started` | 实验启动 |
| `cluster_ready` | 集群就绪 |
| `initial_put_complete` | 初始写入完成 |
| `metrics_sampled` | 一个时间窗口的指标 |
| `topology_published` | 一份拓扑快照 |
| `verification_complete` | 核验完成 |
| `experiment_finished` | 实验结束 |

不同模式还可能有迁移、故障、修复事件。先看 `event` 是什么，再看 `fields` 内容，别仅凭事件位置猜含义。

### 5.7 选图前先问“我要回答什么”

| 问题 | 数据来源 | 合适的表达 |
| --- | --- | --- |
| 某阶段 GET、PUT、DELETE 的 p99 谁更高？ | summary 的分位数 | 表格 + 柱状图，纵轴 µs |
| 负载增加后延迟怎样变化？ | 各 rate 阶段的实际速率与分位数 | 横轴实际 ops/s、纵轴 µs 的数值轴曲线 |
| 哪个节点拥有的键最多？ | `load_balance.per_node` | 节点柱状图 |
| 哪一秒发生故障？ | events 时间戳和事件类型 | 时间线，后续叠加竖线标记 |
| 当前或过去某时刻谁负责哪个区间？ | topology 快照 | 哈希环 + 节点说明 |

缺失值应显示未知或图表断点；不能画成 0。样本单位、阶段、操作类型和是否预热，都应让读者看得见。

## 6. 网页开发的几样东西，各自管什么

### 6.1 不要一次背技术栈

| 技术 | 在这个项目里的具体职责 |
| --- | --- |
| HTML | 定义标题、按钮、表格等内容结构 |
| CSS | 定义颜色、间距、大小、页面排列 |
| JavaScript（JS） | 处理点击、请求数据、转换显示结构 |
| TypeScript（TS） | 在 JS 基础上写类型，让工具提前发现部分用法错误 |
| Vue 3 | 把数据状态与页面绑定，组织可复用组件 |
| Vite | 帮助开发时加载页面、更新代码，并打包前端 |
| ECharts | 根据给定数据和配置画图 |
| Node.js | 在浏览器外运行 JS，让本地后端读文件、提供接口 |
| npm | 管理依赖、按 package.json 执行脚本 |

Vue 和 Node 都可能使用 JS，但运行地点和权限不同。浏览器里的 Vue 代码通常不能导入 Node 的 `node:fs/promises` 随意读本地文件。

### 6.2 浏览器为什么需要本地后端

浏览器不会因为页面知道 `D:/.../summary.json`，就允许它任意读取你的磁盘。后续启动实验也要创建本机进程，因此用 Node 小后端承担本机操作。

网页通过 **HTTP** 与后端说话。**API 接口**是双方约定的访问方式，例如：

```text
GET /api/runs
```

意思是“请求实验列表”。GET 是读取方法，`/api/runs` 是路径。

以后启动实验可能使用 POST，它表示向后端提交一个动作。请求方法来自接口约定，不是任意替换的文字。

### 6.3 localhost、端口和节点地址

`http://localhost:4173` 中：

- `http`：浏览器与服务说话的协议。
- `localhost`：本机。
- `4173`：本机上这个服务使用的端口号。

4173 是当前本地后端的默认端口，服务启动后才能访问。可以按 README 用 PORT 调整。

拓扑中数据节点的 `endpoint` 也长得像 URL，但 Rust 节点使用 gRPC。不能假定浏览器对那个地址直接 `fetch` 就能拿到实验详情；Dashboard 的 HTTP 接口和 Rust 节点接口是两层东西。

### 6.4 一次点击怎样走完整条链

假设你在实验列表点击自己的运行：

1. Vue 记住被点击的运行 id。
2. Vue 请求本地后端的详情接口。
3. 后端根据 id 找到对应结果目录。
4. 后端读取 manifest、summary，解析后组织成接口响应。
5. 浏览器收到 JSON，更新页面状态。
6. Vue 根据新状态显示配置和指标，图表组件接收对应数据。

页面的 `run.summary.measurements.rate_0.latency_us.get.p99` 最终来自磁盘里同一字段的 732。你能追通这条链，就有了定位功能和错误的基础。

## 7. 能读懂第一版所需的 JavaScript 和 TypeScript

本章是教学示例，不要求现在新建文件执行。

### 7.1 变量、对象和数组

```js
const stageName = 'rate_0'
const stage = { target_rate: 500, achieved_rate: 500 }
const rates = [500, 1000]

console.log(stage.achieved_rate) // 500
console.log(rates[0])           // 500
```

`const` 声明一个不再重新赋值的变量；`let` 用在需要重新赋值的变量上。`const` 对象里面的内容仍可以改变。

`=` 是赋值；`===` 是严格比较。`stage.target_rate === 500` 的结果为 true。

### 7.2 函数：把一段工作取个名字

```js
function formatMicroseconds(value) {
  return value == null ? '—' : `${value} µs`
}
```

函数接收 value，返回显示用的文字。反引号里的 `${value}` 是把变量放进字符串。这里特意使用 `value == null`，同时识别 null 和 undefined；数值 0 不会被误判为缺失。

调用 `formatMicroseconds(732)` 得到 `732 µs`，调用 `formatMicroseconds(null)` 得到 `—`。

箭头函数是另一种常见写法：`value => value * 2` 表示“接收 value，返回它的两倍”。看懂输入和返回值即可。

### 7.3 map、filter 和 Object.entries

```js
const stages = [
  { name: 'rate_0', achieved_rate: 500 },
  { name: 'rate_1', achieved_rate: 1000 },
]

const xValues = stages.map(stage => stage.achieved_rate)
// [500, 1000]：每项提取一个值，得到新数组

const highRateStages = stages.filter(stage => stage.achieved_rate >= 1000)
// 只保留符合条件的项，这里只剩 rate_1
```

如果拿到的是对象而不是数组，例如 `{ rate_0: {...}, rate_1: {...} }`，可以用 `Object.entries(...)` 得到一组 `[字段名, 值]`，再逐项显示。

这常用于“把 measurements 变成每阶段一行的表格”。不要依赖字段文字排序得到数值顺序：字符串排序可能把 rate_10 排在 rate_2 前。

### 7.4 ?. 和 ??：处理缺失数据

```js
const retries = stage?.retries ?? '未提供'
```

`?.` 是可选访问：stage 为空时不继续访问属性，得到 undefined。`??` 只在左边是 null 或 undefined 时采用右边的替代值。

如果 retries 是 0，上面仍得到 0。如果写成 `stage.retries || '未提供'`，0 会被错误替换，因为 `||` 会把 0、false、空字符串等都当作不成立。

同样，不能用 `if (summary.success)` 的一个 else 就把“失败”和“尚无 summary”混为一谈。要分别判断 `=== true`、`=== false` 和缺失。

### 7.5 import、export：文件之间怎样合作

```js
import { readFile } from 'node:fs/promises'
```

意思是从 Node 自带的文件模块引入 readFile 功能。`import ... from './某文件'` 则从自己的相对路径文件引入。

一个文件用 `export` 把功能交给其他文件。当前 store.mjs 导出 `createStore`，index.mjs 引入并使用它。你查一个函数不知道来自哪儿时，先看文件顶部 import。

### 7.6 async / await：等待结果，再往下做

```js
async function loadRuns() {
  const response = await fetch('/api/runs')
  if (!response.ok) {
    throw new Error(`读取列表失败：HTTP ${response.status}`)
  }
  const body = await response.json()
  return body.runs
}
```

`fetch` 发 HTTP 请求；它返回一个 Promise，可以理解为“稍后成功或失败的结果”。`await` 等这一操作得到结果后，再执行这个函数的下一步，不是把整个浏览器都卡住。

第一次 await 等响应，第二次 await 读取响应体并把 JSON 转成 JS 对象。`response.ok` 表示 HTTP 状态在成功范围内。**HTTP 404、500 通常不会让 fetch 自动抛异常**，所以要主动检查；网络连接失败等情况才会使请求本身拒绝。

读取流程与 HTTP 错误处理可对照 [MDN：使用 Fetch](https://developer.mozilla.org/zh-CN/docs/Web/API/Fetch_API/Using_Fetch)。

### 7.7 try / catch / finally：页面失败时怎样收尾

```js
try {
  // 尝试读取数据
} catch (error) {
  // 显示失败原因
} finally {
  // 成功或失败，都结束“加载中”状态
}
```

“加载中”“接口读取失败”“实验本身失败”是三个不同状态。成功读到了 `success=false` 的 summary，表示 HTTP 读取成功、实验失败；应该显示错误详情和已有结果。

### 7.8 TypeScript：给数据形状写说明

```ts
type RunListItem = {
  id: string
  status: 'success' | 'failed' | 'incomplete'
  elapsed_seconds?: number
}
```

意思是：每项有字符串 id，status 只使用这三种文字；elapsed_seconds 后面的 `?` 表示可能没有这个字段。`RunListItem[]` 是这样的对象组成的数组。

类型帮助编辑器发现拼错字段或把数字当文字等问题。**类型声明不是对外部 JSON 的自动核验**：后端实际没有提供的字段，不会因为 TS 写了它就出现。

这份类型只是教学示例，真实接口应按实现定义。后续查类型语法可看 [TypeScript：常用类型](https://www.typescriptlang.org/docs/handbook/2/everyday-types.html)。

## 8. Vue：从数据到页面

### 8.1 一个 .vue 文件有哪几部分

```vue
<script setup lang="ts">
// 数据、函数、引入的组件
</script>

<template>
  <!-- 页面结构，以及显示数据的地方 -->
</template>

<style scoped>
/* 当前组件的样式 */
</style>
```

`setup` 表示使用这套组件编写方式，`lang="ts"` 表示脚本使用 TypeScript。`scoped` 帮助把样式限制在本组件，不是 JS 的权限设置。

**组件**就是把一块页面和它的行为放在一起。例如运行列表、配置表、延迟图都可以成为组件。第一版具体怎样拆文件，等实现时再确定。

### 8.2 ref：让数据变化能反映到页面上

```ts
import { ref } from 'vue'

const selectedId = ref('')
selectedId.value = 'my-latency-20261028-013354'
```

`ref` 创建响应式状态。修改它后，Vue 会更新使用这份状态的页面部分。脚本中通过 `.value` 读写，模板里本例这种顶层 ref 通常自动解包。

```vue
<p>当前选择：{{ selectedId }}</p>
```

`{{ ... }}` 把值显示为文字。状态 selectedId 改变，这段文字就随之更新。详情见 [Vue：响应式基础](https://cn.vuejs.org/guide/essentials/reactivity-fundamentals.html)。

### 8.3 模板里最常用的六种写法

| 写法 | 做什么 | 在 Dashboard 中的用途 |
| --- | --- | --- |
| `{{ value }}` | 显示文字 | 显示运行名、p99 |
| `:属性="表达式"` | 动态设置属性，是 v-bind 的简写 | 按加载状态禁用按钮 |
| `@click="函数"` | 响应点击，是 v-on:click 的简写 | 点击打开某次结果 |
| `v-if="条件"` | 条件成立时显示 | 有错误时显示错误信息 |
| `v-for="item in items"` | 遍历列表 | 每个运行显示一行 |
| `v-model="query"` | 把输入框与状态关联 | 输入关键词筛选 |

列表还常写 `:key="run.id"`，帮助 Vue 识别每个条目，通常用稳定、唯一的 id。

按需查阅：[模板语法](https://cn.vuejs.org/guide/essentials/template-syntax.html)、[条件渲染](https://cn.vuejs.org/guide/essentials/conditional.html)、[列表渲染](https://cn.vuejs.org/guide/essentials/list.html)、[表单绑定](https://cn.vuejs.org/guide/essentials/forms.html)。

### 8.4 computed：从已有状态得到显示结果

```ts
const visibleRuns = computed(() =>
  runs.value.filter(run => run.id.includes(query.value))
)
```

这里根据 runs 和 query 得到符合关键词的列表。源状态变化时，计算属性随之更新，适合筛选和显示结构转换。它没有重新计算实验的 p99、CV 等指标。

`computed` 需要从 Vue 引入。见 [Vue：计算属性](https://cn.vuejs.org/guide/essentials/computed.html)。

### 8.5 把前面知识串起来：一个列表组件教学示例

下面展示“请求列表、处理失败、关键词筛选、点击选择”。**它不是第一版成品，也没有写入 App.vue**；需要将来在可运行的 Vue 工程中结合实际接口使用。

```vue
<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'

type RunItem = {
  id: string
  status: 'success' | 'failed' | 'incomplete'
}

const runs = ref<RunItem[]>([])
const query = ref('')
const selectedId = ref('')
const loading = ref(false)
const errorMessage = ref('')

const visibleRuns = computed(() =>
  runs.value.filter(run => run.id.includes(query.value))
)

async function loadRuns() {
  loading.value = true
  errorMessage.value = ''
  try {
    const response = await fetch('/api/runs')
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`)
    }
    const body = await response.json()
    runs.value = body.runs
  } catch (error) {
    errorMessage.value = error instanceof Error ? error.message : String(error)
  } finally {
    loading.value = false
  }
}

onMounted(loadRuns)
</script>

<template>
  <input v-model="query" aria-label="按运行名筛选" placeholder="输入运行名" />
  <button :disabled="loading" @click="loadRuns">重新读取</button>

  <p v-if="loading">正在读取结果……</p>
  <p v-else-if="errorMessage">读取失败：{{ errorMessage }}</p>
  <p v-else-if="runs.length === 0">没有找到运行结果</p>
  <p v-else-if="visibleRuns.length === 0">没有匹配的运行</p>
  <ul v-else>
    <li v-for="run in visibleRuns" :key="run.id">
      <button @click="selectedId = run.id">{{ run.id }}</button>
      <span>{{ run.status }}</span>
    </li>
  </ul>

  <p v-if="selectedId">已选择：{{ selectedId }}</p>
</template>
```

顺着读一遍：

1. 创建列表、关键词、选择项、加载和错误这几份状态。
2. `onMounted` 在组件挂载后调用读取函数，也就是页面这块内容准备好后发起请求。
3. HTTP 成功后，把返回的 `body.runs` 放入 runs。
4. computed 根据关键词筛出 visibleRuns。
5. 模板依据加载、错误和列表状态决定显示哪部分。
6. 点击条目后只更新选择项；这个例子还没有加载详情。

你不需要一开始就默写。先能指出“输入框改了哪个变量”“哪一行发请求”“哪里显示错误”“列表从哪儿来”。

### 8.6 组件之间怎样传数据

父组件可以把选中的 summary 作为属性传给子组件，子组件只负责显示。例如下面是概念示例，RunSummary 组件将来还需要实际创建和引入：

```vue
<RunSummary :summary="selectedRun.summary" />
```

父传给子的数据称为 **props**。子组件可以通过 **emit** 把“选择了某个阶段”等事件通知父组件。这样列表、详情和图表各管一块，避免所有逻辑挤在一处。见 [Vue：组件基础](https://cn.vuejs.org/guide/essentials/component-basics.html)。

### 8.7 看懂几行样式，够你反馈和微调

```css
.metric-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}
```

这表示 `.metric-grid` 元素里的内容排成两列，列内允许收缩，元素之间留 16 像素间距。`padding` 是内部留白，`margin` 是外部间距，`font-size` 是字号。

学习时先关注表格能否看清、单位是否明显、内容是否溢出、窗口缩小时是否可用。颜色和深浅风格等你决定后再落实。

### 8.8 ECharts 配置和 Vue 状态怎样衔接

图表库接收的是“画图选项”。例如以下教学配置使用你那次 GET p99 的真实数值：

```js
const option = {
  tooltip: { trigger: 'axis' },
  xAxis: { type: 'value', name: '实际速率（ops/s）' },
  yAxis: { type: 'value', name: 'GET p99（µs）' },
  series: [{
    name: 'GET p99',
    type: 'line',
    data: [[500, 732], [1000, 660]],
  }],
}
```

每个 `[x, y]` 是一个点。以后代码应该从 summary 提取它们；这里直接写数值只是为了让你看懂形状。

组件挂载、容器有尺寸后初始化图表，数据变化时更新配置；窗口改变时调整尺寸，组件移除时释放图表。容器没有高度时，可能有数据却看不到图。入门可对照 [Apache ECharts：快速上手](https://echarts.apache.org/handbook/zh/get-started/)。

## 9. 对照实际代码，学会找到要看的文件

### 9.1 第一版实际文件地图

以下按第一版实现后的真实工作区更新；软件功能验收与 Git 提交授权仍是两回事：

| 路径（相对 dashboard/） | 作用 | 当前情况 |
| --- | --- | --- |
| `package.json` | 依赖、运行脚本 | 已有 |
| `package-lock.json` | 记录依赖解析版本 | 沿用现有锁文件 |
| `tsconfig.json` | TypeScript 检查设置 | 已有 |
| `vite.config.ts` | Vue 开发与打包设置 | 已明确前端根目录 |
| `client/index.html` | HTML 入口，提供 app 挂载位置 | 已有 |
| `client/src/main.ts` | 创建并挂载 Vue 应用 | 已接到实际页面 |
| `client/src/App.vue` | 列表、筛选、详情请求与视图切换 | 第一版已补齐 |
| `client/src/style.css` | 浅色配色、布局、窄屏样式 | 第一版已补齐 |
| `client/src/types.ts`、`data.ts` | 数据类型、格式化和接口请求 | 第一版新增 |
| `client/src/components/RunOverview.vue` | 指标与图表配置、阶段选择 | 第一版新增 |
| `client/src/components/DataChart.vue` | 图表创建、更新、尺寸变化和释放 | 第一版新增 |
| `client/src/components/RunFiles.vue` | 原始文件和日志的查看、搜索、下载 | 第一版新增 |
| `client/src/components/RunTimeline.vue`、`client/src/events.ts` | 事件时间线、筛选、摘要与详情 | 第一版之后新增 |
| `server/events.mjs` | JSONL 解析、精度保留、坏行与排序 | 第一版之后新增 |
| `server/index.mjs` | 接 HTTP 请求、路由和提供页面 | 第一版已整理 |
| `server/store.mjs` | 扫描结果目录和读文件 | 第一版已整理 |
| `server/store.test.mjs`、`http.test.mjs` | 结果读取与接口测试 | 第一版已补齐 |
| `README.md` | 实际启动和使用说明 | 第一版已补齐 |
| `LEARNING.md` | 本学习文档 | 已补充成品导读 |

`.mjs` 是 JavaScript 模块文件，不是 Rust。`.vue` 是 Vue 组件文件，`.ts` 是 TypeScript 文件。

### 9.2 从入口顺着读，不必逐行硬啃

当前 `main.ts` 是：

```ts
import { createApp } from 'vue'
import App from './App.vue'
import './style.css'

createApp(App).mount('#app')
```

含义是：引入 Vue 的创建功能、根组件和样式，把根组件挂到 HTML 中 `id="app"` 的位置。交接时缺少导入的 App.vue 和 style.css；第一版已补齐这两个入口依赖。

第一版完成后，建议阅读顺序是：

```text
README：怎么启动
    ↓
main.ts：页面从哪儿开始
    ↓
App.vue / 实际组件：状态、按钮、数据展示
    ↓
fetch 调用：浏览器访问哪个接口
    ↓
server/index.mjs：接口转交给哪个函数
    ↓
server/store.mjs：实际读了哪个文件
    ↓
summary / manifest：原始值是什么
```

你可以在编辑器全局搜索 `/api/runs`、`p99`、`readRun` 来追踪。不要遇到一个不认识的配置字段，就停下来学完整个工具链。

### 9.3 Node 后端读文件在做什么

下面是简化的教学流程，实际后端还包含文件缺失和错误处理：

```js
const text = await readFile(filePath, 'utf8')
const summary = JSON.parse(text)
```

第一行把文件读取成 UTF-8 文字，第二行转成可访问字段的 JS 对象。`JSON.parse` 用于解析；`JSON.stringify` 则反过来把 JS 值转为 JSON 文字，常用于接口响应。

目录扫描使用 `readdir`；拼接路径用 `path`；`.mjs` 中引入的是 Node 内置能力，不需要给每个内置模块单独安装包。参见 [Node 24：文件系统 API](https://nodejs.org/docs/latest-v24.x/api/fs.html)。

接口只能读取项目允许的结果目录和文件，不能把浏览器给的任意路径直接交给 readFile。第一版的 store.mjs 会核对结果、原文、日志和符号链接的读取边界；新增事件接口复用这层检查。

### 9.4 第一版接口怎样对应文件

下表是第一版代码的阅读地图，对应 `server/index.mjs`。服务启动后可使用，停止后不能访问：

| 第一版请求 | 用途 |
| --- | --- |
| `GET /api/runs` | 返回 `{ runs: [...] }`，每项是运行概要 |
| `GET /api/runs/:id` | 返回该运行的 manifest 展示字段和 summary |
| `GET /api/runs/:id/events` | 返回排序后的事件、异常行与缺文件标记 |
| `GET /api/runs/:id/raw?file=summary.json` | 返回原始 JSON 文字 |
| `GET /api/runs/:id/raw?file=events.jsonl` | 返回原始事件文字 |
| `GET /api/runs/:id/logs` | 列出日志名称 |
| `GET /api/runs/:id/logs?process=node-1.stderr.log` | 读取该进程日志 |
| `GET /api/guide` | 读取本学习文档 |
| `GET /api/reporting` | 读取现场汇报攻略 |

`:id` 是路径参数占位写法，例如替换为你的运行目录名；包含斜杠时用 encodeURIComponent 编码。原规格用于说明需求，实际接口与数据格式见 README。

### 9.5 先判断错误落在哪一层

以后调试时打开浏览器开发者工具（通常 F12），重点看 Console（控制台）和 Network（网络）：

| 现象 | 先查什么 |
| --- | --- |
| 浏览器提示无法连接 | 后端是否启动、地址和端口是否正确 |
| 接口返回 404 | URL 是否匹配路由，指定运行或文件是否存在 |
| 接口返回 500 | 后端终端报错、文件是否可读或 JSON 是否损坏 |
| 接口有正确值，页面没有 | 前端字段路径、条件渲染、组件传参 |
| 表格正确，图表为空 | 图表容器尺寸、数据转换和更新时机 |
| `success=false` 但接口 200 | 实验失败，按 summary.error 展示，不归为网络故障 |

向 AI 反馈时附上“我点击了什么、期望什么、实际什么、相关报错”，通常比只说“跑不起来”更容易定位。

## 10. 第一版完成后，怎样继续后面的工作

### 10.1 先划清第一版和完整交付

当前第一版目标是：**读取已有真实结果 → 列表 → 详情 → 配置、状态、速率、延迟和负载图**。它是后续功能共用的基础。

下面是完整需求中后续功能的学习路线，不代表已经选定开发顺序或全部冻结了范围。旧规格的对比与导图有可选备注，scaling / fault 的正式支持范围也需要你向组长确认。

| 功能 | 第一版里能复用什么 | 还需要增加什么 |
| --- | --- | --- |
| 事件时间线、日志浏览 | 已有运行选择、文件读取、详情布局 | 已补齐；后续可以与回放联动 |
| 多次结果对比 | 配置表、指标表、图表 | 多选运行、对应阶段、配置差异提示 |
| 历史回放 | 事件、图表、详情状态 | 回放时钟、进度控制、按时刻选择数据 |
| 哈希环拓扑 | 运行选择、无损历史事件 | 精确区间表达、环图、epoch 切换 |
| 实验启动与停止 | 本地 Node 服务、结果列表 | 参数表单、进程管理、运行状态 |
| 实时视图 | 历史曲线、事件展示 | 持续读取新增事件、推送、结束后转详情 |

表中尚未完成的功能仍需要实质开发，不是只换配色。可以沿着“数据 → 接口 → 状态 → 组件 → 验收”这条线逐步推进。

### 10.2 每次加功能，先填写五句话

以“给详情页添加事件时间线”为例：

1. **用户动作：** 打开某次实验的“事件”区域。
2. **数据来源：** 该运行的 events.jsonl；不是 summary，也不是数据库。
3. **后端责任：** 提供可读取的事件数据，保留字段和时间信息，说明缺失或读取失败。
4. **前端责任：** 按时间显示事件，点击展开 fields，标明预热和阶段。
5. **验收证据：** 你那次运行显示 24 条指标事件、2 条拓扑事件，选择几条与原文逐项一致。

先把这五句说清，再请 AI 提出最小实现和解释对应代码。就算你还不会写整段函数，也能判断它有没有做错对象、读错文件或超出范围。

### 10.3 事件时间线：从“最终成绩”走向“过程”

先区分普通 JSON 和 JSONL，再选择读取方式。已结束的文件可以按行解析；带 u64 token 的拓扑事件还要按 10.5 的办法保留精度。

对历史损坏行应给出读取问题，不能默默当作没有发生。将来实时读取时，文件末尾可能暂时只有半行，要等完整一行写入再解析；这是持续写文件的正常状态。

时间线最开始只需时间、事件名和可展开 fields。你能先解释每条事件，再考虑筛选、颜色和时间轴上的标记。

### 10.4 结果对比：先对应同一类实验条件

比较 OwnerOnly 与 AllReplicas 的延迟前，先核对键数、值大小、节点数、RF、负载配比、分布、目标速率、机器和源码等条件。

前端可以并排展示配置、突出不同字段；不同条件下的结果也可以展示，但要让读者看见差异，不能暗示是严格控制其他条件的实验。

多个 latency 运行的阶段不应仅凭 `rate_0` 对齐，因为每次的第一个速率未必相同。曲线横轴用各自真实的 achieved_rate，表格显示对应 target_rate 和配置。

“重复运行的平均 p99”与“把全部请求合在一起的 p99”也不一样。聚合口径和输出责任需与组长 / @Solaris 确认后实现，网页不擅自合成新指标。

### 10.5 哈希环：画图之前先保住 token

拓扑快照中的 `members` 说明有哪些物理节点；`assignments` 说明每个 token 属于哪个节点；`epoch` 表示拓扑版本。

实际 token 是 `u64`，范围为 0 到 18446744073709551615。JS 的 Number 只能精确表达不超过 **9007199254740991** 的所有整数。你这次第一项 token `15411063893526418` 就超过了这个界限。

因此，不能先用普通 `JSON.parse` 把所有 token 变成 Number，再转换 BigInt；精度可能在第一次转换时已经丢失。也不要用简单的正则批量替换 JSON 中的数字。

事件时间线已经采用 Node 的 JSON.parse reviver context.source 读取数字原文，把超出安全范围的大整数以字符串传给浏览器，保留 u64 精度。后续绘制拓扑仍要核对 Rust 的区间与副本契约，使用精确值处理 token，不自行改 Rust。

原 token 用来显示、比较、判断区间，必须精确；画图坐标可以在精确值基础上做近似映射。概念上是“token 占整个环的比例 × 360°”。不要把画图用的近似角度当回原 token。

一个能演示的环图还应能回答：颜色对应哪个物理节点？选中了哪个 epoch？该区间的 owner / followers 是谁？它不只是画出漂亮的圆。

### 10.6 历史回放：不是重新跑一次实验

回放使用已经保存的事件，改变“当前播放到哪儿”，不启动原集群、不重新发负载。

一个基本流程是：

```text
读取事件，按时间组织
        ↓
设定播放起点和当前播放时间
        ↓
显示当前时刻之前的曲线点与事件
        ↓
选取不晚于当前时刻的最近一份拓扑快照
        ↓
播放 / 暂停 / 调速 / 拖动时，更新当前播放时间
```

2× 表示现实经过 1 秒，播放时间前进 2 秒。拖回早一点时，图表、事件和拓扑都应回到同一时刻；不能只有进度条倒退，环图仍停在最后一个 epoch。

没有指标采样的运行可以只有事件时间线。没有采集过的数据，回放不能凭空补出来。

### 10.7 实验启动器：表单到本机进程

未来的启动链路是：浏览器提交参数 → 本地后端校验和整理参数 → 启动 Rust 子进程 → 跟踪状态和输出目录 → 结束后刷新详情。

需要理解的三个重点：

- 浏览器负责提交意图，Node 才能创建本机进程。启动前要让用户看见最终参数或命令。
- 启动进程宜使用参数数组，不能把用户填写的文字直接拼成任意 shell 命令执行。
- 同时只跑一个实验，停止时处理本次实验的进程及其启动的集群进程，保留结果目录；关闭标签页不应被当作可靠的停止方式。

具体停止机制要检查实验程序已有信号与清理行为后确定。输出目录必须是新的或空目录，不能覆盖上次实验。

参数表单要按实际模式显示适用字段。当前 Rust 有 correctness / performance / availability / latency / scaling / fault；旧 UI 草案只列了其中四种，支持范围要确认。

### 10.8 实时视图：后端把新增数据持续送来

普通 fetch 常用来“问一次、答一次”。实时显示可以使用：

| 方式 | 大意 | 适用理解 |
| --- | --- | --- |
| 轮询 | 前端隔一段时间再问一次 | 实现直观，需明确增量或完整数据 |
| SSE | 服务端沿一条连接持续推送事件 | 适合后端单向把日志、指标送到网页 |
| WebSocket | 建立持续的双向通信 | 适合需要持续双向消息的场景 |

不需要同时实现三种。具体选择在这项工作开始时确定。

图表尽量复用回放的展示部分：历史回放提供“文件里的事件”，实时提供“刚收到的事件”。遇到窗口字段口径不够用时，例如想显示成功速率却只取到了 issued，要先确认定义，不能换个标题就把发出数当成功数。

## 11. 第一版怎样验收，你和 AI 怎样分工

### 11.1 你应当能亲自核对的事情

第一版完成后，对着你这份真实结果验收：

- 能从列表打开 `my-latency-20261028-013354`。
- 显示 latency、3 节点、RF=3、OwnerOnly、2000 键。
- 成功状态和 `source_reproducible=false` 分开显示，总耗时约 27.56 秒。
- 两阶段目标 / 实际速率为 500 / 500、1000 / 1000 ops/s。
- GET p99 显示 732、660 µs；如果换成 ms，分别为 0.732、0.660，并标明单位。
- 错误、retries、late 的真实 0 被保留；缺失数据不会被填成 0。
- owner 键数为 635、534、831，图表读数与表格对应。
- 页面初次读取、空列表、读取失败都有可理解的状态。
- 失败运行能显示错误原因和已完成部分，不白屏。

最后一项需要合适的失败结果样本。没有样本时可以在单独的验证数据中构造明确标注的失败结构，不修改你的真实结果；实现时由 AI 安排必要验证，并如实告诉你使用了哪种证据。

这一验收列表服务于当前第一版，不能替代组长对完整产品的验收。构建、运行和检查应在你明确授权开始第一版之后执行。

### 11.2 用一个小变更练习接手代码

第一版完成后，可以选一项已有基础的小需求练习，例如“在 GET 延迟旁单独写出样本数说明”。如果第一版已实现，就反向追踪那段代码，而不重复开发。

步骤是：

1. 在原始结果找到 `measurements.rate_0.latency_us.get.samples`，确认是 4527。
2. 搜索页面中显示 GET p99 的组件，找到它接收的数据。
3. 看 samples 是否已随详情接口传来；若已经有，通常无需改后端。
4. 在模板加显示，在空值时给出“未提供”，不要改动其他指标。
5. 用这次真实运行核对 4527，再用第二阶段核对 9019。
6. 阅读差异，确认只改变了这项展示，运行该改动需要的检查。

做完后，你掌握的是可重复的方法：找到来源 → 找到传递路径 → 修改负责展示的位置 → 用原文验收。

### 11.3 你和 AI 各自负责什么

| 你 | AI |
| --- | --- |
| 决定要做什么、什么时候开始 | 在授权范围内实现、解释和验证 |
| 对照原始结果，判断显示是否可信 | 追踪字段、检查实现与数据一致性 |
| 反馈哪里看不懂、演示需要什么 | 把术语、代码和实际操作连接起来 |
| 与组长确认范围、日期和数据需求 | 帮你整理问题和证据，未经授权不代发消息 |
| 最后操作验收、练习讲解 | 提供可复现的启动说明和已完成检查 |

可以这样向 AI 提需求：

> 我想基于事件时间线加历史回放。请先依据现有结果说明数据和拟改文件，用这次真实运行定义验收点。暂不实现实验启动；等我确认范围后再开始写代码。

也可以这样提代码学习要求：

> 请从 GET p99 的 732 开始，指出它从 summary 到页面经过哪些函数。每次讲一个文件，解释变量和数据形状，先不要改代码。

### 11.4 Git：保存修改不等于提交，更不等于推送

| 动作 | 含义 |
| --- | --- |
| 保存文件 | 修改留在本地工作区 |
| `git status` / `git diff` | 查看修改状态 / 已跟踪文件的差异 |
| `git add <明确路径>` | 把指定修改放入暂存区 |
| `git commit` | 在本地创建提交 |
| `git push` | 把提交发送到 GitHub 远端 |

新文件可能不出现在普通 git diff 中，应同时看 status。`?? dashboard/` 表示它还未被跟踪，不表示目录里没有东西。

本项目只按自己的明确路径暂存，不使用 `git add .` 或 `git add -A`。**你说“开始做第一版”只授权对应开发；验收通过后，提交和推送仍要你另行明确授权。** 不因学习材料提到命令就执行它们。

## 12. 自测与答案：判断自己是否准备好继续

### 12.1 第一次阅读后：项目与文件

1. RF=3、OwnerOnly 是不是互相冲突？
2. 3 个节点、每个 128 个虚拟节点，会启动 384 个存储进程吗？
3. 配置、最终成绩、每秒过程分别读哪个文件？
4. 为什么网页第一版仍需要一个本地后端？

参考答案：

1. 不冲突。目标保存 3 份，但写成功仅等待 owner 应用，复制还在进行。
2. 不会。只有 3 个数据节点进程，384 是环上的分配位置。
3. manifest、summary、events.jsonl；日志另在 process-logs。
4. 浏览器不能按任意本地路径直接读取结果，Node 服务代为读取并提供 HTTP 接口。

### 12.2 第二次阅读后：真实数据

5. rate_0 的 GET p99 从哪里读，值是多少？
6. 这次正式阶段一共发出多少请求？预热是否包含在内？
7. 为什么 24 条指标事件不等于 24 秒都计入正式成绩？
8. 2000 个 owner 键为什么不是按 RF 乘成 6000 个 owned_keys？
9. 0、null、缺字段应不应该显示成同样的 0？
10. 实际速率较低时，能否只看 retries 就判断原因？

参考答案：

5. `summary.measurements.rate_0.latency_us.get.p99`，732 µs。
6. 5000 + 10000 = 15000，不含预热；来自两个正式阶段的 issued。
7. 每个阶段有 2 秒预热，一共 4 条预热指标；正式计时共 20 秒。
8. owned_keys 按主要归属统计，follower 的副本不重复计算。
9. 不应该。0 是测到了零；null 和缺字段要根据含义显示未采集、未提供或隐藏。
10. 不能。还要看成功数、错误、late、sender_saturated 和相关条件。

### 12.3 第三次阅读后：读代码

11. `runs.value`、`v-for`、`v-if` 分别解决什么问题？
12. 输入关键词之后，教学示例中的列表为什么会变化？
13. HTTP 返回 404，fetch 是否一定自动抛异常？
14. API 已返回 p99=732，但页面为空，优先看 Rust 还是前端？
15. 修改一个已经由详情接口传来的字段的排版，一定需要改后端吗？

参考答案：

11. 读写响应式状态；遍历显示列表；按条件显示内容。
12. v-model 修改 query，computed 根据它筛选 runs，模板显示筛选后的结果。
13. 不一定，应检查 response.ok，再决定抛出和展示错误。
14. 先看前端字段路径、条件和组件数据传递，再依据证据定位。
15. 通常不用，找到负责显示的组件修改即可。

### 12.4 第四次阅读后：后续功能与边界

16. 历史回放要不要重新启动一次 Rust 实验？
17. 为什么不能把读成 Number 的 token 再转 BigInt 就算保住精度？
18. 要添加一个原结果没有的新统计指标，你先做什么？
19. 在完整需求尚未确认前，能否把“第一版完成”说成“Dashboard 全部完成”？

参考答案：

16. 不要，使用已保存事件和播放时间来更新展示。
17. 数字可能在 JSON 转 Number 时已经舍入，之后转换无法找回丢失的位数。
18. 明确指标含义和用途，检查现有输出，向 @Solaris / 组长确认实验程序输出和职责。
19. 不能，第一版是结果浏览基础；对比、回放、拓扑、实时和启动器还需要各自实现与验收。

### 12.5 开始第一版前，你应该能用自己的话说这段话

> 我负责本地 Dashboard，用 Vue 做页面，用 Node 后端读 results。manifest 告诉我实验条件，summary 告诉我最终成绩，events 记录过程。我那次是 3 节点、RF=3、OwnerOnly，测了 500 和 1000 ops/s 两档；两档都达到目标，GET p99 是 732 和 660 微秒。我会核对单位、失败状态和缺失字段，不让网页编造指标。第一版先完成真实结果浏览，之后在同一条数据链上继续加功能。

不必逐字背诵。能解释这些关系，再把综合代码示例大致读通，就可以喊我开始第一版。

第一版完成后，再亲自追通一条真实指标、做完 11.2 的小练习，并讲清一个后续功能的五句话。**“读懂基础 + 对照成品代码 + 实际核对一个变更”是继续后续工作的达标方式。**

## 附：遇到具体问题再查的材料

这不是要求你额外通读的阅读清单。本文能先独立阅读，下列资料用于查证和继续深入。

| 项目内材料 | 用途 |
| --- | --- |
| 仓库 `README.md` 的 Replication and guarantees | 核对 RF、ACK、内存存储和数据保留边界 |
| `docs/experiments.md` | 当前实验模式、真实字段、延迟统计和事件含义 |
| `docs/configuration.md` | 参数、默认值、适用范围和 YAML 规则 |
| `docs/latency-acceptance.md` | 组长那组验收实验的方法、数据和限制，别与自己的成绩混用 |
| `docs/scaling-under-load.md`、`docs/fault-under-load.md` | 后续支持扩缩容和故障负载时再读 |
| `results/my-latency-20261028-013354/` | 本文真实数据的来源 |
| `dashboard/server/` | 第一版本地读取后端与测试 |

外部资料的入口已放在对应章节，优先看 Vue 中文指南、MDN、TypeScript、Node 和 Apache ECharts 官方文档。项目的字段以当前项目文档和实际输出为准，第一版的操作步骤以实现后编写并验证的 README 为准。

## 第一版成品导读：亲自追通 GET p99 的 732

读完前面的基础，再打开实际页面和编辑器，沿下面这条线阅读。不需要重新跑实验。

1. 在页面选择 `my-latency-20261028-013354`，当前阶段选 `rate_0`，GET p99 应为 732 µs。
2. 在 `App.vue` 找 `selectRun`：它请求 `/api/runs/` 加编码后的 id，把响应存入 `run`，然后传给 `RunOverview`。
3. 在 `server/index.mjs` 找 `store.readRun(id)`，再到 `store.mjs` 看它从对应目录读取 summary。
4. 在 `RunOverview.vue` 找 `rateStages`：它使用 `data.ts` 的 stages 整理 summary.measurements。`currentEntry` 选择当前阶段，`current` 取出该阶段的数据。
5. 搜索 `latency(current, op).p99`：这里读取当前操作的 p99，交给 fmt 排版。它没有求每秒分位数的均值。
6. 切换到 rate_1，GET p99 应变为 660，样本数变为 9019。再切换另一条运行，它的 rate_0 GET p99 是 601，不能仍是 732。

随后看 `curveOption`：横轴从 achieved_rate 读取，纵轴从 latency_us 读取；`DataChart.vue` 接收 option 并绘制。这样你能区分“读数据的函数”“选阶段的状态”“整理图表的配置”“真正绘图的组件”。

第一版的源码可复现性提示、空闲基线说明和“—”的显示，分别对应第 4.5、5.2、3.4 节的概念。下一步学习时，优先把页面上看见的东西与这些章节一一对应，再做第 11.2 节的小变更练习。

## 事件时间线成品导读：从 35 行记录看懂一次过程

选择自己的运行，点击“事件时间线”。先看 35 条事件、24 个指标窗口、2 份拓扑快照；新版默认只显示 8 条关键事件。取消“只看关键事件”，再展开“搜索、筛选与跳转”，勾选“隐藏预热采样”后剩 31 条。它们是文件内容的分类和筛选，不是新测出的集群性能指标。

1. 在 `RunTimeline.vue` 找 `load()`：它读取 `/api/runs/:id/events`。
2. 在 `server/index.mjs` 找 `store.events(id)`，到 `store.mjs` 看它在允许目录内读取 events.jsonl。
3. 在 `server/events.mjs` 看 `parseEventLog`：按行读，每条保留原始行号；坏行单独记入 issues，正常行按时间排序，同时间按原文顺序。
4. 在浏览器“跳转到关键事件”中选择第 3 行拓扑快照。字段视图中的 token `"15411063893526418"` 是字符串；切到“本行原文”，可以看到 Rust 写出的数字。这是精度保留，不是另造了一个 token。
5. 回到 `RunTimeline.vue`，看 `filtered` 怎样按类别、阶段、关键词筛选；`pageEvents` 每页取 50 条；`selectedLine` 决定详情展示哪一条。筛选和点选不会写回文件。
6. 在 `client/src/events.ts` 看事件名称、类别与摘要。未知事件保留原名；两次 topology_published 被称为“快照已记录”，不会误说成两次拓扑变更。

相对时间优先以启动事件的 unix_ms 为零点；没有启动事件时退到 manifest 开始时间，再退到首条有效事件，界面会标明基准。这是时间轴坐标，和 summary.elapsed_seconds 是两个口径，不能拿它替换总耗时成绩。

小练习：在“事件时间线”中先取消“只看关键事件”，展开筛选后选择 rate_1，应有 12 个窗口；再隐藏预热，应有 10 个。选择一个窗口，对照 fields 里的 stage、warmup、issued、latency_us，再切“本行原文”核对。这里仍没有回放时钟，也不会启动 Rust 实验。

## 浮窗版代码地图（2026-11-02）

数据读取链没有改变，变化的是页面如何组织信息：

- `App.vue`：运行选择、当前阶段、主页面两个读数，以及打开哪一类窗口。运行列表入口改为“切换运行”。
- `components/DetailWindow.vue`：原生 dialog、显示后挂载内容、关闭动画、Esc／外部点击和焦点恢复。
- `components/RunOverview.vue`：通过 section 区分延迟、节点、其他观测；通过 stage 与主页面共享当前阶段。不是三份重复的指标数据。
- `components/RunConfig.vue`：实际配置、构建环境、源码可复现性和文件警告。
- `RunTimeline.vue`、`RunFiles.vue`：保留原有记录功能，放入对应窗口。时间线默认先看关键事件，完整采样与筛选仍可展开。

追 GET p99 的 732 时，主页面查看 App.vue 的 latency('get').p99；详情窗口查看 RunOverview.vue 的 latency(current, op).p99。它们都读取同一份 summary 的 rate_0.latency_us.get.p99，没有新增计算。

练习：在主页面选 rate_1，再打开“延迟与速率”，确认窗口当前阶段也是 rate_1；关闭后主页面仍显示 660 µs。能解释这个共享状态，比记住每一行样式更有用。
